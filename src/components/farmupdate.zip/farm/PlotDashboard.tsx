"use client";

/**
 * PlotDashboard — Intelligence Workstation
 * 
 * Bridges AgriBrainChat ↔ FarmMap ↔ Layer 10 Intelligence.
 * When Layer 10 data loads, the map becomes multi-mode with surface overlays,
 * zone inspection, histograms, and quicklook thumbnails.
 */

import { useState, useEffect } from "react";
import dynamic from "next/dynamic";
import AgriBrainChat from "@/components/farm/AgriBrainChat";
import { useLayer10 } from "@/hooks/useLayer10";
import MapModeSwitcher from "@/components/farm/intelligence/MapModeSwitcher";
import HistogramDrawer from "@/components/farm/intelligence/HistogramDrawer";
import QuicklookStrip from "@/components/farm/intelligence/QuicklookStrip";
import ZoneInspector from "@/components/farm/intelligence/ZoneInspector";
import IntelligenceLegend from "@/components/farm/intelligence/IntelligenceLegend";
import AnalysisStrip from "@/components/farm/intelligence/AnalysisStrip";
import { MODE_CONFIG } from "@/hooks/useLayer10";

const PlotMapShell = dynamic(() => import("@/components/farm/map/PlotMapShell"), { 
  ssr: false,
  loading: () => (
    <div className="h-full w-full bg-slate-900 rounded-lg animate-pulse flex items-center justify-center text-slate-500">
      Initializing AgriBrain WebGL Engine...
    </div>
  )
});

interface PlotDashboardProps {
  farm: Record<string, unknown> | null;
  plot: Record<string, unknown> | null;
  cropName?: string;
  context: Record<string, unknown> | null;
}

export default function PlotDashboard({ farm, plot, cropName, context }: PlotDashboardProps) {
  const [mounted, setMounted] = useState(false);

  // Layer 10 Intelligence
  const l10 = useLayer10();

  // Client-only mount flag to avoid SSR hydration mismatch
  useEffect(() => { setMounted(true); }, []);

  // Fetch true L10 data on mount
  useEffect(() => {
    if (plot?.id && farm?.id) {
      l10.fetchLayer10(String(plot.id), String(farm.id), undefined, undefined, cropName);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [plot?.id, farm?.id, cropName]);

  // Compute surface value range for legend
  const valueRange: [number, number] | undefined = (() => {
    if (!l10.activeSurface) return undefined;
    let min = Infinity, max = -Infinity;
    for (const row of l10.activeSurface.values) {
      for (const v of row) {
        if (v !== null && v !== undefined) {
          if (v < min) min = v;
          if (v > max) max = v;
        }
      }
    }
    return min < Infinity ? [min, max] as [number, number] : undefined;
  })();

  // Find zone data for inspector
  const selectedZoneData = l10.selectedZone && l10.data
    ? l10.data.zones.find(z => z.zone_id === l10.selectedZone)
    : null;

  return (
    <div className="flex flex-col gap-2 h-[78vh]">
      {/* Layer 10 Intelligence Bar — client-only to avoid hydration mismatch */}
      {mounted && (
        l10.data ? (
          <MapModeSwitcher
            activeMode={l10.activeMode}
            detailMode={l10.detailMode}
            onModeChange={l10.setActiveMode}
            onDetailModeChange={l10.setDetailMode}
            loading={l10.loading}
          />
        ) : l10.error ? (
          <div className="mode-switcher">
            <div className="flex items-center gap-2 px-3 py-2 text-red-400 text-xs">
              <span>⚠️ SIRE v10.5</span>
              <span className="text-red-500">{l10.error}</span>
            </div>
          </div>
        ) : (
          <div className="mode-switcher">
            <div className="flex items-center gap-2 px-3 py-2 text-slate-400 text-xs">
              <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
              <span>
                {l10.loading ? "Loading SIRE v10.5 intelligence..." : "Initializing SIRE v10.5..."}
              </span>
            </div>
          </div>
        )
      )}

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 flex-1 min-h-0">
        {/* COL 1: Map (3/4 Width) */}
        {farm && (
          <div className="lg:col-span-3 card fade-in overflow-hidden p-0 h-full flex flex-col relative">
            <div style={{ flex: 1, position: "relative" }}>
              <PlotMapShell 
                farms={farm ? [farm] : []} 
                plots={plot ? [plot] : []} 
                activeMode={l10.activeMode}
                cropName={cropName}
                surfaceData={l10.activeSurface}
                surfaceColors={l10.activeColors}
                confidenceSurface={l10.activeConfidenceSurface}
                gridHeight={l10.data?.grid.height}
                gridWidth={l10.data?.grid.width}
                l10Zones={l10.data?.zones}
                selectedZone={l10.selectedZone}
                detailMode={l10.detailMode}
                onZoneClick={(zoneId: string) => l10.setSelectedZone(zoneId)}
              />

              {/* Intelligence Legend overlay */}
              {l10.data && l10.activeSurface && (
                <IntelligenceLegend
                  mode={l10.activeMode}
                  groundingClass={l10.activeSurface.grounding_class}
                  valueRange={valueRange}
                  histogram={l10.activeHistogram}
                  confidenceScore={l10.data.quality.reliability_score}
                />
              )}

              {/* Zone Inspector overlay — fully grounded in L10 data */}
              {selectedZoneData && (
                <ZoneInspector
                  zone={selectedZoneData}
                  onClose={() => l10.setSelectedZone(null)}
                />
              )}
            </div>

            {/* Quicklook strip */}
            {l10.data && (
              <div className="px-3 border-t border-slate-800/50">
                <QuicklookStrip
                  data={l10.data}
                  activeMode={l10.activeMode}
                  onModeChange={l10.setActiveMode}
                />
              </div>
            )}

            {/* Histogram drawer */}
            {l10.data && l10.activeHistogram && (
              <div className="border-t border-slate-800/50">
                <HistogramDrawer
                  histogram={l10.activeHistogram}
                  delta={l10.activeDelta}
                  colors={l10.activeColors}
                  expanded={l10.histogramExpanded}
                  onToggle={() => l10.setHistogramExpanded(!l10.histogramExpanded)}
                  surfaceLabel={MODE_CONFIG[l10.activeMode].label}
                />
              </div>
            )}
          </div>
        )}

        {/* COL 2: AI Advisor (1/3 Width) */}
        <div className="h-full">
          <AgriBrainChat 
            context={context}
          />
        </div>
      </div>

      {/* Bottom Analysis Strip */}
      {l10.data && (
        <AnalysisStrip
          data={l10.data}
          activeMode={l10.activeMode}
        />
      )}

      {/* Error banner */}
      {l10.error && (
        <div className="bg-red-900/20 border border-red-800/30 rounded-lg px-4 py-2 text-sm text-red-400">
          ⚠️ Layer 10: {l10.error}
        </div>
      )}
    </div>
  );
}
