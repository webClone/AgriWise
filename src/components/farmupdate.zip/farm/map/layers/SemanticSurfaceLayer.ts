"use client";

import { BitmapLayer } from "@deck.gl/layers";
import { SurfaceData } from "@/hooks/useLayer10";
import { buildPolygonMask } from "../utils/buildPolygonMask";

// A small helper to draw the surface data array into a Canvas data URI
// This avoids needing an external image tile server for the MVP Layer 10
function createSurfaceImage(
  plotId: string | undefined,
  surface: SurfaceData | null | undefined, 
  colors: [string, string, string] | null | undefined,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  plotGeoJson: any,
  confidenceSurface: SurfaceData | null | undefined,
  opacity: number = 0.85,
  detailMode: "farmer" | "expert" = "farmer",
  quantizeBands: number | null = null,
  layerMode: string = "vegetation"
): ImageData | null {
  if (!surface || !plotGeoJson) return null;
  const h = surface.values.length;
  if (h === 0) return null;
  const w = surface.values[0].length;
  if (w === 0) return null;

  // 1. We don't need a canvas, we can create ImageData directly
  const imgData = new ImageData(w, h);
  
  // 2. Parse Hex colors
  const hexToRgb = (hex: string) => {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
      r: parseInt(result[1], 16),
      g: parseInt(result[2], 16),
      b: parseInt(result[3], 16)
    } : { r: 0, g: 0, b: 0 };
  };
  
  const MODE_RAMPS: Record<string, {low: number[], mid: number[], high: number[]}> = {
    vegetation: { low: [170, 35, 20], mid: [230, 200, 40], high: [40, 150, 55] },
    water_stress: { low: [30, 140, 90], mid: [245, 190, 40], high: [190, 40, 35] },
    nutrient_risk: { low: [50, 150, 55], mid: [240, 210, 50], high: [210, 120, 20] },
    composite_risk: { low: [40, 155, 65], mid: [240, 170, 30], high: [200, 30, 35] },
    uncertainty: { low: [40, 140, 150], mid: [120, 120, 150], high: [180, 180, 190] },
  };

  const safeMode = layerMode && MODE_RAMPS[layerMode.toLowerCase()] ? layerMode.toLowerCase() : "vegetation";
  const overrideRamp = MODE_RAMPS[safeMode];

  const cLow = overrideRamp ? { r: overrideRamp.low[0], g: overrideRamp.low[1], b: overrideRamp.low[2] } : hexToRgb(colors?.[0] || "#000000");
  const cMid = overrideRamp ? { r: overrideRamp.mid[0], g: overrideRamp.mid[1], b: overrideRamp.mid[2] } : hexToRgb(colors?.[1] || "#000000");
  const cHigh = overrideRamp ? { r: overrideRamp.high[0], g: overrideRamp.high[1], b: overrideRamp.high[2] } : hexToRgb(colors?.[2] || "#000000");

  // Use the extracted and cached polygon mask
  const mask = buildPolygonMask(plotId, w, h, plotGeoJson);

  // 2b. Compute Render Range mapping (OneSoil-style per-field contrast stretch)
  let [minV, maxV] = surface.render_range || [0, 1];
  
  // Gather valid values strictly within the plot boundary to compute local percentiles
  const validVals: number[] = [];
  let statPtr = 0;
  for (let r = 0; r < h; r++) {
    for (let c = 0; c < w; c++) {
      const val = surface.values[r][c];
      if (val !== null && val !== undefined && !isNaN(val) && (!mask || mask.data[statPtr] === 1)) {
        validVals.push(val);
      }
      statPtr++;
    }
  }

  // Apply P02 - P98 stretch to maximize intra-field contrast and ignore outliers (Farmer)
  // Or P01 - P99 stretch for highest detail (Expert)
  if (validVals.length > 10) {
    validVals.sort((a, b) => a - b);
    const bottomSlice = detailMode === "expert" ? 0.01 : 0.02;
    const topSlice = detailMode === "expert" ? 0.99 : 0.98;
    const p02 = validVals[Math.floor(validVals.length * bottomSlice)];
    const p98 = validVals[Math.floor(validVals.length * topSlice)];
    // Only override if the local contrast is meaningful
    if (p98 > p02) {
      minV = p02;
      maxV = p98;
    }
  }

  const range = maxV - minV === 0 ? 1 : maxV - minV;
  const clamp = (num: number, min: number, max: number) => Math.min(Math.max(num,min),max);

  // 3. Write pixels
  let ptr = 0;
  let maskPtr = 0;
  for (let r = 0; r < h; r++) {
    for (let c = 0; c < w; c++) {
      const val = surface.values[r][c];
      if (val === null || val === undefined || isNaN(val) || (mask && mask.data[maskPtr] === 0)) {
        // Transparent nodata or outside field polygon
        imgData.data[ptr++] = 0;
        imgData.data[ptr++] = 0;
        imgData.data[ptr++] = 0;
        imgData.data[ptr++] = 0;
      } else {
        // Normalize value across the dynamic 3-stop ramp range exactly as prescribed
        let t = clamp((val - minV) / range, 0, 1);
        
        // Quantize into crisp visual bands if enforced by policy
        const useQuantization = typeof quantizeBands === "number" && quantizeBands > 1;
        if (useQuantization) {
          const bands = quantizeBands;
          t = Math.min(Math.floor(t * bands), bands - 1) / (bands - 1);
        }
        
        // Base Color Generation
        let rawR, rawG, rawB;
        if (t <= 0.5) {
          const t1 = t * 2.0; 
          rawR = cLow.r + (cMid.r - cLow.r) * t1;
          rawG = cLow.g + (cMid.g - cLow.g) * t1;
          rawB = cLow.b + (cMid.b - cLow.b) * t1;
        } else {
          const t2 = (t - 0.5) * 2.0;
          rawR = cMid.r + (cHigh.r - cMid.r) * t2;
          rawG = cMid.g + (cHigh.g - cMid.g) * t2;
          rawB = cMid.b + (cHigh.b - cMid.b) * t2;
        }

        // Confidence tracking
        let trust = 1.0;
        if (confidenceSurface && confidenceSurface.values[r]?.[c] !== undefined) {
           const conf = confidenceSurface.values[r][c];
           if (conf !== null && !isNaN(conf)) {
              trust = conf;
           }
        }

        // Saturation scaling (grey out low trust zones if in expert view)
        const satScale = 0.75 + 0.25 * trust;
        // Simple luminance approx
        const lum = 0.299 * rawR + 0.587 * rawG + 0.114 * rawB;

        imgData.data[ptr++] = Math.round(lum + (rawR - lum) * satScale);
        imgData.data[ptr++] = Math.round(lum + (rawG - lum) * satScale);
        imgData.data[ptr++] = Math.round(lum + (rawB - lum) * satScale);
        
        const pixelAlpha = opacity * (0.3 + 0.7 * trust);
        imgData.data[ptr++] = Math.round(pixelAlpha * 255);
      }
      maskPtr++;
    }
  }
  return imgData;
}

/**
 * Creates a standard DeckGL BitmapLayer that maps the 2D surface raster
 * perfectly over the Plot bounds.
 */
export function getSemanticSurfaceLayerLayer({
  id = "semantic-surface",
  plotId,
  surfaceData,
  surfaceColors,
  plotGeoJson,
  confidenceSurface,
  opacity = 0.85,
  detailMode = "farmer",
  quantizeBands = null,
  mode = "vegetation",
  visible = true
}: {
  id?: string;
  plotId?: string;
  surfaceData?: SurfaceData | null;
  surfaceColors?: [string, string, string] | null;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  plotGeoJson?: any;
  confidenceSurface?: SurfaceData | null;
  opacity?: number;
  detailMode?: "farmer" | "expert";
  quantizeBands?: number | null;
  mode?: string;
  visible?: boolean;
}) {
  if (!visible || !surfaceData || !plotGeoJson) return null;

  // DeckGL requires bounds as [minLng, minLat, maxLng, maxLat] for BitmapLayer
  // Extract BBox from GeoJSON
  let minLng = Infinity, maxLng = -Infinity, minLat = Infinity, maxLat = -Infinity;
  const coords = plotGeoJson.geometry.type === 'MultiPolygon' 
    ? plotGeoJson.geometry.coordinates[0][0] 
    : plotGeoJson.geometry.coordinates[0];
  
  coords.forEach((c: number[]) => {
    if (c[0] < minLng) minLng = c[0];
    if (c[0] > maxLng) maxLng = c[0];
    if (c[1] < minLat) minLat = c[1];
    if (c[1] > maxLat) maxLat = c[1];
  });

  const bounds: [number, number, number, number] = [minLng, minLat, maxLng, maxLat];
  const imageUrl = createSurfaceImage(plotId, surfaceData, surfaceColors, plotGeoJson, confidenceSurface, opacity, detailMode, quantizeBands, mode);

  if (!imageUrl) return null;

  return new BitmapLayer({
    id,
    bounds,
    image: imageUrl,
    opacity: 1, // handled inside canvas gen
    pickable: true,
    // DeckGL uses linear resampling by default when spanning a bitmap across coordinates.
    // This gives us the bilinear smoothing for free without manual canvas gymnastics.
    textureParameters: {
      minFilter: "linear",
      magFilter: "linear"
    }
  });
}
