import { GeoJsonLayer } from "@deck.gl/layers";
import { PathStyleExtension } from "@deck.gl/extensions";
import { DeckZoneFeature } from "./zoneUtils";

function getTrustColor(severity: number, isLine: boolean = false): [number, number, number] {
  const rgb: [number, number, number] = isLine ? [139, 92, 246] : [167, 139, 250]; // Violet
  if (severity < 0.3) {
    return [Math.min(255, rgb[0] + 40), Math.min(255, rgb[1] + 40), Math.min(255, rgb[2] + 40)];
  }
  return rgb;
}

export function getTrustZoneLayer({
  id = "trust-zones",
  featureCollection,
  visible = true,
  onHover,
  onClick
}: {
  id?: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  featureCollection: any;
  visible?: boolean;
  onHover?: (info: { object?: DeckZoneFeature }) => void;
  onClick?: (info: { object?: DeckZoneFeature }) => void;
}) {
  if (!visible || !featureCollection) return null;

  const data = {
    ...featureCollection,
    features: featureCollection.features.filter((f: DeckZoneFeature) => f.properties.zoneFamily === "trust")
  };
  if (data.features.length === 0) return null;

  return new GeoJsonLayer({
    id,
    data,
    pickable: true,
    stroked: true,
    filled: true,
    extruded: false,
    lineWidthScale: 1,
    lineWidthMinPixels: 2, 
    
    // Hatched/dashed look for trust verification zones
    extensions: [new PathStyleExtension({ dash: true })],
    getDashArray: [4, 4],
    dashJustified: true,
    
    getFillColor: (f: unknown) => {
      const feat = f as DeckZoneFeature;
      const severity = feat.properties.severity || 0;
      const isSelected = feat.properties.isSelected;
      
      const basergb = getTrustColor(severity, false);
      const alpha = isSelected ? 100 : 20 + (severity * 20); // Much more ghostly than diagnostic
      return [...basergb, alpha] as [number, number, number, number];
    },
    
    getLineColor: (f: unknown) => {
      const feat = f as DeckZoneFeature;
      const severity = feat.properties.severity || 0;
      const isSelected = feat.properties.isSelected;
      
      const basergb = getTrustColor(severity, true);
      const alpha = isSelected ? 255 : 150 + (severity * 50);
      return feat.properties.hasSourceDominance && !isSelected 
        ? [0, 200, 255, 255] 
        : [...basergb, Math.min(255, alpha)] as [number, number, number, number];
    },
    
    getLineWidth: (f: unknown) => {
        const feat = f as DeckZoneFeature;
        return feat.properties.isSelected ? 4 : 2;
    },

    onHover,
    onClick,
    
    transitions: {
      getFillColor: 300,
      getLineColor: 300,
      getLineWidth: 300
    }
  });
}
