import { ZoneData } from "@/hooks/useLayer10";

export interface DeckZoneFeature {
  type: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  geometry: any;
  properties: {
    zoneId: string;
    zoneType: string;
    zoneFamily: "diagnostic" | "action" | "trust";
    severity: number;
    confidence: number;
    topDrivers: string[];
    isSelected: boolean;
    hasSourceDominance: boolean;
    areaFraction: number;
    isInferred: boolean;
    calculationTrace?: Record<string, unknown>;
  };
}

export function categorizeZoneFamily(zoneType: string): "diagnostic" | "action" | "trust" {
  const t = zoneType.toLowerCase();
  
  if (t.includes("uncertain") || t.includes("verify") || t.includes("trust")) {
    return "trust";
  }
  
  if (t.includes("action") || t.includes("improve") || t.includes("intervene")) {
    return "action";
  }
  
  return "diagnostic";
}

export function cellIndicesToPolygon(
  cellIndices: [number, number][],
  gridH: number,
  gridW: number,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  plotGeoJson: any
): [number, number][] {
  if (cellIndices.length === 0 || !plotGeoJson) return [];

  // Extract coords for bounding box
  const coords = plotGeoJson.geometry.type === 'MultiPolygon'
    ? plotGeoJson.geometry.coordinates[0][0]
    : plotGeoJson.geometry.coordinates[0];

  let minLng = Infinity, maxLng = -Infinity, minLat = Infinity, maxLat = -Infinity;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  coords.forEach((c: any) => {
    if (c[0] < minLng) minLng = c[0];
    if (c[0] > maxLng) maxLng = c[0];
    if (c[1] < minLat) minLat = c[1];
    if (c[1] > maxLat) maxLat = c[1];
  });

  const latStep = (maxLat - minLat) / gridH;
  const lngStep = (maxLng - minLng) / gridW;

  let minR = Infinity, maxR = -Infinity, minC = Infinity, maxC = -Infinity;
  for (const [r, c] of cellIndices) {
    if (r < minR) minR = r;
    if (r > maxR) maxR = r;
    if (c < minC) minC = c;
    if (c > maxC) maxC = c;
  }

  const south = maxLat - (maxR + 1) * latStep;
  const north = maxLat - minR * latStep;
  const west = minLng + minC * lngStep;
  const east = minLng + (maxC + 1) * lngStep;

  // DeckGL expects GeoJSON linear rings to be counter-clockwise or clockwise closed arrays.
  return [
    [west, north],   // Top-Left
    [east, north],   // Top-Right
    [east, south],   // Bottom-Right
    [west, south],   // Bottom-Left
    [west, north]    // Close the loop
  ];
}

export function formatZoneGeoJson(
  zones: ZoneData[], 
  selectedZoneId?: string | null,
  gridH?: number,
  gridW?: number,
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  plotGeoJson?: any
) {
  const activeZones = zones.filter(z => 
    z.cell_indices && z.cell_indices.length > 0 && gridH && gridW && plotGeoJson
  );
  
  return {
    type: "FeatureCollection",
    features: activeZones.map(z => {
      const polygonCoords = cellIndicesToPolygon(z.cell_indices, gridH!, gridW!, plotGeoJson);
      
      return {
        type: "Feature",
        geometry: {
          type: "Polygon",
          coordinates: [polygonCoords]
        },
        properties: {
          zoneId: z.zone_id,
          zoneType: z.zone_type,
          zoneFamily: categorizeZoneFamily(z.zone_type),
          severity: z.severity,
          confidence: z.confidence,
          topDrivers: z.top_drivers,
          isSelected: z.zone_id === selectedZoneId,
          hasSourceDominance: !!z.source_dominance && z.source_dominance !== "Mixed",
          areaFraction: z.area_fraction,
          isInferred: !!z.is_inferred,
          calculationTrace: z.calculation_trace
        }
      };
    })
  };
}
