import { GeoJsonLayer } from "@deck.gl/layers";
import { DeckZoneFeature } from "./zoneUtils";

function getActionColor(zoneType: string, isLine: boolean = false): [number, number, number] {
  const normClass = zoneType.toLowerCase();
  
  if (normClass.includes("improve") || normClass.includes("stable") || normClass.includes("good")) {
    return isLine ? [34, 197, 94] : [74, 222, 128]; // Green
  }
  
  // Default action is Amber/Alert
  return isLine ? [245, 158, 11] : [251, 191, 36]; 
}

export function getActionZoneLayer({
  id = "action-zones",
  featureCollection,
  visible = true,
  onHover,
  onClick
}: {
  id?: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  featureCollection: any;
  visible?: boolean;
  onHover?: (info: { object?: DeckZoneFeature }) => void;
  onClick?: (info: { object?: DeckZoneFeature }) => void;
}) {
  if (!visible || !featureCollection) return null;

  const data = {
    ...featureCollection,
    features: featureCollection.features.filter((f: DeckZoneFeature) => f.properties.zoneFamily === "action")
  };
  if (data.features.length === 0) return null;

  return new GeoJsonLayer({
    id,
    data,
    pickable: true,
    stroked: true,
    filled: true,
    extruded: false,
    lineWidthScale: 1,
    lineWidthMinPixels: 3, 
    
    getFillColor: (f: unknown) => {
      const feat = f as DeckZoneFeature;
      const severity = feat.properties.severity || 0;
      const isSelected = feat.properties.isSelected;
      
      const basergb = getActionColor(feat.properties.zoneType, false);
      const alpha = isSelected ? 180 : 50 + (severity * 50); 
      return [...basergb, alpha] as [number, number, number, number];
    },
    
    getLineColor: (f: unknown) => {
      const feat = f as DeckZoneFeature;
      const severity = feat.properties.severity || 0;
      const isSelected = feat.properties.isSelected;
      
      const basergb = getActionColor(feat.properties.zoneType, true);
      const alpha = isSelected ? 255 : 200 + (severity * 55);
      return feat.properties.hasSourceDominance && !isSelected 
        ? [0, 200, 255, 255] 
        : [...basergb, Math.min(255, alpha)] as [number, number, number, number];
    },
    
    getLineWidth: (f: unknown) => {
        const feat = f as DeckZoneFeature;
        return feat.properties.isSelected ? 5 : 3;
    },

    onHover,
    onClick,
    
    transitions: {
      getFillColor: 300,
      getLineColor: 300,
      getLineWidth: 300
    }
  });
}
