import { GeoJsonLayer } from "@deck.gl/layers";
import { DeckZoneFeature } from "./zoneUtils";

function getDiagnosticColor(zoneType: string, severity: number, isLine: boolean = false): [number, number, number] {
  const normClass = zoneType.toLowerCase();
  let rgb: [number, number, number];
  
  if (normClass.includes("water") || normClass.includes("dry") || normClass.includes("moisture")) {
    rgb = isLine ? [245, 158, 11] : [251, 191, 36];
  } else if (normClass.includes("nutrient") || normClass.includes("nitrogen")) {
    rgb = isLine ? [234, 179, 8] : [250, 204, 21];
  } else if (normClass.includes("disease") || normClass.includes("pest")) {
    rgb = isLine ? [217, 70, 239] : [232, 121, 249];
  } else {
    rgb = isLine ? [239, 68, 68] : [248, 113, 113];
  }
  
  if (severity < 0.3) {
    return [Math.min(255, rgb[0] + 40), Math.min(255, rgb[1] + 40), Math.min(255, rgb[2] + 40)];
  }
  return rgb;
}

export function getDiagnosticZoneLayer({
  id = "diagnostic-zones",
  featureCollection,
  visible = true,
  onHover,
  onClick
}: {
  id?: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  featureCollection: any;
  visible?: boolean;
  onHover?: (info: { object?: DeckZoneFeature }) => void;
  onClick?: (info: { object?: DeckZoneFeature }) => void;
}) {
  if (!visible || !featureCollection) return null;

  const data = {
    ...featureCollection,
    features: featureCollection.features.filter((f: DeckZoneFeature) => f.properties.zoneFamily === "diagnostic")
  };
  if (data.features.length === 0) return null;

  return new GeoJsonLayer({
    id,
    data,
    pickable: true,
    stroked: true,
    filled: true,
    extruded: false,
    lineWidthScale: 1,
    lineWidthMinPixels: 1.5,
    
    getFillColor: (f: unknown) => {
      const feat = f as DeckZoneFeature;
      const severity = feat.properties.severity || 0;
      const isSelected = feat.properties.isSelected;
      
      const basergb = getDiagnosticColor(feat.properties.zoneType, severity, false);
      const alpha = isSelected ? 160 : 30 + (severity * 30); 
      return [...basergb, alpha] as [number, number, number, number];
    },
    
    getLineColor: (f: unknown) => {
      const feat = f as DeckZoneFeature;
      const severity = feat.properties.severity || 0;
      const isSelected = feat.properties.isSelected;
      
      const basergb = getDiagnosticColor(feat.properties.zoneType, severity, true);
      // Source dominance gets a tinted bright edge
      const alpha = isSelected ? 255 : 180 + (severity * 75);
      return feat.properties.hasSourceDominance && !isSelected 
        ? [0, 200, 255, 255] 
        : [...basergb, Math.min(255, alpha)] as [number, number, number, number];
    },
    
    getLineWidth: (f: unknown) => {
        const feat = f as DeckZoneFeature;
        return feat.properties.isSelected ? 3 : 1.5;
    },

    onHover,
    onClick,
    
    transitions: {
      getFillColor: 300,
      getLineColor: 300,
      getLineWidth: 300
    }
  });
}
