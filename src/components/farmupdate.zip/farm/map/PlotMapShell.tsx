"use client";

import { useMemo, useState, useRef, useEffect } from "react";
import Map, { Source, Layer, NavigationControl } from "react-map-gl/maplibre";
import DeckGL from "@deck.gl/react";
import "maplibre-gl/dist/maplibre-gl.css";
import { SurfaceData, ZoneData } from "@/hooks/useLayer10";
import { usePlotFit } from "./usePlotFit";
import { SCENE_PROVIDERS, SceneProfile } from "./sceneProviders";
import { buildLayerStack } from "./buildLayerStack";

interface PlotMapShellProps {
  farms: Record<string, unknown>[];
  plots: Record<string, unknown>[];
  activeMode?: string;
  cropName?: string;
  surfaceData?: SurfaceData | null;
  surfaceColors?: [string, string, string] | null;
  confidenceSurface?: SurfaceData | null;
  gridHeight?: number;
  gridWidth?: number;
  l10Zones?: ZoneData[] | null;
  selectedZone?: string | null;
  detailMode?: "farmer" | "expert";
  onZoneClick?: (zoneId: string) => void;
}



export default function PlotMapShell(props: PlotMapShellProps) {
  const {
    plots,
    activeMode,
    surfaceData,
    surfaceColors,
    confidenceSurface,
    l10Zones,
    selectedZone,
    detailMode = "farmer",
    onZoneClick
  } = props;

  const primaryPlot = plots?.[0];
  const containerRef = useRef<HTMLDivElement>(null);
  
  // 1. Establish Scene Options
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [sceneProfile, setSceneProfile] = useState<SceneProfile>("agro");

  // 2. Drive Camera using externalized Plot Fit logic
  const { viewState, setViewState, plotGeoJson, setDimensions } = usePlotFit({ primaryPlot, activeMode });

  useEffect(() => {
    if (!containerRef.current) return;
    
    const observer = new ResizeObserver((entries) => {
      const entry = entries[0];
      if (entry && entry.contentRect.width > 0 && entry.contentRect.height > 0) {
        setDimensions({ width: entry.contentRect.width, height: entry.contentRect.height });
      }
    });
    
    observer.observe(containerRef.current);
    
    return () => {
      observer.disconnect();
    };
  }, [setDimensions]);

  // 4. Build Layers dynamically using pure external helper
  const plotId = (primaryPlot?._id || primaryPlot?.id) as string | undefined;
  
  const layers = useMemo(() => buildLayerStack({
    plotId,
    activeMode,
    surfaceData,
    surfaceColors,
    confidenceSurface,
    plotGeoJson,
    l10Zones,
    selectedZone,
    detailMode,
    onZoneClick
  }), [plotId, activeMode, surfaceData, surfaceColors, confidenceSurface, plotGeoJson, l10Zones, selectedZone, detailMode, onZoneClick]);

  return (
    <div ref={containerRef} className="absolute inset-0 w-full h-full bg-slate-950 rounded-lg overflow-hidden border border-slate-800/60 shadow-inner">
      <DeckGL
        viewState={viewState}
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        onViewStateChange={({ viewState }) => setViewState(viewState as any)}
        controller={true}
        layers={layers}
        getTooltip={(info) => {
          const object = info.object as { properties: { zoneId: string; zoneType: string; confidence: number } } | undefined;
          if (!object || !object.properties) return null;
          return {
            html: `
              <div class="px-3 py-2 bg-slate-900/90 text-white rounded-md border border-slate-700 shadow-xl backdrop-blur-md">
                <div class="font-semibold text-xs text-slate-300 mb-1">Zone ${object.properties.zoneId.split('-')[0]}</div>
                <div class="font-bold capitalize text-amber-400">${object.properties.zoneType.replace(/_/g, " ")}</div>
                <div class="text-[10px] text-slate-400 mt-1 uppercase tracking-widest font-bold">Confidence: ${Math.round(object.properties.confidence * 100)}%</div>
              </div>
            `
          };
        }}
      >
        <Map
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          mapStyle={SCENE_PROVIDERS[sceneProfile] as any}
          maplibreLogo={false}
          attributionControl={false}
          interactiveLayerIds={['plot-fill-layer']}
        >
          <NavigationControl position="bottom-right" showCompass={true} />

          {/* --- MapLibre Native Vector Layers --- */}
          
          {/* Field Boundary Polygon */}
          {plotGeoJson && (
            <Source id="plot-boundary" type="geojson" data={plotGeoJson as import("geojson").Feature<import("geojson").Geometry, import("geojson").GeoJsonProperties>}>
              <Layer
                id="plot-fill-layer"
                type="fill"
                paint={{
                  'fill-color': 'transparent',
                }}
              />
              <Layer
                id="plot-outline-layer"
                type="line"
                paint={{
                  'line-color': '#eab308', // Yellow
                  'line-width': 2,
                  'line-opacity': 0.8,
                  'line-dasharray': [2, 1]
                }}
              />
            </Source>
          )}
        </Map>
      </DeckGL>
    </div>
  );
}
