import { SurfaceData, ZoneData } from "@/hooks/useLayer10";
import { getSemanticSurfaceLayerLayer } from "./layers/SemanticSurfaceLayer";
import { getContourSurfaceLayer } from "./layers/ContourSurfaceLayer";
import { getUncertaintyGridLayer } from "./layers/UncertaintyGridLayer";
import { formatZoneGeoJson } from "./layers/zones/zoneUtils";
import { getDiagnosticZoneLayer } from "./layers/zones/DiagnosticZoneLayer";
import { getActionZoneLayer } from "./layers/zones/ActionZoneLayer";
import { getTrustZoneLayer } from "./layers/zones/TrustZoneLayer";

type ViewerMode = "farmer" | "expert";

type RenderPolicy = {
  showContours: boolean;
  showUncertaintyGlyphs: boolean;
  showTrustLayer: boolean;
  maxZones: number;
  minAreaFraction: number;
  allowedZoneFamilies: Array<"diagnostic" | "action" | "trust">;
  quantizeBands: number | null;
  detailMode: "farmer" | "expert";
};

const RENDER_POLICIES: Record<string, Record<ViewerMode, RenderPolicy>> = {
  vegetation: {
    farmer: {
      showContours: false,
      showUncertaintyGlyphs: false,
      showTrustLayer: false,
      maxZones: 3,
      minAreaFraction: 0.06,
      allowedZoneFamilies: ["diagnostic"],
      quantizeBands: 5,
      detailMode: "farmer",
    },
    expert: {
      showContours: true,
      showUncertaintyGlyphs: false,
      showTrustLayer: true,
      maxZones: 8,
      minAreaFraction: 0.02,
      allowedZoneFamilies: ["diagnostic", "trust"],
      quantizeBands: null,
      detailMode: "expert",
    },
  },

  water_stress: {
    farmer: {
      showContours: false,
      showUncertaintyGlyphs: false,
      showTrustLayer: false,
      maxZones: 3,
      minAreaFraction: 0.05,
      allowedZoneFamilies: ["diagnostic", "action"],
      quantizeBands: 5,
      detailMode: "farmer",
    },
    expert: {
      showContours: false,
      showUncertaintyGlyphs: false,
      showTrustLayer: true,
      maxZones: 8,
      minAreaFraction: 0.02,
      allowedZoneFamilies: ["diagnostic", "action", "trust"],
      quantizeBands: null,
      detailMode: "expert",
    },
  },

  nutrient_risk: {
    farmer: {
      showContours: false,
      showUncertaintyGlyphs: false,
      showTrustLayer: false,
      maxZones: 3,
      minAreaFraction: 0.05,
      allowedZoneFamilies: ["diagnostic"],
      quantizeBands: 5,
      detailMode: "farmer",
    },
    expert: {
      showContours: true,
      showUncertaintyGlyphs: false,
      showTrustLayer: true,
      maxZones: 8,
      minAreaFraction: 0.02,
      allowedZoneFamilies: ["diagnostic", "trust"],
      quantizeBands: null,
      detailMode: "expert",
    },
  },
  
  composite_risk: {
    farmer: {
      showContours: false,
      showUncertaintyGlyphs: false,
      showTrustLayer: false,
      maxZones: 3,
      minAreaFraction: 0.05,
      allowedZoneFamilies: ["diagnostic", "action"],
      quantizeBands: 5,
      detailMode: "farmer",
    },
    expert: {
      showContours: false,
      showUncertaintyGlyphs: false,
      showTrustLayer: true,
      maxZones: 8,
      minAreaFraction: 0.02,
      allowedZoneFamilies: ["diagnostic", "action", "trust"],
      quantizeBands: null,
      detailMode: "expert",
    },
  },

  uncertainty: {
    farmer: {
      showContours: false,
      showUncertaintyGlyphs: false,
      showTrustLayer: true,
      maxZones: 3,
      minAreaFraction: 0.05,
      allowedZoneFamilies: ["trust"],
      quantizeBands: null,
      detailMode: "farmer",
    },
    expert: {
      showContours: false,
      showUncertaintyGlyphs: true,
      showTrustLayer: true,
      maxZones: 10,
      minAreaFraction: 0.01,
      allowedZoneFamilies: ["trust"],
      quantizeBands: null,
      detailMode: "expert",
    },
  },
};

interface BuildLayerStackOptions {
  plotId?: string;
  activeMode?: string;
  surfaceData?: SurfaceData | null;
  surfaceColors?: [string, string, string] | null;
  confidenceSurface?: SurfaceData | null;
  plotGeoJson?: GeoJSON.Feature<GeoJSON.Geometry> | null;
  l10Zones?: ZoneData[] | null;
  selectedZone?: string | null;
  detailMode?: "farmer" | "expert";
  onZoneClick?: (zoneId: string) => void;
}

export function buildLayerStack(options: BuildLayerStackOptions) {
  const {
    plotId,
    activeMode,
    surfaceData,
    surfaceColors,
    confidenceSurface,
    plotGeoJson,
    l10Zones,
    selectedZone,
    detailMode = "farmer",
    onZoneClick
  } = options;

  const defaultColors: [string, string, string] = ["#8B0000", "#FFD700", "#006400"];
  
  // Resolve Render Policy
  const safeMode = activeMode && RENDER_POLICIES[activeMode] ? activeMode : "vegetation";
  const policy = RENDER_POLICIES[safeMode][detailMode];

  // 0. Zone Rendering Policy (Phase 2H) 
  // Drop visual clutter by filtering zones specifically against the mode policy
  let visibleZones = l10Zones || [];
  
  // Map our unified category (diagnostic, action, trust) which exists in categorizedZoneFamily
  const categorizeLocal = (type: string) => {
      const t = type.toLowerCase();
      if (t.includes("uncertain") || t.includes("verify") || t.includes("trust")) return "trust";
      if (t.includes("action") || t.includes("improve") || t.includes("intervene")) return "action";
      return "diagnostic";
  };

  const ranked = visibleZones
    .filter((z) => policy.allowedZoneFamilies.includes(categorizeLocal(z.zone_type)))
    .filter((z) => z.area_fraction >= policy.minAreaFraction || z.zone_id === selectedZone)
    .sort((a, b) => {
      const aScore = (a.severity ?? 0) * (a.area_fraction ?? 0);
      const bScore = (b.severity ?? 0) * (b.area_fraction ?? 0);
      return bScore - aScore;
    });

  visibleZones = ranked.slice(0, policy.maxZones);
  
  if (selectedZone && !visibleZones.some(z => z.zone_id === selectedZone)) {
      const selected = ranked.find(z => z.zone_id === selectedZone);
      if (selected) visibleZones.push(selected);
  }

  // Build base GeoJSON shared across the 3 semantic zone layers
  const featureCollection = visibleZones.length > 0 
    ? formatZoneGeoJson(
        visibleZones, 
        selectedZone, 
        surfaceData?.values?.length || 8, 
        surfaceData?.values?.[0]?.length || 8, 
        plotGeoJson
      )
    : null;

  return [
    // 1. Base Intelligence Surface (Raster mapped to bounds)
    getSemanticSurfaceLayerLayer({
      id: "l10-surface-base",
      plotId,
      surfaceData: surfaceData,
      surfaceColors: surfaceColors || defaultColors,
      plotGeoJson: plotGeoJson || undefined,
      confidenceSurface: confidenceSurface || undefined,
      opacity: 0.85,
      detailMode: policy.detailMode,
      quantizeBands: policy.quantizeBands,
      mode: activeMode
    }),
    
    // 2. Intelligence Topography (Contours for vegetation to differentiate visual grammar)
    surfaceData?.type === "NDVI_CLEAN" || surfaceData?.type === "NUTRIENT_DEFICIENCY" 
      ? getContourSurfaceLayer({
          id: "l10-surface-contours",
          plotId,
          surfaceData: surfaceData,
          plotGeoJson: plotGeoJson || undefined,
          visible: policy.showContours
        }) 
      : null,
      
    // 3. Secondary Evidence (Uncertainty Grid overlaid on any surface if confidence drops)
    activeMode === 'UNCERTAINTY' || activeMode === 'INSPECTION'
      ? getUncertaintyGridLayer({ // NOTE: Tomorrow this becomes TrustFogLayer
          id: "l10-uncertainty-markers",
          plotId,
          confidenceSurface: confidenceSurface || undefined,
          plotGeoJson: plotGeoJson || undefined,
          visible: policy.showUncertaintyGlyphs
        })
      : null,
    
    // 4. Semantic Zone Layers (Vector over Raster) - Split into explicit grammars
    getDiagnosticZoneLayer({
      id: "l10-diagnostic-zones",
      featureCollection,
      visible: policy.allowedZoneFamilies.includes("diagnostic"),
      onHover: () => {},
      onClick: (info: { object?: { properties: { zoneId: string } } }) => {
        if (info.object && onZoneClick) {
          onZoneClick(info.object.properties.zoneId);
        }
      }
    }),
    
    getActionZoneLayer({
      id: "l10-action-zones",
      featureCollection,
      visible: policy.allowedZoneFamilies.includes("action"),
      onHover: () => {},
      onClick: (info: { object?: { properties: { zoneId: string } } }) => {
        if (info.object && onZoneClick) {
          onZoneClick(info.object.properties.zoneId);
        }
      }
    }),
    
    getTrustZoneLayer({
      id: "l10-trust-zones",
      featureCollection,
      visible: policy.showTrustLayer || policy.allowedZoneFamilies.includes("trust"),
      onHover: () => {},
      onClick: (info: { object?: { properties: { zoneId: string } } }) => {
        if (info.object && onZoneClick) {
          onZoneClick(info.object.properties.zoneId);
        }
      }
    })
  ].filter(Boolean);
}
