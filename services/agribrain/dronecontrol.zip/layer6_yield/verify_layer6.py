"""
Verification Script for Layer 6 (Yield & Economics)
Tests Yield Prediction, Harvest Logic, and Profit Stats.
"""

import sys
import os
import pandas as pd
import numpy as np
from datetime import datetime

# Add services directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

def test_layer6():
    print("🧪 Starting Layer 6 Verification...")
    results = {}
    
    # 1. Yield Forecast
    try:
        from layer6_yield.yield_forecast import yield_engine
        print("✅ Import: Yield Engine")
        
        # Scenario: High Biomass (20t/ha), but moderate Water Stress (20% loss)
        stress_factors = {
            "water_loss_factor": 0.2,
            "nutrient_loss_factor": 0.05,
            "disease_loss_factor": 0.0
        }
        confidence = {"biomass": 0.9, "stress": 0.8}
        
        pred = yield_engine.predict_yield(
            "tomato", 
            final_biomass_kg_ha=20000, 
            cumulative_stress=stress_factors, 
            confidence_scores=confidence,
            input_hash="abc1234"
        )
        
        # Check Trust Tier and Intervals
        if "trust_tier" in pred and pred["trust_tier"] == "High":
             results['yield_pred'] = f"SUCCESS (Trust: {pred['trust_tier']}, P10-P90: {pred['yield_p10']}-{pred['yield_p90']}t)"
        else:
             results['yield_pred'] = f"FAILED (Trust: {pred.get('trust_tier')})"
             
    except Exception as e:
        results['yield_pred'] = f"ERROR: {e}"

    # 2. Harvest Optimizer
    try:
        from layer6_yield.harvest_optimizer import harvest_engine
        print("✅ Import: Harvest Optimizer")
        
        # Forecast: Rain on Day 1, Clear on Day 3
        forecast = [
            {"precip_mm": 15, "temp_max": 20}, # Bad
            {"precip_mm": 5, "temp_max": 22},  # Marginally Bad
            {"precip_mm": 0, "temp_max": 24},  # Good
            {"precip_mm": 0, "temp_max": 25},
            {"precip_mm": 0, "temp_max": 25},
            {"precip_mm": 0, "temp_max": 25},
            {"precip_mm": 0, "temp_max": 25},
        ]
        
        advice = harvest_engine.optimize_window(
            datetime(2023, 9, 1), 
            "maturity", 
            forecast, 
            disease_risk_prob=10
        )
        
        if advice["action"] == "harvest" and advice["window_start"] == "2023-09-03":
             results['harvest_opt'] = f"SUCCESS (Picked clear window starting {advice['window_start']})"
        else:
             results['harvest_opt'] = f"FAILED (Advice: {advice})"
             
    except Exception as e:
        results['harvest_opt'] = f"ERROR: {e}"

    # 3. Profitability
    try:
        from layer6_yield.profitability import profit_engine
        print("✅ Import: Profitability Calculator")
        
        # Gross Margin
        prof = profit_engine.calculate_profit(yield_mean_t_ha=10.0, price_per_ton=150.0, input_costs_per_ha=1000.0)
        
        if prof["profit_usd_ha"] == 500.0:
             results['profitability'] = f"SUCCESS (Profit: ${prof['profit_usd_ha']}, ROI: {prof['roi_pct']}%)"
        else:
             results['profitability'] = f"FAILED (Profit: {prof['profit_usd_ha']})"
             
        # Intervention ROI
        interv = profit_engine.evaluate_intervention(cost_of_action=50, expected_yield_gain_t=0.5, price_per_ton=150)
        # Gain: 0.5 * 150 = $75. Cost $50. Net +25.
        if interv["is_viable"]:
             results['intervention_roi'] = f"SUCCESS (Net Benefit: ${interv['net_benefit']})"
        else:
             results['intervention_roi'] = "FAILED"
             
    except Exception as e:
        results['profitability'] = f"ERROR: {e}"

    print("\n--- Summary ---")
    for k, v in results.items():
        print(f"{k.upper()}: {v}")
        
    return results

if __name__ == "__main__":
    test_layer6()
