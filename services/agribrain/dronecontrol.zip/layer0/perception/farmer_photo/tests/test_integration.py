"""
Farmer Photo Integration Tests

Verifies:
  - Field photo → packets emitted with FARMER_PHOTO source
  - Non-field photo → zero packets
  - All packets have "point" scope (never "plot")
  - Packets have uncertainty (sigma > 0)
  - End-to-end: input → engine → packets → Kalman observations
  - Legacy path still works
  - Semantics definitions present
"""

import unittest
from datetime import datetime

from services.agribrain.layer0.perception.farmer_photo.engine import FarmerPhotoEngine
from services.agribrain.layer0.perception.farmer_photo.schemas import (
    FarmerPhotoEngineInput, SceneClass,
)
from services.agribrain.layer0.perception.farmer_photo.semantics import (
    VARIABLE_SEMANTICS, get_semantics,
)
from services.agribrain.layer0.observation_packet import ObservationPacket, ObservationSource
from services.agribrain.layer0.perception_to_kalman import packets_to_kalman_observations


def _make_field_input(**overrides):
    """Create a standard green field photo input."""
    defaults = dict(
        plot_id="test_plot_001",
        timestamp=datetime(2026, 4, 20, 14, 0),
        image_ref="test://field_photo",
        image_content_hash="field_photo_hash_abc",
        image_width=3000,
        image_height=4000,
        gps_lat=34.0,
        gps_lng=-1.5,
        plot_centroid_lat=34.0,
        plot_centroid_lng=-1.5,
        pixel_stats={
            "green_ratio": 0.48,
            "brightness_mean": 120,
            "brightness_std": 42,
            "saturation_mean": 120,
            "laplacian_var": 120,
            "red_ratio": 0.26,
            "blue_ratio": 0.26,
        },
    )
    defaults.update(overrides)
    return FarmerPhotoEngineInput(**defaults)


def _make_indoor_input():
    """Create a non-field (indoor) photo input."""
    return FarmerPhotoEngineInput(
        plot_id="test_plot_001",
        timestamp=datetime(2026, 4, 20, 14, 0),
        image_ref="test://indoor_photo",
        image_content_hash="indoor_hash_xyz",
        image_width=2000,
        image_height=1500,
        pixel_stats={
            "green_ratio": 0.08,
            "brightness_mean": 190,
            "brightness_std": 15,
            "saturation_mean": 12,
            "red_ratio": 0.45,
            "blue_ratio": 0.47,
        },
    )


class TestFieldPhotoPackets(unittest.TestCase):
    """Test that field photos produce valid ObservationPackets."""

    def test_field_photo_produces_packets(self):
        """A valid field photo should produce at least one packet."""
        engine = FarmerPhotoEngine()
        inp = _make_field_input()
        packets = engine.process(inp)
        self.assertGreater(len(packets), 0)

    def test_packets_have_farmer_photo_source(self):
        """All packets should have FARMER_PHOTO source."""
        engine = FarmerPhotoEngine()
        inp = _make_field_input()
        packets = engine.process(inp)
        for pkt in packets:
            self.assertEqual(pkt.source, ObservationSource.FARMER_PHOTO)

    def test_all_packets_have_point_scope(self):
        """ALL farmer photo packets must have geometry_scope='point'."""
        engine = FarmerPhotoEngine()
        inp = _make_field_input()
        result = engine.process_full(inp)
        self.assertIsNotNone(result)
        output, packets = result
        self.assertEqual(output.geometry_scope, "point")

    def test_packets_have_uncertainty(self):
        """Every packet must have non-zero sigma."""
        engine = FarmerPhotoEngine()
        inp = _make_field_input()
        packets = engine.process(inp)
        for pkt in packets:
            if hasattr(pkt, 'uncertainty') and pkt.uncertainty:
                for var, sigma in pkt.uncertainty.sigmas.items():
                    self.assertGreater(sigma, 0.0)

    def test_packets_have_provenance(self):
        """Packets should have processing chain provenance."""
        engine = FarmerPhotoEngine()
        inp = _make_field_input()
        packets = engine.process(inp)
        for pkt in packets:
            if hasattr(pkt, 'provenance') and pkt.provenance:
                self.assertGreater(len(pkt.provenance.processing_chain), 0)


class TestNonFieldRejection(unittest.TestCase):
    """Test that non-field images produce zero packets."""

    def test_indoor_photo_zero_packets(self):
        """Indoor / non-field photo should produce zero packets."""
        engine = FarmerPhotoEngine()
        inp = _make_indoor_input()
        packets = engine.process(inp)
        self.assertEqual(len(packets), 0)

    def test_indoor_photo_scene_class(self):
        """Indoor photo should be classified as NON_FIELD."""
        engine = FarmerPhotoEngine()
        inp = _make_indoor_input()
        result = engine.process_full(inp)
        self.assertIsNotNone(result)
        output, packets = result
        self.assertEqual(output.scene_class, SceneClass.NON_FIELD)

    def test_invalid_input_returns_none(self):
        """Missing required fields should return None."""
        engine = FarmerPhotoEngine()
        inp = FarmerPhotoEngineInput(plot_id="bad")
        result = engine.process_full(inp)
        self.assertIsNone(result)


class TestEndToEnd(unittest.TestCase):
    """Test the complete pipeline: input → engine → packets → Kalman."""

    def test_full_pipeline_to_kalman(self):
        """Field photo → ObservationPackets → KalmanObservations."""
        engine = FarmerPhotoEngine()
        inp = _make_field_input()
        packets = engine.process(inp)

        self.assertGreater(len(packets), 0)

        kalman_obs = packets_to_kalman_observations(packets)
        self.assertGreater(len(kalman_obs), 0)
        for obs in kalman_obs:
            self.assertTrue(obs.obs_type)
            self.assertGreater(obs.sigma, 0.0)

    def test_full_output_has_classifications(self):
        """process_full() should return all classification results."""
        engine = FarmerPhotoEngine()
        inp = _make_field_input()
        result = engine.process_full(inp)

        self.assertIsNotNone(result)
        output, packets = result

        # Scene classification
        self.assertIn(output.scene_class, {SceneClass.FIELD, SceneClass.CROP_CLOSEUP})
        # Crop classification
        self.assertIsNotNone(output.crop_class)
        # Organ classification
        self.assertIsNotNone(output.organ_class)
        # Symptom classification
        self.assertIsNotNone(output.primary_symptom)

    def test_cache_hit_returns_same_result(self):
        """Same input should return cached result."""
        engine = FarmerPhotoEngine()
        inp = _make_field_input()

        result1 = engine.process_full(inp)
        result2 = engine.process_full(inp)

        self.assertIsNotNone(result1)
        self.assertIsNotNone(result2)
        output1, _ = result1
        output2, _ = result2
        self.assertEqual(output1.crop_class, output2.crop_class)


class TestLegacyStillWorks(unittest.TestCase):
    """Verify the legacy perception path is not broken."""

    def test_legacy_packet_factory_imports(self):
        from services.agribrain.layer0.perception_packet_factory import PerceptionPacketFactory
        self.assertIsNotNone(PerceptionPacketFactory)

    def test_legacy_image_qa_imports(self):
        from services.agribrain.layer0.image_qa import ImageQAEngine
        self.assertIsNotNone(ImageQAEngine)


class TestVariableSemantics(unittest.TestCase):
    """Verify frozen variable semantics are present."""

    def test_all_v1_variables_have_semantics(self):
        expected = [
            "local_canopy_cover",
            "disease_symptom_prob",
            "local_stress_proxy",
            "phenology_stage_est",
            "plant_identity_confidence",
        ]
        for var in expected:
            sem = get_semantics(var)
            self.assertIsNotNone(sem, f"Missing semantics for '{var}'")

    def test_all_scopes_are_point(self):
        """All farmer photo variables must have scope='point'."""
        for name, sem in VARIABLE_SEMANTICS.items():
            self.assertEqual(
                sem.scope, "point",
                f"Variable '{name}' has scope '{sem.scope}', expected 'point'"
            )

    def test_disease_symptom_prob_is_weak(self):
        """disease_symptom_prob must have reliability ceiling ≤ 0.50."""
        sem = get_semantics("disease_symptom_prob")
        self.assertLessEqual(sem.reliability_ceiling, 0.50)


class TestNoDoubleCountedStress(unittest.TestCase):
    """
    REGRESSION: One photo must NOT emit two correlated stress observations.

    Before this fix, a symptomatic photo emitted both:
      - disease_symptom_prob → maps to canopy_stress
      - local_stress_proxy  → maps to canopy_stress

    That double-counted stress from the same evidence.
    Now only disease_symptom_prob is packetized.
    """

    def test_no_local_stress_proxy_in_packets(self):
        """local_stress_proxy must NOT appear as a separate packet."""
        engine = FarmerPhotoEngine()
        # Yellowed leaf — will trigger symptoms
        inp = _make_field_input(
            image_content_hash="stress_regression_test",
            user_label="leaf",
            pixel_stats={
                "green_ratio": 0.20,
                "brightness_mean": 140,
                "brightness_std": 22,
                "saturation_mean": 65,
                "laplacian_var": 100,
                "red_ratio": 0.38,
                "blue_ratio": 0.20,
            },
        )
        packets = engine.process(inp)
        variable_names = set()
        for pkt in packets:
            if hasattr(pkt, 'payload') and pkt.payload:
                for key in pkt.payload:
                    if not key.endswith("_sigma") and key not in (
                        "engine_family", "image_content_hash", "details"
                    ):
                        variable_names.add(key)
        self.assertNotIn("local_stress_proxy", variable_names,
                        "local_stress_proxy should NOT be a separate packet")

    def test_stress_observation_count(self):
        """At most ONE observation mapping to canopy_stress per photo."""
        from services.agribrain.layer0.observation_model import get_observation_model
        engine = FarmerPhotoEngine()
        inp = _make_field_input(
            image_content_hash="stress_count_test",
            user_label="leaf",
            pixel_stats={
                "green_ratio": 0.18,
                "brightness_mean": 145,
                "brightness_std": 20,
                "saturation_mean": 55,
                "laplacian_var": 90,
                "red_ratio": 0.40,
                "blue_ratio": 0.22,
            },
        )
        packets = engine.process(inp)
        kalman_obs = packets_to_kalman_observations(packets)

        # Count how many map to stress-related observation types
        stress_obs = [o for o in kalman_obs if o.obs_type in (
            "farmer_photo_symptom", "stress_proxy"
        )]
        self.assertLessEqual(len(stress_obs), 1,
                           f"Expected at most 1 stress obs, got {len(stress_obs)}")


class TestPhenologyGating(unittest.TestCase):
    """Verify phenology is suppressed for soil and weak-confidence images."""

    def test_soil_photo_no_phenology(self):
        """Soil organ type should NOT emit phenology_stage_est."""
        engine = FarmerPhotoEngine()
        inp = _make_field_input(
            image_content_hash="soil_pheno_test",
            pixel_stats={
                "green_ratio": 0.18,
                "brightness_mean": 130,
                "brightness_std": 20,
                "saturation_mean": 45,
                "laplacian_var": 60,
                "red_ratio": 0.40,
                "blue_ratio": 0.30,
            },
        )
        packets = engine.process(inp)
        phenology_packets = [
            p for p in packets
            if hasattr(p, 'payload') and "phenology_stage_est" in p.payload
        ]
        self.assertEqual(len(phenology_packets), 0,
                        "Phenology should not be emitted for soil photos")


class TestUserHintProvenance(unittest.TestCase):
    """Verify user hints are tracked in output provenance."""

    def test_crop_hint_provenance(self):
        """crop_hint should set crop_assisted_by_hint=True."""
        engine = FarmerPhotoEngine()
        inp = _make_field_input(
            image_content_hash="hint_prov_test",
            crop_hint="wheat",
        )
        result = engine.process_full(inp)
        self.assertIsNotNone(result)
        output, _ = result
        self.assertTrue(output.crop_assisted_by_hint)

    def test_user_label_provenance(self):
        """user_label should set organ_from_user_label=True."""
        engine = FarmerPhotoEngine()
        inp = _make_field_input(
            image_content_hash="label_prov_test",
            user_label="leaf",
        )
        result = engine.process_full(inp)
        self.assertIsNotNone(result)
        output, _ = result
        self.assertTrue(output.organ_from_user_label)

    def test_no_hint_provenance_false(self):
        """Without hints, provenance flags should be False."""
        engine = FarmerPhotoEngine()
        inp = _make_field_input(image_content_hash="no_hint_test")
        result = engine.process_full(inp)
        self.assertIsNotNone(result)
        output, _ = result
        self.assertFalse(output.crop_assisted_by_hint)
        self.assertFalse(output.organ_from_user_label)


class TestPacketGeometryIntegrity(unittest.TestCase):
    """Verify geometry scope and bbox metadata are populated correctly."""

    def test_farmer_photo_packets_do_not_use_source_enum_as_bbox(self):
        """Farmer photo packets must have point scope and NO bounding box metadata."""
        engine = FarmerPhotoEngine()
        inp = _make_field_input()
        packets = engine.process(inp)
        
        self.assertGreater(len(packets), 0)
        for pkt in packets:
            self.assertEqual(pkt.geometry_type, "point")
            # bbox MUST be None or a tuple. It must never be an ObservationSource enum.
            if pkt.bbox is not None:
                self.assertIsInstance(pkt.bbox, tuple)
                self.assertEqual(len(pkt.bbox), 4)

    def test_farmer_photo_packets_have_valid_geo_fields(self):
        """Ensure geo_type is correctly emitted as point for farmer photos."""
        engine = FarmerPhotoEngine()
        inp = _make_field_input()
        packets = engine.process(inp)
        for pkt in packets:
            self.assertEqual(pkt.geometry_type, "point")


class TestOutputVariablesParity(unittest.TestCase):
    """Ensure typed output variables reflect the actual packetized evidence."""

    def test_output_variables_matches_packets(self):
        engine = FarmerPhotoEngine()
        inp = _make_field_input()
        result = engine.process_full(inp)
        self.assertIsNotNone(result)
        output, packets = result
        
        # Every variable in output.variables must exist conceptually in the packet stream (based on key metrics)
        packet_types = {pkt.obs_type.value for pkt in packets}
        
        self.assertGreater(len(output.variables), 0, "output.variables should not be empty")
        
        for var in output.variables:
            # We don't map exact 1:1 string equality because packets might map `disease_symptom_prob` to `stress_proxy` via adapter,
            # but we CAN assert that `output.variables` is fully populated.
            self.assertTrue(var.name, "Variables should have names")


class TestCacheVersionInvalidation(unittest.TestCase):
    """Ensure that modifying model version drops the cache."""

    def test_cache_version_is_compound(self):
        engine = FarmerPhotoEngine()
        inp = _make_field_input(image_content_hash="version_test_1")
        
        # Initial run caches the result
        engine.process_full(inp)
        
        # Inspect cache key manually
        key = engine.cache.make_key(
            engine_family="farmer_photo",
            plot_id=inp.plot_id,
            image_content_hash="version_test_1",
            model_version=f"{engine.scene_gate.VERSION}_{engine.crop_classifier.VERSION}_{engine.organ_classifier.VERSION}_{engine.symptom_classifier.VERSION}_{engine.calibrator.VERSION}",
        )
        self.assertIsNotNone(engine.cache.get(key), "Cache should be populated with the compound model version")

try:
    import numpy as np
    import cv2
    HAS_CV2 = True
except ImportError:
    HAS_CV2 = False
import tempfile
import os

def _make_temp_image(bgr_color=(0, 255, 0), size=(300, 400)):
    img = np.zeros((size[0], size[1], 3), dtype=np.uint8)
    img[:] = bgr_color
    _, path = tempfile.mkstemp(suffix=".png")
    cv2.imwrite(path, img)
    return path

@unittest.skipIf(not HAS_CV2, "Requires OpenCV and Numpy")
class TestWorkstreamB_RealImageIngress(unittest.TestCase):
    def test_ImageLoaderExposesErrors(self):
        engine = FarmerPhotoEngine()
        inp = _make_field_input(image_ref="fake_path_that_does_not_exist.jpg")
        result = engine.process_full(inp)
        
        # QA should fail it
        self.assertIsNotNone(result)
        output, _ = result
        self.assertEqual(output.qa_score, 0.0, "load_error should force qa_score to 0.0")
        self.assertEqual(output.reliability_weight, 0.0, "load_error should force reliability to 0.0")
        self.assertTrue("LOAD_ERROR" in output.qa_flags)

    def test_ROIExtraction(self):
        engine = FarmerPhotoEngine()
        path = _make_temp_image()
        # Process manually via preprocessor to inspect PreprocessResult
        features = engine.preprocessor.preprocess(image_ref=path, image_width=400, image_height=300)
        
        self.assertTrue(features.real_image_loaded)
        self.assertIsNotNone(features.central_crop_tensor)
        self.assertIsNotNone(features.green_roi_tensor)
        
        try:
            os.remove(path)
        except OSError:
            pass  # Windows file locking

    def test_TensorNormalization(self):
        engine = FarmerPhotoEngine()
        path = _make_temp_image()
        features = engine.preprocessor.preprocess(image_ref=path, image_width=400, image_height=300)
        
        # canonical resized tensor
        t = features.resized_tensor
        self.assertEqual(t.shape, (1, 3, 224, 224))
        self.assertEqual(str(t.dtype), "float32")
        self.assertLessEqual(np.max(t), 1.0)
        self.assertGreaterEqual(np.min(t), 0.0)
        
        # normalized tensor
        t_norm = features.normalized_tensor
        self.assertEqual(t_norm.shape, (1, 3, 224, 224))
        self.assertNotEqual(np.sum(t_norm), np.sum(t)) 
        
        try:
            os.remove(path)
        except OSError:
            pass  # Windows file locking

    def test_TensorColorSpace(self):
        engine = FarmerPhotoEngine()
        # BGR red is (0, 0, 255) in OpenCV
        path = _make_temp_image(bgr_color=(0, 0, 255))
        features = engine.preprocessor.preprocess(image_ref=path, image_width=400, image_height=300)
        
        t = features.resized_tensor
        # t is RGB NCHW (1, 3, 224, 224)
        # So channel 0 (Red) should be 1.0, channels 1 and 2 should be 0.0
        self.assertAlmostEqual(t[0, 0, 112, 112], 1.0)  # R
        self.assertAlmostEqual(t[0, 1, 112, 112], 0.0)  # G
        self.assertAlmostEqual(t[0, 2, 112, 112], 0.0)  # B
        
        try:
            os.remove(path)
        except OSError:
            pass  # Windows file locking

if __name__ == "__main__":
    unittest.main()
