"""
Adversarial / anti-poisoning benchmark tests for Farmer Photo Engine.

These tests encode exact adversarial probes that exposed semantic failures
in the engine. They MUST remain green as permanent regression gates.
Any future change that breaks these tests is a semantic regression.
"""

import unittest
from datetime import datetime

from ..schemas import (
    FarmerPhotoEngineInput,
    SceneClass,
    OrganClass,
    SymptomClass,
)
from ..engine import FarmerPhotoEngine


def _px(w, h, r, g, b):
    """Create uniform synthetic pixel data."""
    return {
        "red": [[r] * w for _ in range(h)],
        "green": [[g] * w for _ in range(h)],
        "blue": [[b] * w for _ in range(h)],
    }


class TestAdversarial_IndoorGrayWall(unittest.TestCase):
    """Uniform gray indoor wall (with noise) must be rejected as non-field with zero packets."""

    @classmethod
    def setUpClass(cls):
        engine = FarmerPhotoEngine()
        inp = FarmerPhotoEngineInput(
            plot_id="adv_gray", image_ref="mock_gray.jpg",
            pixel_stats={
                "green_ratio": 0.34, "red_ratio": 0.33, "blue_ratio": 0.33,
                "brightness_mean": 150, "brightness_std": 10,
                "saturation_mean": 20, "laplacian_var": 40,
            },
        )
        cls.output, cls.packets = engine.process_full(inp)

    def test_scene_is_non_field(self):
        self.assertEqual(self.output.scene_class, SceneClass.NON_FIELD)

    def test_zero_packets(self):
        self.assertEqual(len(self.packets), 0)

    def test_zero_variables(self):
        self.assertEqual(len(self.output.variables), 0)


class TestAdversarial_BareSoil(unittest.TestCase):
    """Plain brown bare soil (even with moderate green cast) must be classified as field/soil with NO canopy or phenology."""

    @classmethod
    def setUpClass(cls):
        engine = FarmerPhotoEngine()
        inp = FarmerPhotoEngineInput(
            plot_id="adv_soil", image_ref="mock_soil.jpg",
            pixel_stats={
                "green_ratio": 0.3333, "red_ratio": 0.4545, "blue_ratio": 0.2121,
                "brightness_mean": 100, "brightness_std": 0,
                "saturation_mean": 136, "laplacian_var": 0,
            },
        )
        cls.output, cls.packets = engine.process_full(inp)
        cls.var_names = [v.name for v in cls.output.variables]

    def test_scene_is_field(self):
        self.assertIn(self.output.scene_class, (SceneClass.FIELD, "soil_scene"))

    def test_organ_is_soil(self):
        self.assertEqual(self.output.organ_class, OrganClass.SOIL)

    def test_no_canopy_packet(self):
        self.assertNotIn("local_canopy_cover", self.var_names,
                         "Bare soil must not emit canopy cover")

    def test_no_phenology_packet(self):
        self.assertNotIn("phenology_stage_est", self.var_names,
                         "Bare soil must not emit phenology")

    def test_no_symptom_packet(self):
        self.assertNotIn("disease_symptom_prob", self.var_names,
                         "Bare soil must not emit disease symptoms")


class TestAdversarial_GreenTarp(unittest.TestCase):
    """Saturated synthetic green tarp (with fold texture) must be rejected as non-field."""

    @classmethod
    def setUpClass(cls):
        engine = FarmerPhotoEngine()
        inp = FarmerPhotoEngineInput(
            plot_id="adv_tarp", image_ref="mock_tarp.jpg",
            pixel_stats={
                "green_ratio": 0.50, "red_ratio": 0.25, "blue_ratio": 0.25,
                "brightness_mean": 120, "brightness_std": 15,
                "saturation_mean": 150, "laplacian_var": 50,
            },
        )
        cls.output, cls.packets = engine.process_full(inp)

    def test_scene_is_non_field(self):
        self.assertEqual(self.output.scene_class, SceneClass.NON_FIELD)

    def test_zero_packets(self):
        self.assertEqual(len(self.packets), 0)

    def test_not_crop_closeup(self):
        self.assertNotEqual(self.output.scene_class, SceneClass.CROP_CLOSEUP,
                            "Uniform green must not be classified as crop closeup")


class TestAdversarial_PottedPlant(unittest.TestCase):
    """Gray background with green center (potted plant) must be rejected."""

    @classmethod
    def setUpClass(cls):
        engine = FarmerPhotoEngine()
        inp = FarmerPhotoEngineInput(
            plot_id="adv_pot", image_ref="mock_pot.jpg",
            pixel_stats={
                "green_ratio": 0.38, "red_ratio": 0.31, "blue_ratio": 0.31,
                "brightness_mean": 120, "brightness_std": 60,
                "saturation_mean": 35, "laplacian_var": 80,
            },
        )
        cls.output, cls.packets = engine.process_full(inp)

    def test_scene_is_non_field(self):
        self.assertEqual(self.output.scene_class, SceneClass.NON_FIELD)

    def test_zero_packets(self):
        self.assertEqual(len(self.packets), 0)


class TestAdversarial_YellowedLeaf(unittest.TestCase):
    """Yellow leaf with green strip must produce chlorosis, not spots or healthy."""

    @classmethod
    def setUpClass(cls):
        engine = FarmerPhotoEngine()
        inp = FarmerPhotoEngineInput(
            plot_id="adv_yellow", image_ref="mock_yellow.jpg",
            pixel_stats={
                "green_ratio": 0.38, "red_ratio": 0.45, "blue_ratio": 0.17,
                "brightness_mean": 140, "brightness_std": 35,
                "saturation_mean": 120, "laplacian_var": 90,
            },
            user_label="leaf",
            crop_hint="wheat",
        )
        cls.output, cls.packets = engine.process_full(inp)

    def test_scene_is_field(self):
        self.assertIn(self.output.scene_class, (SceneClass.FIELD, SceneClass.CROP_CLOSEUP))

    def test_organ_is_leaf(self):
        self.assertEqual(self.output.organ_class, OrganClass.LEAF)

    def test_symptom_is_chlorosis(self):
        self.assertEqual(self.output.primary_symptom, SymptomClass.CHLOROSIS,
                         "Yellowed leaf must detect chlorosis, not spots or healthy")

    def test_severity_above_zero(self):
        self.assertGreater(self.output.symptom_severity, 0.0)


class TestAdversarial_WrongMetadataHint(unittest.TestCase):
    """Tomato-red image with crop_hint='wheat' must NOT classify as wheat."""

    @classmethod
    def setUpClass(cls):
        engine = FarmerPhotoEngine()
        inp = FarmerPhotoEngineInput(
            plot_id="adv_meta", image_ref="mock_red.jpg",
            synthetic_pixels=_px(10, 10, 220, 40, 40),
            crop_hint="wheat",
        )
        cls.output, cls.packets = engine.process_full(inp)

    def test_crop_not_wheat(self):
        self.assertNotEqual(self.output.crop_class, "wheat",
                            "Metadata hint must not override visual evidence")

    def test_crop_is_tomato_or_unknown(self):
        self.assertIn(self.output.crop_class, ("tomato", "unknown_crop"),
                      "Red image should be classified as tomato or unknown")
