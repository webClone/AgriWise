"""
Farmer Photo Golden Scenario Tests

Pinned, deterministic scenarios that verify the entire engine pipeline
from input to observation packets.

Golden 1: Healthy canopy overhead photo
  → high local_canopy_cover, low symptom score, FIELD scene

Golden 2: Yellowed leaf closeup
  → chlorosis detected, crop_closeup scene, symptom evidence emitted

Golden 3: Indoor / non-field photo
  → zero packets, NON_FIELD scene class

Golden 4: GPS mismatch (photo far from plot)
  → packets emitted but with extreme sigma inflation

Golden 5: Bare soil photo
  → low canopy cover, SOIL organ, minimal symptom output
"""

import unittest
from datetime import datetime

from services.agribrain.layer0.perception.farmer_photo.engine import FarmerPhotoEngine
from services.agribrain.layer0.perception.farmer_photo.schemas import (
    FarmerPhotoEngineInput, SceneClass, OrganClass, SymptomClass,
)


class TestGolden1_HealthyCanopyPhoto(unittest.TestCase):
    """
    Scenario: Farmer takes a clear overhead photo of a healthy wheat canopy.

    Expected:
      - Scene = FIELD
      - High local canopy cover
      - Low or zero symptom score
      - Packets emitted with reasonable reliability
    """
    @classmethod
    def setUpClass(cls):
        engine = FarmerPhotoEngine()
        inp = FarmerPhotoEngineInput(
            plot_id="golden_1",
            timestamp=datetime(2026, 4, 20, 10, 0),
            image_ref="test://golden1_healthy_canopy",
            image_content_hash="golden1_hash",
            image_width=4000,
            image_height=3000,
            gps_lat=34.05,
            gps_lng=-1.50,
            plot_centroid_lat=34.05,
            plot_centroid_lng=-1.50,
            crop_hint="wheat",
            pixel_stats={
                "green_ratio": 0.42,
                "red_ratio": 0.28,
                "blue_ratio": 0.30,
                "brightness_mean": 115,
                "brightness_std": 25,
                "saturation_mean": 105,
                "laplacian_var": 130,
            },
        )
        cls.result = engine.process_full(inp)

    def test_result_not_none(self):
        self.assertIsNotNone(self.result)

    def test_scene_is_field(self):
        output, _ = self.result
        self.assertIn(output.scene_class, {SceneClass.FIELD, SceneClass.CROP_CLOSEUP})

    def test_packets_emitted(self):
        _, packets = self.result
        self.assertGreater(len(packets), 0)

    def test_high_canopy_cover(self):
        output, _ = self.result
        self.assertGreater(output.local_canopy_cover, 0.4)

    def test_low_symptom(self):
        output, _ = self.result
        self.assertLess(output.symptom_severity, 0.15)


class TestGolden2_YellowedLeaf(unittest.TestCase):
    """
    Scenario: Farmer photographs a yellowed wheat leaf up close.

    Expected:
      - Scene = CROP_CLOSEUP or FIELD
      - Symptom detected (chlorosis or similar)
      - Disease candidate suggested (with low confidence)
      - Severity > 0
    """
    @classmethod
    def setUpClass(cls):
        engine = FarmerPhotoEngine()
        inp = FarmerPhotoEngineInput(
            plot_id="golden_2",
            timestamp=datetime(2026, 4, 20, 11, 0),
            image_ref="test://golden2_yellowed_leaf",
            image_content_hash="golden2_hash",
            image_width=3000,
            image_height=4000,
            gps_lat=34.05,
            gps_lng=-1.50,
            plot_centroid_lat=34.05,
            plot_centroid_lng=-1.50,
            crop_hint="wheat",
            user_label="leaf",
            pixel_stats={
                "green_ratio": 0.22,
                "red_ratio": 0.38,
                "blue_ratio": 0.20,
                "brightness_mean": 145,
                "brightness_std": 20,
                "saturation_mean": 70,
                "laplacian_var": 100,
            },
        )
        cls.result = engine.process_full(inp)

    def test_result_not_none(self):
        self.assertIsNotNone(self.result)

    def test_scene_is_valid(self):
        output, _ = self.result
        self.assertIn(output.scene_class, {SceneClass.FIELD, SceneClass.CROP_CLOSEUP})

    def test_symptom_detected(self):
        output, _ = self.result
        self.assertNotEqual(output.primary_symptom, SymptomClass.HEALTHY)

    def test_severity_above_zero(self):
        output, _ = self.result
        self.assertGreater(output.symptom_severity, 0.0)

    def test_disease_confidence_capped(self):
        output, _ = self.result
        self.assertLessEqual(output.disease_confidence, 0.40)

    def test_organ_is_leaf(self):
        output, _ = self.result
        self.assertEqual(output.organ_class, OrganClass.LEAF)


class TestGolden3_IndoorNonField(unittest.TestCase):
    """
    Scenario: User accidentally uploads an indoor/office photo.

    Expected:
      - Scene = NON_FIELD
      - Zero packets — engine rejects
    """
    @classmethod
    def setUpClass(cls):
        engine = FarmerPhotoEngine()
        inp = FarmerPhotoEngineInput(
            plot_id="golden_3",
            timestamp=datetime(2026, 4, 20, 12, 0),
            image_ref="test://golden3_indoor",
            image_content_hash="golden3_hash",
            image_width=2000,
            image_height=1500,
            pixel_stats={
                "green_ratio": 0.07,
                "red_ratio": 0.45,
                "blue_ratio": 0.48,
                "brightness_mean": 200,
                "brightness_std": 12,
                "saturation_mean": 10,
                "laplacian_var": 80,
            },
        )
        cls.result = engine.process_full(inp)

    def test_result_not_none(self):
        self.assertIsNotNone(self.result)

    def test_scene_is_non_field(self):
        output, _ = self.result
        self.assertEqual(output.scene_class, SceneClass.NON_FIELD)

    def test_zero_packets(self):
        _, packets = self.result
        self.assertEqual(len(packets), 0)


class TestGolden4_GPSMismatch(unittest.TestCase):
    """
    Scenario: Photo taken far from the registered plot.

    Expected:
      - Packets emitted (not rejected — GPS missing is allowed)
      - But sigma inflation is high
      - QA score is reduced
    """
    @classmethod
    def setUpClass(cls):
        engine = FarmerPhotoEngine()
        inp = FarmerPhotoEngineInput(
            plot_id="golden_4",
            timestamp=datetime(2026, 4, 20, 13, 0),
            image_ref="test://golden4_gps_far",
            image_content_hash="golden4_hash",
            image_width=3000,
            image_height=4000,
            gps_lat=36.0,   # ~220 km from plot
            gps_lng=-1.5,
            plot_centroid_lat=34.0,
            plot_centroid_lng=-1.5,
            pixel_stats={
                "green_ratio": 0.38,
                "red_ratio": 0.30,
                "blue_ratio": 0.32,
                "brightness_mean": 120,
                "brightness_std": 28,
                "saturation_mean": 95,
                "laplacian_var": 100,
            },
        )
        cls.result = engine.process_full(inp)

    def test_result_not_none(self):
        self.assertIsNotNone(self.result)

    def test_qa_score_reduced(self):
        output, _ = self.result
        # GPS mismatch should pull QA down
        self.assertLess(output.qa_score, 0.7)

    def test_sigma_inflation_elevated(self):
        output, _ = self.result
        self.assertGreater(output.sigma_inflation, 1.0)

    def test_still_produces_packets(self):
        """GPS mismatch should NOT reject — just inflate uncertainty."""
        _, packets = self.result
        self.assertGreater(len(packets), 0)


class TestGolden5_BareSoilPhoto(unittest.TestCase):
    """
    Scenario: Photo of bare soil (pre-planting or harvested field).

    Expected:
      - Scene = FIELD
      - Organ = SOIL
      - Very low canopy cover
      - No symptom detection (organ gating suppresses it)
    """
    @classmethod
    def setUpClass(cls):
        engine = FarmerPhotoEngine()
        inp = FarmerPhotoEngineInput(
            plot_id="golden_5",
            timestamp=datetime(2026, 4, 20, 14, 0),
            image_ref="test://golden5_bare_soil",
            image_content_hash="golden5_hash",
            image_width=3000,
            image_height=4000,
            gps_lat=34.05,
            gps_lng=-1.50,
            plot_centroid_lat=34.05,
            plot_centroid_lng=-1.50,
            pixel_stats={
                "green_ratio": 0.18,
                "red_ratio": 0.40,
                "blue_ratio": 0.30,
                "brightness_mean": 130,
                "brightness_std": 20,
                "saturation_mean": 45,
                "laplacian_var": 60,
            },
        )
        cls.result = engine.process_full(inp)

    def test_result_not_none(self):
        self.assertIsNotNone(self.result)

    def test_scene_is_field(self):
        output, _ = self.result
        self.assertIn(output.scene_class, {SceneClass.FIELD, SceneClass.CROP_CLOSEUP, "soil_scene"})

    def test_organ_is_soil(self):
        output, _ = self.result
        self.assertEqual(output.organ_class, OrganClass.SOIL)

    def test_low_canopy_cover(self):
        output, _ = self.result
        self.assertLess(output.local_canopy_cover, 0.2)

    def test_no_symptom_from_soil(self):
        """Soil organ should suppress symptom classification."""
        output, _ = self.result
        self.assertEqual(output.primary_symptom, SymptomClass.HEALTHY)


if __name__ == "__main__":
    unittest.main()
