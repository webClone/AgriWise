"""
Farmer Photo Classifier Tests

Verifies:
  - Crop classifier: green field → crop class, crop hint boosts
  - Organ classifier: canopy/leaf/fruit/soil detection, user label override
  - Symptom classifier: healthy vs stressed, symptom-first scoring
  - Disease gating: weak crop ID → weak disease confidence
  - Organ gating: soil/stem → no symptoms
"""

import unittest
from services.agribrain.layer0.perception.farmer_photo.preprocess import (
    FarmerPhotoPreprocessor, PreprocessResult,
)
from services.agribrain.layer0.perception.farmer_photo.crop_classifier import CropClassifier
from services.agribrain.layer0.perception.farmer_photo.organ_classifier import OrganClassifier
from services.agribrain.layer0.perception.farmer_photo.symptom_classifier import SymptomClassifier
from services.agribrain.layer0.perception.farmer_photo.schemas import (
    CropClass, OrganClass, SymptomClass,
)


def _make_features(**overrides) -> PreprocessResult:
    """Create a PreprocessResult with sensible defaults."""
    defaults = dict(
        green_ratio=0.38,
        red_ratio=0.30,
        blue_ratio=0.32,
        brightness_mean=120.0,
        brightness_std=30.0,
        saturation_mean=95.0,
        yellow_ratio=0.0,
        brown_ratio=0.0,
        width=2000,
        height=1500,
        megapixels=3.0,
    )
    defaults.update(overrides)
    result = PreprocessResult()
    for k, v in defaults.items():
        setattr(result, k, v)
    return result


class TestCropClassifier(unittest.TestCase):
    """Test crop family classification."""

    def setUp(self):
        self.classifier = CropClassifier()

    def test_green_field_produces_crop_class(self):
        """A green field photo should produce a non-unknown crop class."""
        features = _make_features(green_ratio=0.40, saturation_mean=100)
        result = self.classifier.predict(features)
        # Should identify something — exact class depends on heuristics
        self.assertIsNotNone(result.crop_class)
        self.assertGreater(result.confidence, 0.0)

    def test_crop_hint_boosts_confidence(self):
        """Providing a crop hint should increase that crop's score."""
        features = _make_features(green_ratio=0.38)
        result_no_hint = self.classifier.predict(features)
        result_wheat = self.classifier.predict(features, crop_hint="wheat")
        # Wheat score should be higher with hint
        wheat_score_with = result_wheat.top_candidates.get(CropClass.WHEAT, 0)
        wheat_score_without = result_no_hint.top_candidates.get(CropClass.WHEAT, 0)
        self.assertGreaterEqual(wheat_score_with, wheat_score_without)

    def test_low_green_returns_unknown(self):
        """Very low green ratio → unknown crop."""
        features = _make_features(green_ratio=0.10, saturation_mean=20)
        result = self.classifier.predict(features)
        self.assertEqual(result.crop_class, CropClass.UNKNOWN)

    def test_confidence_capped_for_heuristic(self):
        """Heuristic confidence should never exceed 0.60."""
        features = _make_features(green_ratio=0.50, saturation_mean=150)
        result = self.classifier.predict(features)
        self.assertLessEqual(result.confidence, 0.60)

    def test_red_fruit_signals_tomato(self):
        """High red ratio + low green should signal tomato/fruit crop."""
        features = _make_features(red_ratio=0.45, green_ratio=0.22, saturation_mean=100)
        result = self.classifier.predict(features)
        # Should at least consider tomato
        self.assertIn(CropClass.TOMATO, result.top_candidates)


class TestOrganClassifier(unittest.TestCase):
    """Test organ/context classification."""

    def setUp(self):
        self.classifier = OrganClassifier()

    def test_high_green_detects_canopy_or_leaf(self):
        """High green + saturation → canopy or leaf."""
        features = _make_features(green_ratio=0.42, saturation_mean=110)
        result = self.classifier.predict(features)
        self.assertIn(result.organ_class, {OrganClass.CANOPY, OrganClass.LEAF, OrganClass.MIXED})

    def test_low_green_low_sat_detects_soil(self):
        """Low green, low saturation → soil."""
        features = _make_features(green_ratio=0.18, saturation_mean=40, brown_ratio=0.4)
        result = self.classifier.predict(features)
        self.assertEqual(result.organ_class, OrganClass.SOIL)

    def test_user_label_override(self):
        """User label 'leaf' should override to LEAF."""
        features = _make_features()
        result = self.classifier.predict(features, user_label="leaf")
        self.assertEqual(result.organ_class, OrganClass.LEAF)
        self.assertGreater(result.confidence, 0.0)

    def test_user_label_fruit(self):
        """User label 'fruit' should override to FRUIT."""
        features = _make_features()
        result = self.classifier.predict(features, user_label="fruit")
        self.assertEqual(result.organ_class, OrganClass.FRUIT)

    def test_confidence_capped_for_heuristic(self):
        """Heuristic organ confidence should not exceed 0.55."""
        features = _make_features(green_ratio=0.45, saturation_mean=120)
        result = self.classifier.predict(features)
        self.assertLessEqual(result.confidence, 0.55)


class TestSymptomClassifier(unittest.TestCase):
    """Test symptom-first plant stress detection."""

    def setUp(self):
        self.classifier = SymptomClassifier()

    def test_healthy_green_produces_healthy(self):
        """Healthy green image → HEALTHY as primary symptom."""
        features = _make_features(
            green_ratio=0.42, saturation_mean=100,
            yellow_ratio=0.0, brown_ratio=0.0,
        )
        result = self.classifier.predict(
            features, organ_class=OrganClass.LEAF,
        )
        self.assertEqual(result.primary_symptom, SymptomClass.HEALTHY)
        self.assertAlmostEqual(result.severity, 0.0, places=1)

    def test_yellowing_detects_chlorosis(self):
        """Yellow tones → chlorosis symptom."""
        features = _make_features(
            green_ratio=0.22, yellow_ratio=0.25,
            brightness_mean=140, saturation_mean=70,
            brown_ratio=0.0,
        )
        result = self.classifier.predict(
            features, organ_class=OrganClass.LEAF,
        )
        self.assertIn(
            result.primary_symptom,
            {SymptomClass.CHLOROSIS, SymptomClass.NECROSIS, SymptomClass.UNKNOWN_STRESS},
        )
        self.assertGreater(result.severity, 0.0)

    def test_browning_detects_necrosis(self):
        """Brown tones + low green → necrosis."""
        features = _make_features(
            green_ratio=0.18, brown_ratio=0.4,
            saturation_mean=35, brightness_mean=110,
            yellow_ratio=0.0,
        )
        result = self.classifier.predict(
            features, organ_class=OrganClass.LEAF,
        )
        self.assertTrue(result.has_symptoms)
        self.assertGreater(result.severity, 0.0)

    def test_soil_organ_suppresses_symptoms(self):
        """Soil organ type → no symptom inference, returns healthy."""
        features = _make_features(green_ratio=0.15, brown_ratio=0.5)
        result = self.classifier.predict(
            features, organ_class=OrganClass.SOIL,
        )
        self.assertEqual(result.primary_symptom, SymptomClass.HEALTHY)
        self.assertEqual(result.severity, 0.0)

    def test_stem_organ_suppresses_symptoms(self):
        """Stem organ type → suppressed."""
        features = _make_features()
        result = self.classifier.predict(
            features, organ_class=OrganClass.STEM,
        )
        self.assertEqual(result.primary_symptom, SymptomClass.HEALTHY)

    def test_weak_crop_id_downgrades_disease(self):
        """Low crop confidence → disease confidence must be very low."""
        features = _make_features(
            green_ratio=0.20, yellow_ratio=0.20,
            brightness_mean=130, saturation_mean=60,
        )
        result = self.classifier.predict(
            features,
            organ_class=OrganClass.LEAF,
            crop_class=CropClass.UNKNOWN,
            crop_confidence=0.05,  # Very weak crop ID
        )
        self.assertLessEqual(result.disease_confidence, 0.10)

    def test_strong_crop_id_allows_disease_candidate(self):
        """Decent crop confidence + symptoms → disease candidate emitted."""
        features = _make_features(
            green_ratio=0.20, yellow_ratio=0.22,
            brightness_mean=140, saturation_mean=65,
            brown_ratio=0.0,
        )
        result = self.classifier.predict(
            features,
            organ_class=OrganClass.LEAF,
            crop_class=CropClass.WHEAT,
            crop_confidence=0.45,
        )
        if result.has_symptoms:
            # Disease candidate should exist but with capped confidence
            self.assertLessEqual(result.disease_confidence, 0.40)

    def test_disease_confidence_never_exceeds_cap(self):
        """Disease confidence must never exceed 0.40 in heuristic mode."""
        features = _make_features(
            green_ratio=0.15, yellow_ratio=0.30,
            brightness_mean=150, saturation_mean=50,
            brown_ratio=0.2,
        )
        result = self.classifier.predict(
            features,
            organ_class=OrganClass.LEAF,
            crop_class=CropClass.WHEAT,
            crop_confidence=0.60,
        )
        self.assertLessEqual(result.disease_confidence, 0.40)


if __name__ == "__main__":
    unittest.main()
