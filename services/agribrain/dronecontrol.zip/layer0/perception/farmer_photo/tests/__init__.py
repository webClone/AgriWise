"""Farmer Photo test package."""
