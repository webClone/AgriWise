"""
Farmer Photo QA Tests

Verifies:
  - Clean field photo → high reliability
  - Blurry photo → BLURRY flag
  - Overexposed / underexposed → appropriate flags
  - GPS far from plot → GPS_FAR flag
  - GPS missing → moderate uncertainty
  - Non-field / indoor photo → NON_FIELD flag
  - Stale timestamp → STALE flag
  - Low resolution → LOW_RESOLUTION flag
"""

import unittest
from services.agribrain.layer0.perception.farmer_photo.qa import (
    FarmerPhotoQA, FarmerPhotoQAResult, FarmerPhotoQAFlag,
)


class TestFarmerPhotoQA(unittest.TestCase):
    """Test camera-specific QA engine."""

    def setUp(self):
        self.qa = FarmerPhotoQA()

    def test_clean_field_photo_high_reliability(self):
        """A sharp, well-exposed field photo should score well."""
        result = self.qa.assess(
            image_width=3000,
            image_height=4000,
            pixel_stats={
                "green_ratio": 0.40,
                "brightness_mean": 120,
                "brightness_std": 30,
                "saturation_mean": 100,
                "laplacian_var": 150,
            },
            gps_lat=34.0,
            gps_lng=-1.5,
            plot_centroid_lat=34.0,
            plot_centroid_lng=-1.5,
            recentness_days=0,
        )
        self.assertTrue(result.usable)
        self.assertGreater(result.qa_score, 0.7)
        self.assertGreater(result.reliability_weight, 0.5)
        self.assertIn(FarmerPhotoQAFlag.CLEAN, result.flags)

    def test_blurry_photo_flagged(self):
        """Very blurry photo should be flagged."""
        result = self.qa.assess(
            image_width=2000,
            image_height=1500,
            pixel_stats={
                "green_ratio": 0.38,
                "brightness_mean": 120,
                "saturation_mean": 90,
                "laplacian_var": 10,  # Very blurry
            },
        )
        self.assertIn(FarmerPhotoQAFlag.BLURRY, result.flags)
        self.assertLess(result.blur_score, 0.4)

    def test_overexposed_photo_flagged(self):
        """Washed-out photo should be flagged."""
        result = self.qa.assess(
            image_width=2000,
            image_height=1500,
            pixel_stats={
                "green_ratio": 0.30,
                "brightness_mean": 245,  # Very bright
                "saturation_mean": 40,
                "overexposed_pct": 35,
            },
        )
        self.assertIn(FarmerPhotoQAFlag.OVEREXPOSED, result.flags)
        self.assertLess(result.exposure_score, 0.4)

    def test_underexposed_photo_flagged(self):
        """Very dark photo should be flagged."""
        result = self.qa.assess(
            image_width=2000,
            image_height=1500,
            pixel_stats={
                "green_ratio": 0.20,
                "brightness_mean": 20,  # Very dark
                "saturation_mean": 30,
            },
        )
        self.assertIn(FarmerPhotoQAFlag.UNDEREXPOSED, result.flags)

    def test_gps_far_from_plot(self):
        """Photo GPS far from plot centroid should be flagged."""
        result = self.qa.assess(
            image_width=2000,
            image_height=1500,
            pixel_stats={"green_ratio": 0.38, "brightness_mean": 120, "saturation_mean": 90},
            gps_lat=35.0,   # ~111 km away
            gps_lng=-1.5,
            plot_centroid_lat=34.0,
            plot_centroid_lng=-1.5,
        )
        self.assertIn(FarmerPhotoQAFlag.GPS_FAR, result.flags)
        self.assertLess(result.geo_score, 0.4)

    def test_gps_missing_moderate_uncertainty(self):
        """Missing GPS should give moderate geo_score, not rejection."""
        result = self.qa.assess(
            image_width=2000,
            image_height=1500,
            pixel_stats={"green_ratio": 0.38, "brightness_mean": 120, "saturation_mean": 90},
            # No GPS
        )
        self.assertIn(FarmerPhotoQAFlag.GPS_MISSING, result.flags)
        self.assertEqual(result.geo_score, 0.5)
        # Should still be usable — not rejected
        self.assertTrue(result.usable)

    def test_non_field_indoor_photo(self):
        """Indoor / non-agricultural photo should be flagged NON_FIELD."""
        result = self.qa.assess(
            image_width=2000,
            image_height=1500,
            pixel_stats={
                "green_ratio": 0.08,      # Almost no green
                "brightness_mean": 180,
                "saturation_mean": 12,     # Very desaturated (indoor)
            },
        )
        self.assertIn(FarmerPhotoQAFlag.NON_FIELD, result.flags)
        self.assertFalse(result.usable)

    def test_stale_photo_flagged(self):
        """Old photo should be flagged STALE."""
        result = self.qa.assess(
            image_width=2000,
            image_height=1500,
            pixel_stats={"green_ratio": 0.38, "brightness_mean": 120, "saturation_mean": 90},
            recentness_days=45,
        )
        self.assertIn(FarmerPhotoQAFlag.STALE, result.flags)
        self.assertLessEqual(result.timestamp_score, 0.4)

    def test_low_resolution_flagged(self):
        """Very small image should be flagged LOW_RESOLUTION."""
        result = self.qa.assess(
            image_width=200,
            image_height=200,  # 0.04 MP
            pixel_stats={"green_ratio": 0.38, "brightness_mean": 120, "saturation_mean": 90},
        )
        self.assertIn(FarmerPhotoQAFlag.LOW_RESOLUTION, result.flags)

    def test_color_cast_flagged(self):
        """Extreme color cast should be flagged."""
        result = self.qa.assess(
            image_width=2000,
            image_height=1500,
            pixel_stats={
                "green_ratio": 0.08,      # Almost no green
                "brightness_mean": 120,
                "saturation_mean": 180,    # High saturation = color filter
            },
        )
        self.assertIn(FarmerPhotoQAFlag.COLOR_CAST, result.flags)

    def test_user_label_boosts_field_likelihood(self):
        """User labeling 'leaf' should increase field_likelihood."""
        result_no_label = self.qa.assess(
            image_width=1500,
            image_height=1500,
            pixel_stats={"green_ratio": 0.22, "brightness_mean": 100, "saturation_mean": 50},
        )
        result_with_label = self.qa.assess(
            image_width=1500,
            image_height=1500,
            pixel_stats={"green_ratio": 0.22, "brightness_mean": 100, "saturation_mean": 50},
            user_label="leaf",
        )
        self.assertGreater(
            result_with_label.field_likelihood,
            result_no_label.field_likelihood,
        )


if __name__ == "__main__":
    unittest.main()
