"""
Satellite RGB Inference Tests

Verifies:
  - Vegetation mask on green/brown mixed plots
  - Anomaly heatmap detects sparse zones
  - Canopy fraction within expected range
  - Zone aggregation produces multiple zones
  - Coarse phenology estimation
"""

import unittest
from services.agribrain.layer0.perception.satellite_rgb.preprocess import (
    SatelliteRGBPreprocessor,
)
from services.agribrain.layer0.perception.satellite_rgb.inference import (
    SatelliteRGBInference,
)


def _make_uniform_green_pixels(h, w, green_ratio=0.45):
    """Create a synthetic green field image."""
    r_val = (1.0 - green_ratio) / 2
    b_val = (1.0 - green_ratio) / 2
    g_val = green_ratio
    return {
        "red": [[r_val] * w for _ in range(h)],
        "green": [[g_val] * w for _ in range(h)],
        "blue": [[b_val] * w for _ in range(h)],
    }


def _make_mixed_pixels(h, w):
    """Create a mixed green/brown plot: top half green, bottom half brown."""
    pixels = {"red": [], "green": [], "blue": []}
    for r in range(h):
        if r < h // 2:
            # Green vegetation
            pixels["red"].append([0.2] * w)
            pixels["green"].append([0.5] * w)
            pixels["blue"].append([0.15] * w)
        else:
            # Brown soil (clearly non-vegetation)
            pixels["red"].append([0.50] * w)
            pixels["green"].append([0.20] * w)
            pixels["blue"].append([0.15] * w)
    return pixels


def _make_patchy_pixels(h, w):
    """Create a patchy field: mostly green with sparse gaps."""
    pixels = {"red": [], "green": [], "blue": []}
    for r in range(h):
        row_r, row_g, row_b = [], [], []
        for c in range(w):
            # Create sparse gaps (every 5th column in every 5th row)
            if r % 5 == 0 and c % 5 == 0:
                row_r.append(0.4)
                row_g.append(0.15)  # Very low green = gap
                row_b.append(0.1)
            else:
                row_r.append(0.2)
                row_g.append(0.5)
                row_b.append(0.15)
        pixels["red"].append(row_r)
        pixels["green"].append(row_g)
        pixels["blue"].append(row_b)
    return pixels


class TestSatelliteRGBInference(unittest.TestCase):
    """Test structural inference."""

    def setUp(self):
        self.preprocessor = SatelliteRGBPreprocessor()
        self.inference = SatelliteRGBInference()

    def test_uniform_green_high_vegetation(self):
        """A uniformly green image should have high vegetation fraction."""
        pixels = _make_uniform_green_pixels(30, 30, green_ratio=0.45)
        ctx = self.preprocessor.preprocess(30, 30, 10.0, synthetic_pixels=pixels)
        result = self.inference.run(ctx, resolution_m=10.0)

        self.assertGreater(result.vegetation_fraction, 0.5)
        self.assertLess(result.bare_soil_fraction, 0.3)
        self.assertEqual(result.canopy_density_class, "dense")

    def test_mixed_green_brown(self):
        """A half-green, half-brown plot should show ~50% vegetation."""
        pixels = _make_mixed_pixels(30, 30)
        ctx = self.preprocessor.preprocess(30, 30, 10.0, synthetic_pixels=pixels)
        result = self.inference.run(ctx, resolution_m=10.0)

        # Should be roughly split (margins for mask edges)
        self.assertGreater(result.vegetation_fraction, 0.2)
        self.assertLess(result.vegetation_fraction, 0.8)
        self.assertGreater(result.bare_soil_fraction, 0.0)

    def test_anomaly_detects_sparse_zone(self):
        """Patchy pixels should produce non-zero anomaly fraction."""
        pixels = _make_patchy_pixels(30, 30)
        ctx = self.preprocessor.preprocess(30, 30, 10.0, synthetic_pixels=pixels)
        result = self.inference.run(ctx, resolution_m=10.0)

        # Patchy areas create spatial heterogeneity → anomalies
        self.assertIsNotNone(result.anomaly_heatmap)
        # Anomaly fraction should exist (may or may not be high depending on threshold)
        self.assertGreaterEqual(result.anomaly_fraction, 0.0)

    def test_vegetation_mask_shape(self):
        """Vegetation mask should match input dimensions."""
        pixels = _make_uniform_green_pixels(20, 25)
        ctx = self.preprocessor.preprocess(25, 20, 10.0, synthetic_pixels=pixels)
        result = self.inference.run(ctx, resolution_m=10.0)

        self.assertIsNotNone(result.vegetation_mask)
        self.assertEqual(len(result.vegetation_mask), 20)  # height
        self.assertEqual(len(result.vegetation_mask[0]), 25)  # width

    def test_zone_aggregation(self):
        """Zone aggregation should produce multiple zones."""
        pixels = _make_mixed_pixels(40, 40)
        ctx = self.preprocessor.preprocess(40, 40, 10.0, synthetic_pixels=pixels)
        result = self.inference.run(ctx, resolution_m=10.0, n_zones=4)

        self.assertGreater(len(result.zone_results), 1)
        for zone in result.zone_results:
            self.assertTrue(zone.zone_id)
            self.assertGreaterEqual(zone.canopy_fraction, 0.0)
            self.assertLessEqual(zone.canopy_fraction, 1.0)

    def test_confidence_map_exists(self):
        """Confidence map should be generated."""
        pixels = _make_uniform_green_pixels(20, 20)
        ctx = self.preprocessor.preprocess(20, 20, 10.0, synthetic_pixels=pixels)
        result = self.inference.run(ctx, resolution_m=10.0)

        self.assertIsNotNone(result.confidence_map)
        self.assertEqual(len(result.confidence_map), 20)

    def test_phenology_estimation(self):
        """Coarse phenology should be within valid range."""
        pixels = _make_uniform_green_pixels(20, 20, green_ratio=0.45)
        ctx = self.preprocessor.preprocess(20, 20, 10.0, synthetic_pixels=pixels)
        result = self.inference.run(ctx, resolution_m=10.0)

        self.assertGreaterEqual(result.coarse_phenology_stage, 0.0)
        self.assertLessEqual(result.coarse_phenology_stage, 4.0)
        self.assertGreater(result.phenology_sigma, 0.5)  # Should be uncertain

    def test_feasibility_gates_block_rows(self):
        """Row detection should be blocked in V1."""
        pixels = _make_uniform_green_pixels(20, 20)
        ctx = self.preprocessor.preprocess(20, 20, 10.0, synthetic_pixels=pixels)
        result = self.inference.run(ctx, resolution_m=10.0)

        row_gates = [g for g in result.feasibility_gates if g.feature_name == "row_direction"]
        self.assertTrue(len(row_gates) > 0)
        self.assertFalse(row_gates[0].is_feasible)

    def test_empty_image_zero_confidence(self):
        """An image with no inside pixels should have zero confidence."""
        ctx = self.preprocessor.preprocess(0, 0, 10.0)
        result = self.inference.run(ctx, resolution_m=10.0)

        self.assertEqual(result.overall_confidence, 0.0)


if __name__ == "__main__":
    unittest.main()
