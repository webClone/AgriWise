"""
Satellite RGB QA Tests

Verifies:
  - Cloudy image lowers reliability
  - Stale image lowers recentness score
  - Low-resolution plot blocks row detection
  - Heavy boundary contamination lowers confidence
  - Clean image gets CLEAN flag
"""

import unittest
from services.agribrain.layer0.perception.satellite_rgb.qa import (
    SatelliteRGBQA, SatelliteRGBQAResult, SatelliteRGBQAFlag,
)


class TestSatelliteRGBQA(unittest.TestCase):
    """Test satellite-specific QA engine."""

    def setUp(self):
        self.qa = SatelliteRGBQA()

    def test_clean_image_high_reliability(self):
        """A clean, recent, high-resolution image should score well."""
        result = self.qa.assess(
            ground_resolution_m=10.0,
            image_width=200,
            image_height=200,
            cloud_estimate=0.05,
            haze_score=0.05,
            recentness_days=3,
            plot_area_ha=5.0,
            coverage_fraction=0.95,
            boundary_pixel_fraction=0.05,
        )
        self.assertTrue(result.usable)
        self.assertGreater(result.qa_score, 0.7)
        self.assertGreater(result.reliability_weight, 0.5)
        self.assertIn(SatelliteRGBQAFlag.CLEAN, result.flags)

    def test_cloudy_image_lowers_reliability(self):
        """Heavy cloud contamination should lower reliability and quality."""
        result = self.qa.assess(
            ground_resolution_m=10.0,
            image_width=200,
            image_height=200,
            cloud_estimate=0.7,  # 70% cloudy
            haze_score=0.1,
            recentness_days=3,
        )
        self.assertLessEqual(result.qa_score, 0.55)
        self.assertLess(result.reliability_weight, 0.5)
        self.assertIn(SatelliteRGBQAFlag.CLOUD_CONTAMINATED, result.flags)
        self.assertGreater(result.sigma_inflation, 1.0)

    def test_stale_image_lowers_recentness(self):
        """Old acquisition should lower recentness score."""
        result = self.qa.assess(
            ground_resolution_m=10.0,
            image_width=200,
            image_height=200,
            recentness_days=60,  # 60 days old — well past stale threshold
        )
        self.assertLessEqual(result.recentness_score, 0.5)
        self.assertIn(SatelliteRGBQAFlag.STALE, result.flags)

    def test_low_resolution_blocks_row_detection(self):
        """Resolution >2m should block row detection feasibility."""
        result = self.qa.assess(
            ground_resolution_m=10.0,  # Sentinel-2 resolution
            image_width=200,
            image_height=200,
        )
        self.assertFalse(result.resolution_sufficient_for_rows)

    def test_high_resolution_allows_row_detection(self):
        """Resolution <=2m should allow row detection feasibility."""
        result = self.qa.assess(
            ground_resolution_m=1.5,  # Sub-2m resolution
            image_width=200,
            image_height=200,
        )
        self.assertTrue(result.resolution_sufficient_for_rows)

    def test_heavy_boundary_contamination(self):
        """High boundary pixel fraction should lower confidence."""
        result = self.qa.assess(
            ground_resolution_m=10.0,
            image_width=200,
            image_height=200,
            boundary_pixel_fraction=0.6,  # 60% boundary pixels
        )
        self.assertLess(result.boundary_score, 0.5)
        self.assertIn(SatelliteRGBQAFlag.BOUNDARY_CONTAMINATED, result.flags)

    def test_very_low_resolution_near_unusable(self):
        """Resolution >30m should produce very low quality scores."""
        result = self.qa.assess(
            ground_resolution_m=40.0,  # Too coarse
            image_width=50,
            image_height=50,
        )
        self.assertLess(result.resolution_score, 0.2)

    def test_insufficient_pixels(self):
        """Tiny plot with very few pixels should be flagged."""
        result = self.qa.assess(
            ground_resolution_m=30.0,
            image_width=10,
            image_height=10,
            plot_area_ha=0.001,  # Tiny plot
        )
        self.assertIn(SatelliteRGBQAFlag.INSUFFICIENT_PIXELS, result.flags)

    def test_cloudy_but_still_georeferenced(self):
        """
        Cloudy image that is still georeferenced: should downgrade QA
        but NOT produce total failure — usable flag may still be True
        with very low reliability.
        """
        result = self.qa.assess(
            ground_resolution_m=10.0,
            image_width=200,
            image_height=200,
            cloud_estimate=0.5,  # 50% cloudy — borderline
            coverage_fraction=0.9,
            recentness_days=3,
        )
        # Should still be usable (qa_score > 0.1)
        self.assertTrue(result.usable)
        # But reliability should be reduced
        self.assertLess(result.reliability_weight, 0.7)
        self.assertGreater(result.sigma_inflation, 1.0)


if __name__ == "__main__":
    unittest.main()
