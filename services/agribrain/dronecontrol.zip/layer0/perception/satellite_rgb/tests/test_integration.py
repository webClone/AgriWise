"""
Satellite RGB Integration Tests

Verifies:
  - Packet adapter creates valid ObservationPackets
  - End-to-end: input → engine → packets → Kalman observations
  - Low-confidence satellite RGB cannot dominate state
  - Legacy path still works unchanged
  - Cache collision regression (same metadata, different image bytes → different keys)
  - Semantics definitions are present and correct
"""

import unittest
from datetime import datetime

from services.agribrain.layer0.perception.satellite_rgb.engine import SatelliteRGBEngine
from services.agribrain.layer0.perception.satellite_rgb.schemas import SatelliteRGBEngineInput
from services.agribrain.layer0.perception.satellite_rgb.semantics import (
    VARIABLE_SEMANTICS, get_semantics, assert_not_biophysical
)
from services.agribrain.layer0.perception.common.base_types import SatelliteProvider
from services.agribrain.layer0.perception.common.cache import PerceptionCache
from services.agribrain.layer0.observation_packet import ObservationPacket, ObservationSource
from services.agribrain.layer0.perception_to_kalman import packets_to_kalman_observations


def _make_test_input(
    cloud_estimate=0.05,
    resolution_m=10.0,
    recentness_days=3,
    green_ratio=0.45,
):
    """Create a standard test engine input."""
    h, w = 30, 30
    r_val = (1.0 - green_ratio) / 2
    g_val = green_ratio
    b_val = (1.0 - green_ratio) / 2

    return SatelliteRGBEngineInput(
        plot_id="test_plot_001",
        timestamp=datetime(2026, 4, 15, 10, 30),
        bbox=(-1.5, 34.0, -1.49, 34.01),
        rgb_image_ref="test://synthetic",
        plot_polygon="POLYGON((-1.5 34.0, -1.49 34.0, -1.49 34.01, -1.5 34.01, -1.5 34.0))",
        crs_or_georef="EPSG:4326",
        ground_resolution_m=resolution_m,
        image_width=w,
        image_height=h,
        provider=SatelliteProvider.SENTINEL2,
        cloud_estimate=cloud_estimate,
        recentness_days=recentness_days,
        image_content_hash="test_hash_abc123",
        synthetic_pixels={
            "red": [[r_val] * w for _ in range(h)],
            "green": [[g_val] * w for _ in range(h)],
            "blue": [[b_val] * w for _ in range(h)],
        },
    )


class TestPacketAdapter(unittest.TestCase):
    """Test that the packet adapter creates valid ObservationPackets."""

    def test_engine_produces_packets(self):
        """Engine should produce at least one ObservationPacket."""
        engine = SatelliteRGBEngine()
        inp = _make_test_input()
        packets = engine.process(inp)

        self.assertGreater(len(packets), 0)
        for pkt in packets:
            self.assertIsInstance(pkt, ObservationPacket)

    def test_packets_have_correct_source(self):
        """All packets should have SATELLITE_RGB source."""
        engine = SatelliteRGBEngine()
        inp = _make_test_input()
        packets = engine.process(inp)

        for pkt in packets:
            self.assertEqual(pkt.source, ObservationSource.SATELLITE_RGB)

    def test_packets_have_uncertainty(self):
        """Every packet must have non-zero uncertainty."""
        engine = SatelliteRGBEngine()
        inp = _make_test_input()
        packets = engine.process(inp)

        for pkt in packets:
            self.assertTrue(len(pkt.uncertainty.sigmas) > 0)
            for var, sigma in pkt.uncertainty.sigmas.items():
                self.assertGreater(sigma, 0.0)

    def test_packets_have_provenance(self):
        """Every packet must have provenance chain."""
        engine = SatelliteRGBEngine()
        inp = _make_test_input()
        packets = engine.process(inp)

        for pkt in packets:
            self.assertTrue(len(pkt.provenance.processing_chain) > 0)

    def test_packets_have_deterministic_ids(self):
        """Same input should produce same packet IDs."""
        engine = SatelliteRGBEngine()
        inp = _make_test_input()
        
        packets1 = engine.process(inp)
        engine.cache.clear()  # Clear cache to force re-computation
        packets2 = engine.process(inp)

        ids1 = sorted([p.packet_id for p in packets1])
        ids2 = sorted([p.packet_id for p in packets2])
        self.assertEqual(ids1, ids2)


class TestEndToEnd(unittest.TestCase):
    """Test the complete pipeline: input → engine → packets → Kalman."""

    def test_full_pipeline(self):
        """End-to-end: engine input → ObservationPackets → KalmanObservations."""
        engine = SatelliteRGBEngine()
        inp = _make_test_input()
        packets = engine.process(inp)

        self.assertGreater(len(packets), 0)

        # Convert to Kalman observations
        kalman_obs = packets_to_kalman_observations(packets)

        self.assertGreater(len(kalman_obs), 0)
        for obs in kalman_obs:
            self.assertTrue(obs.obs_type)
            self.assertGreater(obs.sigma, 0.0)
            self.assertGreaterEqual(obs.reliability, 0.0)
            self.assertLessEqual(obs.reliability, 1.0)

    def test_low_confidence_cannot_dominate(self):
        """
        A low-confidence satellite RGB observation should have
        high R (effective noise variance), preventing it from
        dominating the Kalman state.
        """
        engine = SatelliteRGBEngine()
        # Cloudy image → low QA
        inp = _make_test_input(cloud_estimate=0.6, recentness_days=20)
        packets = engine.process(inp)

        kalman_obs = packets_to_kalman_observations(packets)

        for obs in kalman_obs:
            # R = sigma^2 / reliability
            # Low reliability → high R → observation is down-weighted
            self.assertGreater(obs.R, 0.05)  # R should be meaningfully inflated

    def test_invalid_input_returns_empty(self):
        """Invalid input (missing mandatory fields) should return no packets."""
        engine = SatelliteRGBEngine()
        inp = SatelliteRGBEngineInput(
            plot_id="bad_plot",
            # Missing: plot_polygon, bbox, crs_or_georef, ground_resolution_m
        )
        packets = engine.process(inp)
        self.assertEqual(len(packets), 0)

    def test_full_output_has_summaries(self):
        """process_full() should return typed output with summaries."""
        engine = SatelliteRGBEngine()
        inp = _make_test_input()
        result = engine.process_full(inp)

        self.assertIsNotNone(result)
        output, packets = result
        
        # Check typed output fields
        self.assertGreater(output.vegetation_fraction, 0)
        self.assertGreaterEqual(output.bare_soil_fraction, 0)
        self.assertGreaterEqual(output.anomaly_fraction, 0)
        self.assertGreater(output.qa_score, 0)
        self.assertGreater(len(output.zone_outputs), 0)


class TestLegacyPathStillWorks(unittest.TestCase):
    """Verify the legacy perception path is not broken."""

    def test_legacy_perception_packet_factory_imports(self):
        """Legacy PerceptionPacketFactory should still be importable."""
        from services.agribrain.layer0.perception_packet_factory import PerceptionPacketFactory
        factory = PerceptionPacketFactory()
        self.assertIsNotNone(factory)

    def test_legacy_image_qa_imports(self):
        """Legacy ImageQAEngine should still be importable."""
        from services.agribrain.layer0.image_qa import ImageQAEngine
        qa = ImageQAEngine()
        self.assertIsNotNone(qa)

    def test_legacy_perception_models_import(self):
        """Legacy perception models should still be importable."""
        from services.agribrain.layer0.perception_models.inference import (
            CanopyCoverModel, PhenologyStageModel, DiseaseSymptomModel
        )
        self.assertIsNotNone(CanopyCoverModel)


class TestCacheCollisionRegression(unittest.TestCase):
    """
    Regression test: proves that the content-hash cache key prevents
    the collision bug that existed in the legacy path.

    OLD BUG: cache keyed by width + height + timestamp
             → two different images of the same size taken at the
               same time would return the SAME cached result.

    NEW BEHAVIOR: cache keyed by image_content_hash
             → different bytes → different key → no collision.
    """

    def test_same_metadata_different_bytes_different_keys(self):
        """
        Same dimensions, same timestamp, same plot, DIFFERENT image bytes
        should produce DIFFERENT cache keys.
        """
        cache = PerceptionCache()

        # Two images: same width/height/timestamp, different content hashes
        key_a = cache.make_key(
            engine_family="satellite_rgb",
            plot_id="plot_001",
            image_content_hash="hash_image_A",
            model_version="v1",
        )
        key_b = cache.make_key(
            engine_family="satellite_rgb",
            plot_id="plot_001",
            image_content_hash="hash_image_B",  # different bytes
            model_version="v1",
        )

        # MUST be different — this would have been equal in the old timestamp-keyed path
        self.assertNotEqual(key_a, key_b)

    def test_same_bytes_same_key(self):
        """
        Identical image bytes should produce the SAME cache key
        (correct caching behavior).
        """
        cache = PerceptionCache()

        key_a = cache.make_key("satellite_rgb", "plot_001", "hash_image_X", "v1")
        key_b = cache.make_key("satellite_rgb", "plot_001", "hash_image_X", "v1")

        self.assertEqual(key_a, key_b)

    def test_different_plots_different_keys(self):
        """Same image bytes for different plots must produce different keys."""
        cache = PerceptionCache()

        key_a = cache.make_key("satellite_rgb", "plot_001", "same_hash", "v1")
        key_b = cache.make_key("satellite_rgb", "plot_002", "same_hash", "v1")

        self.assertNotEqual(key_a, key_b)

    def test_different_model_versions_different_keys(self):
        """A model upgrade must invalidate the cache for the same image."""
        cache = PerceptionCache()

        key_v1 = cache.make_key("satellite_rgb", "plot_001", "same_hash", "v1")
        key_v2 = cache.make_key("satellite_rgb", "plot_001", "same_hash", "v2")

        self.assertNotEqual(key_v1, key_v2)

    def test_content_hash_from_bytes(self):
        """
        compute_content_hash() must return different hashes for different
        image bytes, even when other metadata is identical.
        """
        bytes_a = b"\x00" * 1000 + b"\x01"  # mostly zeros, one 1
        bytes_b = b"\x00" * 1000 + b"\x02"  # mostly zeros, one 2
        bytes_same = b"\x00" * 1000 + b"\x01"  # same as bytes_a

        hash_a = PerceptionCache.compute_content_hash(bytes_a)
        hash_b = PerceptionCache.compute_content_hash(bytes_b)
        hash_same = PerceptionCache.compute_content_hash(bytes_same)

        self.assertNotEqual(hash_a, hash_b)
        self.assertEqual(hash_a, hash_same)


class TestVariableSemantics(unittest.TestCase):
    """
    Verify that the frozen variable semantics are present and consistent
    with the Kalman observation model mappings.
    """

    def test_all_v1_variables_have_semantics(self):
        """All expected V1 output variables must have frozen semantics."""
        expected = [
            "vegetation_fraction",
            "bare_soil_fraction",
            "rgb_anomaly_score",
            "coarse_phenology_stage",
            "boundary_contamination_score",
        ]
        for var in expected:
            sem = get_semantics(var)
            self.assertIsNotNone(sem, f"Missing semantics for '{var}'")

    def test_rgb_anomaly_has_weak_proxy_ceiling(self):
        """rgb_anomaly_score must have reliability ceiling < 0.7 (weak proxy)."""
        sem = get_semantics("rgb_anomaly_score")
        self.assertIsNotNone(sem)
        self.assertLess(sem.reliability_ceiling, 0.70)

    def test_anomaly_assert_not_biophysical_raises(self):
        """assert_not_biophysical must raise for weak proxy variables."""
        with self.assertRaises(ValueError):
            assert_not_biophysical("rgb_anomaly_score")

    def test_vegetation_fraction_not_biophysical_passes(self):
        """
        vegetation_fraction has higher ceiling (0.85) — assert_not_biophysical
        should NOT raise (it is still a proxy, but a stronger one).
        """
        # Should not raise — ceiling is >= 0.5
        try:
            assert_not_biophysical("vegetation_fraction")
        except ValueError:
            self.fail("vegetation_fraction wrongly flagged as weak proxy")

    def test_phenology_stage_has_high_sigma(self):
        """coarse_phenology_stage must have base_sigma >= 0.8."""
        sem = get_semantics("coarse_phenology_stage")
        self.assertIsNotNone(sem)
        self.assertGreaterEqual(sem.base_sigma, 0.80)


if __name__ == "__main__":
    unittest.main()
