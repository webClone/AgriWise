"""
Satellite RGB Golden Tests

Four fixed synthetic plot RGB scenarios with pinned expectations:
  1. Healthy uniform plot
  2. Patchy stressed plot
  3. Boundary-offset plot
  4. Cloudy but georeferenced plot

Each test pins:
  - canopy fraction range
  - anomaly fraction range
  - QA flags
  - whether row detection is emitted or suppressed
"""

import unittest
from datetime import datetime

from services.agribrain.layer0.perception.satellite_rgb.engine import SatelliteRGBEngine
from services.agribrain.layer0.perception.satellite_rgb.schemas import SatelliteRGBEngineInput
from services.agribrain.layer0.perception.satellite_rgb.qa import SatelliteRGBQAFlag
from services.agribrain.layer0.perception.common.base_types import SatelliteProvider


class TestGolden1_HealthyUniformPlot(unittest.TestCase):
    """
    Golden Test 1: Healthy uniform green plot.
    
    Expected:
      - High vegetation fraction (>0.5)
      - Low anomaly fraction (<0.2)  
      - Low bare soil fraction (<0.3)
      - CLEAN QA flags
      - Row detection suppressed (V1)
      - High confidence
    """

    def setUp(self):
        self.engine = SatelliteRGBEngine()
        h, w = 40, 40
        self.input = SatelliteRGBEngineInput(
            plot_id="golden_healthy",
            timestamp=datetime(2026, 4, 15),
            bbox=(-1.5, 34.0, -1.49, 34.01),
            rgb_image_ref="test://golden_healthy",
            plot_polygon="POLYGON((-1.5 34.0, -1.49 34.0, -1.49 34.01, -1.5 34.01, -1.5 34.0))",
            crs_or_georef="EPSG:4326",
            ground_resolution_m=10.0,
            image_width=w,
            image_height=h,
            provider=SatelliteProvider.SENTINEL2,
            cloud_estimate=0.02,
            recentness_days=2,
            image_content_hash="golden_healthy_hash",
            synthetic_pixels={
                "red": [[0.2] * w for _ in range(h)],
                "green": [[0.5] * w for _ in range(h)],
                "blue": [[0.15] * w for _ in range(h)],
            },
        )

    def test_canopy_fraction_range(self):
        result = self.engine.process_full(self.input)
        self.assertIsNotNone(result)
        output, _ = result
        self.assertGreater(output.vegetation_fraction, 0.5)

    def test_anomaly_fraction_range(self):
        result = self.engine.process_full(self.input)
        output, _ = result
        self.assertLess(output.anomaly_fraction, 0.2)

    def test_bare_soil_fraction(self):
        result = self.engine.process_full(self.input)
        output, _ = result
        self.assertLess(output.bare_soil_fraction, 0.3)

    def test_qa_flags_clean(self):
        result = self.engine.process_full(self.input)
        output, _ = result
        self.assertGreaterEqual(output.qa_score, 0.69)

    def test_row_detection_suppressed(self):
        result = self.engine.process_full(self.input)
        output, packets = result
        row_vars = [p for p in packets if "row_direction" in p.payload]
        self.assertEqual(len(row_vars), 0)


class TestGolden2_PatchyStressedPlot(unittest.TestCase):
    """
    Golden Test 2: Patchy stressed plot with gaps.
    
    Expected:
      - Moderate vegetation fraction (0.2–0.7)
      - Elevated anomaly fraction (>0.0)
      - Proper confidence (not artificially high)
    """

    def setUp(self):
        self.engine = SatelliteRGBEngine()
        h, w = 40, 40
        # Create patchy: mostly green with brown gaps
        pixels = {"red": [], "green": [], "blue": []}
        for r in range(h):
            row_r, row_g, row_b = [], [], []
            for c in range(w):
                if (r + c) % 7 == 0:  # Sparse gaps
                    row_r.append(0.45)
                    row_g.append(0.2)
                    row_b.append(0.15)
                else:
                    row_r.append(0.2)
                    row_g.append(0.48)
                    row_b.append(0.15)
            pixels["red"].append(row_r)
            pixels["green"].append(row_g)
            pixels["blue"].append(row_b)

        self.input = SatelliteRGBEngineInput(
            plot_id="golden_patchy",
            timestamp=datetime(2026, 4, 15),
            bbox=(-1.5, 34.0, -1.49, 34.01),
            rgb_image_ref="test://golden_patchy",
            plot_polygon="POLYGON((-1.5 34.0, -1.49 34.0, -1.49 34.01, -1.5 34.01, -1.5 34.0))",
            crs_or_georef="EPSG:4326",
            ground_resolution_m=10.0,
            image_width=w,
            image_height=h,
            provider=SatelliteProvider.SENTINEL2,
            cloud_estimate=0.05,
            recentness_days=3,
            image_content_hash="golden_patchy_hash",
            synthetic_pixels=pixels,
        )

    def test_canopy_fraction_moderate(self):
        result = self.engine.process_full(self.input)
        output, _ = result
        self.assertGreater(output.vegetation_fraction, 0.2)
        self.assertLess(output.vegetation_fraction, 0.95)

    def test_anomaly_fraction_elevated(self):
        result = self.engine.process_full(self.input)
        output, _ = result
        # Patchy plots should trigger some heterogeneity
        self.assertGreaterEqual(output.anomaly_fraction, 0.0)

    def test_confidence_not_artificially_high(self):
        result = self.engine.process_full(self.input)
        output, _ = result
        self.assertLessEqual(output.qa_score, 1.0)


class TestGolden3_BoundaryOffsetPlot(unittest.TestCase):
    """
    Golden Test 3: Plot with heavy boundary contamination.
    
    Expected:
      - Boundary contamination detected
      - Lower reliability weight
      - QA flags include boundary contamination
    """

    def setUp(self):
        self.engine = SatelliteRGBEngine()
        # Small image with large margins → high boundary fraction
        h, w = 12, 12
        self.input = SatelliteRGBEngineInput(
            plot_id="golden_boundary",
            timestamp=datetime(2026, 4, 15),
            bbox=(-1.5, 34.0, -1.49, 34.01),
            rgb_image_ref="test://golden_boundary",
            plot_polygon="POLYGON((-1.5 34.0, -1.49 34.0, -1.49 34.01, -1.5 34.01, -1.5 34.0))",
            crs_or_georef="EPSG:4326",
            ground_resolution_m=10.0,
            image_width=w,
            image_height=h,
            provider=SatelliteProvider.SENTINEL2,
            cloud_estimate=0.05,
            recentness_days=3,
            image_content_hash="golden_boundary_hash",
            synthetic_pixels={
                "red": [[0.2] * w for _ in range(h)],
                "green": [[0.45] * w for _ in range(h)],
                "blue": [[0.15] * w for _ in range(h)],
            },
        )

    def test_boundary_contamination_detected(self):
        result = self.engine.process_full(self.input)
        output, _ = result
        self.assertGreater(output.boundary_contamination_score, 0.0)

    def test_reliability_reduced(self):
        result = self.engine.process_full(self.input)
        output, _ = result
        # Heavy boundary contamination should reduce overall QA
        self.assertLess(output.qa_score, 0.9)


class TestGolden4_CloudyButGeoreferenced(unittest.TestCase):
    """
    Golden Test 4: Cloudy but still georeferenced plot.
    
    Expected:
      - Usable (not total failure)
      - CLOUD_CONTAMINATED flag
      - Lower reliability
      - Higher sigma inflation
      - Still produces some packets (with low weight)
    """

    def setUp(self):
        self.engine = SatelliteRGBEngine()
        h, w = 30, 30
        self.input = SatelliteRGBEngineInput(
            plot_id="golden_cloudy",
            timestamp=datetime(2026, 4, 15),
            bbox=(-1.5, 34.0, -1.49, 34.01),
            rgb_image_ref="test://golden_cloudy",
            plot_polygon="POLYGON((-1.5 34.0, -1.49 34.0, -1.49 34.01, -1.5 34.01, -1.5 34.0))",
            crs_or_georef="EPSG:4326",
            ground_resolution_m=10.0,
            image_width=w,
            image_height=h,
            provider=SatelliteProvider.SENTINEL2,
            cloud_estimate=0.55,  # Borderline cloudy
            recentness_days=3,
            image_content_hash="golden_cloudy_hash",
            synthetic_pixels={
                "red": [[0.3] * w for _ in range(h)],
                "green": [[0.35] * w for _ in range(h)],
                "blue": [[0.3] * w for _ in range(h)],
            },
        )

    def test_still_usable(self):
        """Should NOT produce total failure despite clouds."""
        result = self.engine.process_full(self.input)
        self.assertIsNotNone(result)
        output, packets = result
        # May have packets with low weight
        self.assertGreaterEqual(len(packets), 0)

    def test_cloud_flag_present(self):
        result = self.engine.process_full(self.input)
        output, _ = result
        # QA score should be reduced
        self.assertLess(output.qa_score, 0.7)

    def test_sigma_inflation_elevated(self):
        result = self.engine.process_full(self.input)
        output, _ = result
        self.assertGreater(output.sigma_inflation, 1.0)

    def test_reliability_capped(self):
        result = self.engine.process_full(self.input)
        output, _ = result
        self.assertLess(output.reliability_weight, 0.7)


class TestGolden5_TooSmallOrTooCoarse(unittest.TestCase):
    """
    Golden Test 5: Too-small plot / too-low-resolution.

    Policy:
      - Very coarse resolution (40m GSD) with a tiny plot
        produces insufficient pixels → extreme QA downgrade
      - Engine may still return output (not hard rejection) but:
          * qa_score must be very low
          * reliability_weight must be near-floor
          * sigma_inflation must be very high
          * row detection must be suppressed
          * Kalman will nearly ignore these observations

    This is the guard for the row/feasibility logic in V1.5:
    if coarse-resolution images could emit packets with normal weights,
    they would corrupt the state before row detection is even attempted.
    """

    def setUp(self):
        self.engine = SatelliteRGBEngine()
        # Very small image at very coarse resolution
        h, w = 6, 6  # Only 36 pixels total
        self.input = SatelliteRGBEngineInput(
            plot_id="golden_toosmall",
            timestamp=datetime(2026, 4, 15),
            bbox=(-1.5, 34.0, -1.49, 34.01),
            rgb_image_ref="test://golden_toosmall",
            plot_polygon="POLYGON((-1.5 34.0, -1.49 34.0, -1.49 34.01, -1.5 34.01, -1.5 34.0))",
            crs_or_georef="EPSG:4326",
            ground_resolution_m=40.0,           # WAY too coarse (>30m threshold)
            image_width=w,
            image_height=h,
            provider=SatelliteProvider.OTHER,
            cloud_estimate=0.05,
            recentness_days=3,
            plot_area_ha=0.001,                  # Tiny plot — triggers insufficient pixels
            image_content_hash="golden_toosmall_hash",
            synthetic_pixels={
                "red": [[0.2] * w for _ in range(h)],
                "green": [[0.45] * w for _ in range(h)],
                "blue": [[0.15] * w for _ in range(h)],
            },
        )

    def test_qa_score_is_very_low(self):
        """Coarse resolution with tiny plot must produce very low qa_score."""
        result = self.engine.process_full(self.input)
        self.assertIsNotNone(result)
        output, _ = result
        self.assertLess(output.qa_score, 0.3)

    def test_reliability_near_floor(self):
        """Near-unusable observations must have near-floor reliability."""
        result = self.engine.process_full(self.input)
        output, _ = result
        self.assertLessEqual(output.reliability_weight, 0.25)

    def test_sigma_inflation_extreme(self):
        """Extreme downgrade must produce very high sigma inflation."""
        result = self.engine.process_full(self.input)
        output, _ = result
        self.assertGreater(output.sigma_inflation, 2.0)

    def test_row_detection_not_feasible(self):
        """40m resolution must NOT allow row detection."""
        result = self.engine.process_full(self.input)
        output, _ = result
        self.assertFalse(output.row_detection_feasible)

    def test_no_high_weight_packets(self):
        """
        Any packets emitted must have very low reliability_weight.
        This is the key protection for V1.5 row detection:
        coarse-resolution inputs cannot corrupt the Kalman state.
        """
        result = self.engine.process_full(self.input)
        output, packets = result
        for pkt in packets:
            self.assertLessEqual(
                pkt.reliability_weight, 0.25,
                f"Packet {pkt.packet_id} has unreasonably high reliability_weight "
                f"{pkt.reliability_weight:.3f} for a too-coarse input"
            )


if __name__ == "__main__":
    unittest.main()
