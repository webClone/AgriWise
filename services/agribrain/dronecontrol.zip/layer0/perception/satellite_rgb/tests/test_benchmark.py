"""
Satellite RGB V1 Benchmark CI Test — satrgb_benchmark_v1

Runs the frozen benchmark and asserts all 7 metrics pass their targets.
This is the CI gate that ensures no engine regression breaks the scorecard.
"""

import unittest

from services.agribrain.layer0.perception.satellite_rgb.benchmark.run_benchmark import (
    run_benchmark,
    CaseResult,
)


class TestSatelliteRGBBenchmarkV1(unittest.TestCase):
    """
    CI gate: runs the full satrgb_benchmark_v1 and asserts all metric targets.
    """

    @classmethod
    def setUpClass(cls):
        cls.results = run_benchmark(verbose=False)

    def _structural_cases(self):
        return [r for r in self.results if r.case.gt_qa_usable]

    # --- Metric 1: Vegetation fraction MAE <= 0.08 ---
    def test_vegetation_fraction_mae(self):
        structural = self._structural_cases()
        mae = sum(r.veg_error for r in structural) / max(len(structural), 1)
        self.assertLessEqual(
            mae, 0.08,
            f"Vegetation fraction MAE {mae:.3f} exceeds target 0.08"
        )

    # --- Metric 2: Soil fraction MAE <= 0.08 ---
    def test_soil_fraction_mae(self):
        structural = self._structural_cases()
        mae = sum(r.soil_error for r in structural) / max(len(structural), 1)
        self.assertLessEqual(
            mae, 0.08,
            f"Soil fraction MAE {mae:.3f} exceeds target 0.08"
        )

    # --- Metric 3: Density class accuracy >= 85% ---
    def test_density_class_accuracy(self):
        structural = self._structural_cases()
        correct = sum(1 for r in structural if r.density_correct)
        acc = correct / max(len(structural), 1) * 100
        self.assertGreaterEqual(
            acc, 85.0,
            f"Density class accuracy {acc:.1f}% below target 85%"
        )

    # --- Metric 4: Phenology stage MAE <= 1.0 ---
    def test_phenology_stage_mae(self):
        structural = self._structural_cases()
        mae = sum(r.phenology_error for r in structural) / max(len(structural), 1)
        self.assertLessEqual(
            mae, 1.0,
            f"Phenology stage MAE {mae:.2f} exceeds target 1.0"
        )

    # --- Metric 5: QA gating accuracy >= 95% ---
    def test_qa_gating_accuracy(self):
        correct = sum(1 for r in self.results if r.qa_correct)
        acc = correct / max(len(self.results), 1) * 100
        self.assertGreaterEqual(
            acc, 95.0,
            f"QA gating accuracy {acc:.1f}% below target 95%"
        )

    # --- Metric 6: Anomaly FP rate <= 10% ---
    def test_anomaly_false_positive_rate(self):
        structural = self._structural_cases()
        non_anomaly = [r for r in structural if not r.case.gt_anomaly_expected]
        fps = sum(1 for r in non_anomaly if r.anomaly_fp)
        fp_rate = fps / max(len(non_anomaly), 1) * 100
        self.assertLessEqual(
            fp_rate, 10.0,
            f"Anomaly FP rate {fp_rate:.1f}% exceeds target 10%"
        )

    # --- Metric 7: Boundary contamination accuracy >= 90% ---
    def test_boundary_contamination_accuracy(self):
        correct = sum(1 for r in self.results if r.boundary_correct)
        acc = correct / max(len(self.results), 1) * 100
        self.assertGreaterEqual(
            acc, 90.0,
            f"Boundary accuracy {acc:.1f}% below target 90%"
        )

    # --- Sanity checks ---
    def test_no_engine_errors(self):
        errors = [r for r in self.results if r.error]
        self.assertEqual(
            len(errors), 0,
            f"Engine errors in: {[r.case.case_id for r in errors]}"
        )

    def test_all_usable_cases_produce_packets(self):
        usable = [r for r in self.results if r.case.gt_qa_usable]
        no_packets = [r for r in usable if r.n_packets == 0]
        self.assertEqual(
            len(no_packets), 0,
            f"Cases with 0 packets: {[r.case.case_id for r in no_packets]}"
        )


if __name__ == "__main__":
    unittest.main()
