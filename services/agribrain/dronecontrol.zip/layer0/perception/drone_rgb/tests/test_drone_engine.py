"""
Tests for Drone RGB Engine.

Validates dual-mode routing, provenance preservation, command-mode symptom
packet emission, and spatial map schema compliance.
"""

import random
import pytest
from services.agribrain.layer0.perception.drone_rgb.engine import DroneRGBEngine
from services.agribrain.layer0.perception.drone_rgb.schemas import DroneRGBInput
from services.agribrain.drone_mission.schemas import FlightMode, MissionType


def _make_golden_disease_pixels(w: int = 100, h: int = 100, seed: int = 42):
    """Generate the same tuned golden pixels used by the benchmark command case.
    
    R=240, G=200, B=100 with ±25 noise — passes Farmer Photo scene_gate as FIELD
    and triggers CHLOROSIS symptoms.
    """
    rng = random.Random(seed)
    red = [[0] * w for _ in range(h)]
    green = [[0] * w for _ in range(h)]
    blue = [[0] * w for _ in range(h)]
    for y in range(h):
        for x in range(w):
            noise = rng.randint(-25, 25)
            red[y][x] = min(255, max(0, 240 + noise))
            green[y][x] = min(255, max(0, 200 + noise))
            blue[y][x] = min(255, max(0, 100 + noise))
    return {"red": red, "green": green, "blue": blue}


def _make_row_ortho(w: int = 50, h: int = 50):
    """Generate a simple synthetic orthomosaic with crop rows for mapping tests."""
    rng = random.Random(99)
    red = [[0] * w for _ in range(h)]
    green = [[0] * w for _ in range(h)]
    blue = [[0] * w for _ in range(h)]
    for y in range(h):
        for x in range(w):
            # Simple vertical rows every 20px
            if x % 20 < 5:
                r, g, b = 40, 160, 40  # crop
            else:
                r, g, b = 130, 100, 70  # soil
            noise = rng.randint(-10, 10)
            red[y][x] = min(255, max(0, r + noise))
            green[y][x] = min(255, max(0, g + noise))
            blue[y][x] = min(255, max(0, b + noise))
    return {"red": red, "green": green, "blue": blue}


# ============================================================================
# Basic Routing Tests
# ============================================================================

def test_drone_engine_routing_mapping():
    """Test mapping mode routing."""
    engine = DroneRGBEngine()
    
    inp = DroneRGBInput(
        plot_id="test_plot",
        mission_id="test_mission",
        flight_mode=FlightMode.MAPPING_MODE,
        mission_type=MissionType.FULL_PLOT_MAP,
        synthetic_ortho_pixels=_make_row_ortho()
    )
    
    out, packets = engine.process_full(inp)
    
    assert out is not None
    assert not out.routed_to_farmer_photo
    assert out.routed_frame_count == 0

def test_drone_engine_routing_command():
    """Test command mode routing to Farmer Photo."""
    engine = DroneRGBEngine()
    
    inp = DroneRGBInput(
        plot_id="test_plot",
        mission_id="test_mission",
        flight_mode=FlightMode.COMMAND_REVISIT_MODE,
        mission_type=MissionType.CONCERN_ZONE_COMMAND,
        synthetic_frame_pixels=[{"red": [[1]], "green": [[1]], "blue": [[1]]}],
        target_zone_id="zone_123"
    )
    
    out, packets = engine.process_full(inp)
    
    assert out is not None
    assert out.routed_to_farmer_photo
    assert out.routed_frame_count == 1


# ============================================================================
# Command Mode: Symptom Packet Emission
# ============================================================================

def test_command_mode_emits_symptom_packets():
    """Test that command mode with tuned golden disease pixels emits symptom packets.
    
    Uses the same R=240/G=200/B=100 + noise pixels proven in the benchmark
    to pass the Farmer Photo scene gate and trigger chlorosis detection.
    """
    engine = DroneRGBEngine()
    
    disease_pixels = _make_golden_disease_pixels()
    
    inp = DroneRGBInput(
        plot_id="test_plot",
        mission_id="test_cmd_symptom",
        flight_mode=FlightMode.COMMAND_REVISIT_MODE,
        mission_type=MissionType.CONCERN_ZONE_COMMAND,
        synthetic_frame_pixels=[disease_pixels],
        target_zone_id="zone_disease",
        commanded_altitude_m=5.0,
    )
    
    out, packets = engine.process_full(inp)
    
    assert out is not None
    assert out.routed_to_farmer_photo
    assert len(packets) >= 1, (
        f"Expected at least 1 symptom packet from Farmer Photo, got {len(packets)}"
    )


# ============================================================================
# Command Mode: Drone Provenance Survival (strict — every packet)
# ============================================================================

def test_command_mode_preserves_drone_provenance():
    """Test that drone provenance fields survive routing into every Farmer Photo packet.
    
    Asserts strictly on EVERY returned packet (not just one):
    - capture_source == "drone"
    - mission_id is present
    - target_zone_id is present
    - commanded_altitude_m is present
    """
    engine = DroneRGBEngine()
    
    disease_pixels = _make_golden_disease_pixels()
    
    inp = DroneRGBInput(
        plot_id="test_plot",
        mission_id="mission_prov_test",
        flight_mode=FlightMode.COMMAND_REVISIT_MODE,
        mission_type=MissionType.CONCERN_ZONE_COMMAND,
        synthetic_frame_pixels=[disease_pixels],
        target_zone_id="zone_abc",
        commanded_altitude_m=5.0,
    )
    
    out, packets = engine.process_full(inp)
    
    assert len(packets) >= 1, "Need at least one packet to verify provenance"
    
    for i, packet in enumerate(packets):
        payload = packet.payload
        assert isinstance(payload, dict), f"Packet {i} payload is not a dict: {type(payload)}"
        
        assert payload.get("capture_source") == "drone", (
            f"Packet {i} missing capture_source='drone', got: {payload.get('capture_source')}"
        )
        assert payload.get("mission_id") == "mission_prov_test", (
            f"Packet {i} missing/wrong mission_id, got: {payload.get('mission_id')}"
        )
        assert payload.get("target_zone_id") == "zone_abc", (
            f"Packet {i} missing/wrong target_zone_id, got: {payload.get('target_zone_id')}"
        )
        assert payload.get("commanded_altitude_m") == 5.0, (
            f"Packet {i} missing/wrong commanded_altitude_m, got: {payload.get('commanded_altitude_m')}"
        )


# ============================================================================
# Mapping Mode: Spatial Maps Schema Compliance
# ============================================================================

def test_mapping_mode_spatial_maps_schema():
    """Test that mapping mode packets contain properly structured spatial maps.
    
    Asserts:
    - Payload contains summary_metrics and spatial_maps_embedded
    - Every embedded map has encoding, is_downsampled, source_resolution_cm, bbox, data_grid
    - No data_grid dimension exceeds 128
    """
    engine = DroneRGBEngine()
    
    ortho = _make_row_ortho(w=50, h=50)
    
    inp = DroneRGBInput(
        plot_id="test_plot",
        mission_id="test_spatial",
        flight_mode=FlightMode.MAPPING_MODE,
        mission_type=MissionType.FULL_PLOT_MAP,
        synthetic_ortho_pixels=ortho,
    )
    
    out, packets = engine.process_full(inp)
    
    assert out is not None
    assert out.is_valid
    assert len(packets) >= 1, "Expected at least one mapping packet"
    
    packet = packets[0]
    payload = packet.payload
    
    # Top-level structure
    assert "summary_metrics" in payload, "Payload missing summary_metrics"
    assert "spatial_maps_embedded" in payload, "Payload missing spatial_maps_embedded"
    
    # Summary metrics should have at least some data
    sm = payload["summary_metrics"]
    assert len(sm) > 0, "summary_metrics is empty"
    
    # Spatial maps validation
    maps = payload["spatial_maps_embedded"]
    assert len(maps) > 0, "spatial_maps_embedded is empty"
    
    REQUIRED_MAP_FIELDS = {"encoding", "is_downsampled", "source_resolution_cm", 
                           "downsampled_resolution_cm", "bbox", "data_grid"}
    REQUIRED_BBOX_FIELDS = {"top_left_lat", "top_left_lon", "bottom_right_lat", "bottom_right_lon"}
    
    for map_type, map_data in maps.items():
        # Check all required fields are present
        missing = REQUIRED_MAP_FIELDS - set(map_data.keys())
        assert len(missing) == 0, (
            f"Map '{map_type}' missing fields: {missing}"
        )
        
        # Check bbox has required fields
        bbox = map_data["bbox"]
        missing_bbox = REQUIRED_BBOX_FIELDS - set(bbox.keys())
        assert len(missing_bbox) == 0, (
            f"Map '{map_type}' bbox missing fields: {missing_bbox}"
        )
        
        # Check encoding value
        assert map_data["encoding"] == "inline_array_v1", (
            f"Map '{map_type}' has unexpected encoding: {map_data['encoding']}"
        )
        
        # Check 128x128 cap
        grid = map_data["data_grid"]
        grid_h = len(grid)
        grid_w = len(grid[0]) if grid_h > 0 else 0
        assert grid_h <= 128, (
            f"Map '{map_type}' data_grid height {grid_h} exceeds 128 cap"
        )
        assert grid_w <= 128, (
            f"Map '{map_type}' data_grid width {grid_w} exceeds 128 cap"
        )


# ============================================================================
# V1.5 Tests
# ============================================================================

def _make_gapped_row_ortho(w: int = 100, h: int = 100, gap_density: float = 0.15):
    """Generate ortho with contiguous row gaps for break detection tests.
    
    Places contiguous gap segments (15px long) along rows to create
    realistic, detectable row breaks.
    """
    rng = random.Random(555)
    red = [[0] * w for _ in range(h)]
    green = [[0] * w for _ in range(h)]
    blue = [[0] * w for _ in range(h)]
    
    # Precompute contiguous gap regions
    gap_regions = set()
    row_spacing = 40
    row_width = 10  # half-width 5 on each side
    seg_len = 15
    
    # Find crop pixel positions per row
    row_positions = {}
    for y in range(h):
        for x in range(w):
            dist = x % row_spacing
            if dist > row_spacing // 2:
                dist = row_spacing - dist
            if dist < row_width // 2:
                row_idx = x // row_spacing
                if row_idx not in row_positions:
                    row_positions[row_idx] = []
                row_positions[row_idx].append((y, x))
    
    # Place one gap segment per row
    for row_idx in sorted(row_positions.keys()):
        positions = row_positions[row_idx]
        if len(positions) < seg_len:
            continue
        start = rng.randint(0, max(0, len(positions) - seg_len))
        for i in range(start, min(start + seg_len, len(positions))):
            gap_regions.add(positions[i])
    
    for y in range(h):
        for x in range(w):
            dist = x % row_spacing
            if dist > row_spacing // 2:
                dist = row_spacing - dist
            is_crop = dist < row_width // 2
            if is_crop and (y, x) in gap_regions:
                is_crop = False
            if is_crop:
                r, g, b = 40, 160, 40
            else:
                r, g, b = 130, 100, 70
            red[y][x] = min(255, max(0, r + rng.randint(-10, 10)))
            green[y][x] = min(255, max(0, g + rng.randint(-10, 10)))
            blue[y][x] = min(255, max(0, b + rng.randint(-10, 10)))
    return {"red": red, "green": green, "blue": blue}


def _make_weedy_row_ortho(w: int = 100, h: int = 100, weed_density: float = 0.40):
    """Generate ortho with weeds for in-row vs inter-row tests."""
    rng = random.Random(777)
    red = [[0] * w for _ in range(h)]
    green = [[0] * w for _ in range(h)]
    blue = [[0] * w for _ in range(h)]
    for y in range(h):
        for x in range(w):
            dist = x % 40
            if dist > 20:
                dist = 40 - dist
            is_crop = dist < 5
            is_weed = (not is_crop) and (rng.random() < weed_density)
            if is_crop:
                r, g, b = 40, 160, 40
            elif is_weed:
                r, g, b = 100, 150, 30
            else:
                r, g, b = 130, 100, 70
            red[y][x] = min(255, max(0, r + rng.randint(-10, 10)))
            green[y][x] = min(255, max(0, g + rng.randint(-10, 10)))
            blue[y][x] = min(255, max(0, b + rng.randint(-10, 10)))
    return {"red": red, "green": green, "blue": blue}


def _make_orchard_ortho(w: int = 100, h: int = 100, remove_tree_idx: int = -1):
    """Generate ortho with circular tree canopies on a grid."""
    import math
    rng = random.Random(999)
    red = [[0] * w for _ in range(h)]
    green = [[0] * w for _ in range(h)]
    blue = [[0] * w for _ in range(h)]
    
    spacing = 25
    radius = 8
    trees = []
    ty = spacing // 2
    while ty < h:
        tx = spacing // 2
        while tx < w:
            trees.append((ty, tx))
            tx += spacing
        ty += spacing
    
    if 0 <= remove_tree_idx < len(trees):
        trees.pop(remove_tree_idx)
    
    for y in range(h):
        for x in range(w):
            is_tree = any(math.sqrt((y - ty)**2 + (x - tx)**2) < radius for ty, tx in trees)
            if is_tree:
                r, g, b = 30, 140, 30
            else:
                r, g, b = 130, 100, 70
            noise = rng.randint(-10, 10)
            red[y][x] = min(255, max(0, r + noise))
            green[y][x] = min(255, max(0, g + noise))
            blue[y][x] = min(255, max(0, b + noise))
    return {"red": red, "green": green, "blue": blue}


class TestRowContinuity:
    """V1.5: Row continuity scores and row count."""
    
    def test_row_continuity_populated(self):
        engine = DroneRGBEngine()
        inp = DroneRGBInput(
            plot_id="test", mission_id="m1",
            flight_mode=FlightMode.MAPPING_MODE,
            mission_type=MissionType.ROW_AUDIT,
            synthetic_ortho_pixels=_make_row_ortho(100, 100),
        )
        out, _ = engine.process_full(inp)
        assert out.row_count > 0, "Should detect at least one row"
        assert len(out.row_continuity_scores) == out.row_count
        assert all(0 <= s <= 1 for s in out.row_continuity_scores)


class TestRowBreaks:
    """V1.5: Row break detection in gapped ortho."""
    
    def test_breaks_detected_in_gapped_ortho(self):
        engine = DroneRGBEngine()
        inp = DroneRGBInput(
            plot_id="test", mission_id="m2",
            flight_mode=FlightMode.MAPPING_MODE,
            mission_type=MissionType.ROW_AUDIT,
            synthetic_ortho_pixels=_make_gapped_row_ortho(),
        )
        out, _ = engine.process_full(inp)
        assert len(out.row_breaks) > 0, "Gapped ortho should have row breaks"
        for brk in out.row_breaks:
            assert brk.gap_length_blocks > 0

    def test_stand_density_populated(self):
        engine = DroneRGBEngine()
        inp = DroneRGBInput(
            plot_id="test", mission_id="m3",
            flight_mode=FlightMode.MAPPING_MODE,
            mission_type=MissionType.ROW_AUDIT,
            synthetic_ortho_pixels=_make_gapped_row_ortho(),
        )
        out, _ = engine.process_full(inp)
        assert len(out.stand_density_per_row) > 0


class TestInRowVsInterRowWeeds:
    """V1.5: In-row vs inter-row weed separation."""
    
    def test_inter_row_exceeds_in_row(self):
        engine = DroneRGBEngine()
        inp = DroneRGBInput(
            plot_id="test", mission_id="m4",
            flight_mode=FlightMode.MAPPING_MODE,
            mission_type=MissionType.WEED_MAP,
            synthetic_ortho_pixels=_make_weedy_row_ortho(),
        )
        out, _ = engine.process_full(inp)
        # Inter-row weed fraction should exceed in-row for typical weed patterns
        assert out.inter_row_weed_fraction > out.in_row_weed_fraction, (
            f"inter_row={out.inter_row_weed_fraction:.3f} should > in_row={out.in_row_weed_fraction:.3f}"
        )


class TestOrchardMode:
    """V1.5: Orchard tree detection and canopy analysis."""
    
    def test_tree_count_detected(self):
        engine = DroneRGBEngine()
        inp = DroneRGBInput(
            plot_id="test", mission_id="m5",
            flight_mode=FlightMode.MAPPING_MODE,
            mission_type=MissionType.ORCHARD_AUDIT,
            synthetic_ortho_pixels=_make_orchard_ortho(),
        )
        out, _ = engine.process_full(inp)
        assert out.tree_count >= 10, f"Should detect trees, got {out.tree_count}"
    
    def test_canopy_diameters_positive(self):
        engine = DroneRGBEngine()
        inp = DroneRGBInput(
            plot_id="test", mission_id="m6",
            flight_mode=FlightMode.MAPPING_MODE,
            mission_type=MissionType.ORCHARD_AUDIT,
            synthetic_ortho_pixels=_make_orchard_ortho(),
        )
        out, _ = engine.process_full(inp)
        assert len(out.canopy_diameters_cm) > 0
        assert all(d > 0 for d in out.canopy_diameters_cm)
    
    def test_missing_tree_detected(self):
        engine = DroneRGBEngine()
        inp = DroneRGBInput(
            plot_id="test", mission_id="m7",
            flight_mode=FlightMode.MAPPING_MODE,
            mission_type=MissionType.ORCHARD_AUDIT,
            synthetic_ortho_pixels=_make_orchard_ortho(remove_tree_idx=3),
        )
        out, _ = engine.process_full(inp)
        assert out.missing_tree_count >= 1, "Should detect missing tree"
    
    def test_uniformity_cv_computed(self):
        engine = DroneRGBEngine()
        inp = DroneRGBInput(
            plot_id="test", mission_id="m8",
            flight_mode=FlightMode.MAPPING_MODE,
            mission_type=MissionType.ORCHARD_AUDIT,
            synthetic_ortho_pixels=_make_orchard_ortho(),
        )
        out, _ = engine.process_full(inp)
        # Uniform trees should have low CV
        assert out.canopy_uniformity_cv >= 0

