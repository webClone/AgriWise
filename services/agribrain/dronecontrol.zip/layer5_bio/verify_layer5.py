"""
Verification Script for Layer 5 (Bio-Threat Intelligence)
Tests Weather Pressure, Spread Signature, and Remote Signature engines.
Updated to match layer5_bio module structure.
"""

import sys
import os

# Add services directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

def test_layer5():
    print("🧪 Starting Layer 5 Verification...")
    results = {}
    
    # 1. Weather Pressure Engine
    try:
        from layer5_bio.engines.weather_pressure import build_weather_pressure
        print("✅ Import: Weather Pressure Engine")
        
        # Mock timeseries with rain and temperature data
        mock_ts = [
            {"date": "2025-01-01", "rain": 5.0, "tmean": 18.0, "gdd": 8.0},
            {"date": "2025-01-02", "rain": 8.0, "tmean": 20.0, "gdd": 10.0},
            {"date": "2025-01-03", "rain": 12.0, "tmean": 22.0, "gdd": 12.0},
        ]
        from unittest.mock import MagicMock
        mock_veg = MagicMock()
        mock_context = {"crop_type": "tomato"}
        
        wp = build_weather_pressure(mock_ts, mock_veg, mock_context)
        
        if isinstance(wp, dict) and "fungal_pressure" in wp:
            results['weather_pressure'] = f"SUCCESS (fungal_pressure={wp['fungal_pressure']:.2f})"
        else:
            results['weather_pressure'] = f"PARTIAL (keys: {list(wp.keys()) if isinstance(wp, dict) else 'N/A'})"
              
    except Exception as e:
        results['weather_pressure'] = f"ERROR: {e}"

    # 2. Spread Signature 
    try:
        from layer5_bio.engines.spread_signature import infer_spread_signature
        print("✅ Import: Spread Signature Engine")
        
        mock_tensor = MagicMock()
        mock_tensor.zones = {}
        
        sss = infer_spread_signature(mock_tensor, mock_veg, mock_context)
        
        if isinstance(sss, dict):
            results['spread_signature'] = f"SUCCESS (pattern={sss.get('pattern', 'N/A')})"
        else:
            results['spread_signature'] = f"PARTIAL (type: {type(sss).__name__})"
            
    except Exception as e:
        results['spread_signature'] = f"ERROR: {e}"

    # 3. Remote Signature (NDVI/SAR evidence)
    try:
        from layer5_bio.engines.remote_signature import build_remote_evidence
        print("✅ Import: Remote Signature Engine")
        
        from layer5_bio.schema import BioThreatIntelligenceOutput
        from agribrain.layer3_decision.schema import DegradationMode
        
        rs, rs_missing = build_remote_evidence(
            ts=mock_ts,
            veg_output=mock_veg,
            wdp=wp if 'wp' in dir() else {},
            spread=sss if 'sss' in dir() else {},
            nutrient_output=None,
            plot_context=mock_context,
            degradation_mode=DegradationMode.NORMAL
        )
        
        if isinstance(rs, dict):
            results['remote_signature'] = f"SUCCESS (keys: {list(rs.keys())[:3]})"
        else:
            results['remote_signature'] = "FAILED"
             
    except Exception as e:
        results['remote_signature'] = f"ERROR: {e}"

    print("\n--- Summary ---")
    for k, v in results.items():
        print(f"{k.upper()}: {v}")
        
    return results

if __name__ == "__main__":
    test_layer5()
