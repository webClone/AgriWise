
import unittest
from unittest.mock import MagicMock
from services.agribrain.layer5_bio.runner import run_layer5_bio
from services.agribrain.layer5_bio.schema import Layer5Input, ThreatId, BioThreatState, Severity, SpreadPattern
from services.agribrain.layer3_decision.schema import PlotContext, DecisionOutput, DegradationMode
from services.agribrain.layer1_fusion.schema import FieldTensor
from services.agribrain.layer2_veg_int.schema import VegIntOutput, VegetationAnomaly, SpatialMetrics
from services.agribrain.orchestrator_v2.schema import OrchestratorInput


class TestLayer5Scenarios(unittest.TestCase):

    def setUp(self):
        self.inputs = OrchestratorInput(
            plot_id="P1", geometry_hash="GEO123",
            date_range={"start": "2025-06-01", "end": "2025-06-30"},
            crop_config={"crop": "Wheat", "planting_date": "2025-05-01"},
            operational_context={"irrigation_type": "rainfed"},
            policy_snapshot={},
        )

    def _make_mocks(self, rain_val=5.0, temp_val=20.0, ndvi_val=0.6,
                     stability_cls="HETEROGENEOUS", anomalies=None, confounders=None):
        # L1 Mock
        ts = []
        for i in range(30):
            ts.append({
                "date": f"2025-06-{i+1:02d}",
                "rain": rain_val,
                "tmean": temp_val,
                "ndvi_smoothed": ndvi_val,
                "vv_interpolated": -10.0,
                "vh_interpolated": -15.0,
            })
        ft = MagicMock(spec=FieldTensor)
        ft.plot_timeseries = ts
        ft.run_id = "L1_MOCK"

        # L2 Mock
        vi = MagicMock(spec=VegIntOutput)
        vi.run_id = "L2_MOCK"
        vi.stability = SpatialMetrics(0.3, 0.2, stability_cls, 1.0)
        vi.anomalies = anomalies or []

        # L3 Mock
        d3 = MagicMock(spec=DecisionOutput)
        d3.run_id_l3 = "L3_MOCK"
        d3.audit = MagicMock()
        d3.audit.policy_snapshot = {}

        # L4 Mock
        n4 = MagicMock()
        n4.run_meta = MagicMock()
        n4.run_meta.run_id = "L4_MOCK"
        n4.nutrient_states = {}
        if confounders:
            n4.nutrient_states["N"] = MagicMock()
            n4.nutrient_states["N"].confounders = confounders

        return ft, vi, d3, n4

    def test_fungal_outbreak(self):
        print("\n🦠 Scenario 1: Fungal Outbreak (Wet + Patchy)")
        anom = [{"type": "DROP", "magnitude": 0.3}]
        ft, vi, d3, n4 = self._make_mocks(rain_val=10.0, temp_val=20.0,
                                            stability_cls="HETEROGENEOUS", anomalies=anom)
        res = run_layer5_bio(self.inputs, ft, vi, d3, n4)
        fwd = res.threat_states[ThreatId.FUNGAL_LEAF_SPOT.value]
        print(f"   Leaf Spot Prob: {fwd.probability:.2f}")
        self.assertGreater(fwd.probability, 0.15, "Expect elevated fungal risk in wet+patchy conditions")
        self.assertEqual(fwd.spread_pattern, SpreadPattern.PATCHY)

    def test_insect_outbreak(self):
        print("\n🦗 Scenario 2: Insect Outbreak (Hot + Dry + Patchy)")
        anom = [{"type": "DROP", "magnitude": 0.25}]
        ft, vi, d3, n4 = self._make_mocks(rain_val=0.0, temp_val=32.0,
                                            stability_cls="HETEROGENEOUS", anomalies=anom)
        res = run_layer5_bio(self.inputs, ft, vi, d3, n4)
        ins = res.threat_states[ThreatId.CHEWING_INSECTS.value]
        print(f"   Insect Prob: {ins.probability:.2f}")
        self.assertGreater(ins.probability, 0.15, "Expect elevated insect risk in hot+dry+patchy conditions")

    def test_abiotic_confounder(self):
        print("\n🌵 Scenario 3: Abiotic Confounder (Water Stress + Uniform)")
        ft, vi, d3, n4 = self._make_mocks(rain_val=0.0, stability_cls="STABLE",
                                            confounders=["WATER_STRESS"])
        res = run_layer5_bio(self.inputs, ft, vi, d3, n4)
        fwd = res.threat_states[ThreatId.FUNGAL_LEAF_SPOT.value]
        print(f"   Leaf Spot Prob (Suppressed): {fwd.probability:.2f}")
        self.assertLess(fwd.probability, 0.4)

    def test_data_gap(self):
        print("\n🚫 Scenario 4: Data Gap (Missing Weather)")
        ft, vi, d3, n4 = self._make_mocks()
        ft.plot_timeseries = []  # No data
        res = run_layer5_bio(self.inputs, ft, vi, d3, n4)
        gap = res.threat_states.get(ThreatId.DATA_GAP.value)
        self.assertIsNotNone(gap)
        print(f"   Data Gap Severity: {gap.severity}")
        self.assertEqual(res.run_meta.degradation_mode, DegradationMode.DATA_GAP)


if __name__ == "__main__":
    unittest.main()
