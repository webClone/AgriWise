
import unittest
from unittest.mock import MagicMock
from datetime import datetime

from services.agribrain.layer5_bio.schema import Layer5Input, ThreatId, BioThreatIntelligenceOutput
from services.agribrain.layer5_bio.runner import run_layer5_bio

# Import Real Input Types
from services.agribrain.orchestrator_v2.schema import OrchestratorInput
from services.agribrain.layer1_fusion.schema import FieldTensor
from services.agribrain.layer2_veg_int.schema import VegIntOutput
from services.agribrain.layer3_decision.schema import DecisionOutput, PlotContext
from services.agribrain.layer4_nutrients.schema import NutrientIntelligenceOutput

class TestLayer5Contract(unittest.TestCase):
    
    def setUp(self):
        # Create Dummy Inputs
        self.tensor = MagicMock(spec=FieldTensor)
        self.tensor.plot_timeseries = []
        self.tensor.static = {"texture_class": "clay_loam"}
        self.tensor.run_id = "test-run"
        self.tensor.zones = {}

        self.veg_int = MagicMock(spec=VegIntOutput)
        self.decision = MagicMock(spec=DecisionOutput)
        self.nutrient = MagicMock(spec=NutrientIntelligenceOutput)

        self.inputs = MagicMock(spec=OrchestratorInput)
        self.inputs.crop_config = {"crop": "Wheat", "variety": "Hard Red"}
        self.inputs.operational_context = {"irrigation_type": "drip"}
        
    def test_strict_input_type(self):
        print("\n🔒 Test Layer 5 Strict Input Contract")
        
        try:
            res = run_layer5_bio(
                inputs=self.inputs,
                tensor=self.tensor,
                veg_int=self.veg_int,
                decision_l3=self.decision,
                nutrient_l4=self.nutrient
            )
            self.assertIsInstance(res, BioThreatIntelligenceOutput)
            print("   ✅ Valid Input Accepted, returned BioThreatIntelligenceOutput")
        except Exception as e:
            self.fail(f"Valid inputs raised exception: {e}")
            
    def test_handles_none_nutrient(self):
        print("   🔒 Testing None nutrient_l4 handling...")
        try:
            res = run_layer5_bio(
                inputs=self.inputs,
                tensor=self.tensor,
                veg_int=self.veg_int,
                decision_l3=self.decision,
                nutrient_l4=None
            )
            self.assertIsInstance(res, BioThreatIntelligenceOutput)
            print("   ✅ None nutrient_l4 handled gracefully")
        except Exception as e:
            self.fail(f"None nutrient_l4 raised exception: {e}")

    def test_enum_usage(self):
        # Verify Enums are importable and used
        print(f"   🔒 Enum Check: {ThreatId.FUNGAL_RUST}")
        self.assertIsInstance(ThreatId.FUNGAL_RUST, ThreatId)

if __name__ == "__main__":
    unittest.main()
