"""Tests init."""
