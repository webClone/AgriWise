"""Benchmark init."""
