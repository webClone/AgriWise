
import unittest
import sys
import os

# Ensure path is set up for imports
sys.path.insert(0, os.getcwd())

from services.agribrain.layer3_decision.features.builder import DecisionFeatures
from services.agribrain.layer3_decision.diagnosis.inference import DiagnosisEngine
from services.agribrain.layer3_decision.schema import ExecutionPlan, TaskNode, Driver
from services.agribrain.layer3_decision.knowledge.ontology import ProblemType
from services.agribrain.orchestrator_v2.gating import filter_unsafe_actions
from services.agribrain.orchestrator_v2.schema import GlobalQuality, GlobalDegradation
from services.agribrain.orchestrator_v2.gating import filter_unsafe_actions
from services.agribrain.orchestrator_v2.schema import GlobalQuality, GlobalDegradation

class TestLogicInvariants(unittest.TestCase):

    def _create_mock_features(self, **overrides):
        """Helper to create a populated DecisionFeatures object with defaults."""
        defaults = {
            "rain_sum_7d": 0.0,
            "rain_sum_14d": 0.0,
            "days_since_rain": 0,
            "soil_moisture_proxy": 0.5,
            "current_stage": "VEGETATIVE",
            "days_in_stage": 10,
            "stage_confidence": 1.0,
            "growth_adequacy": 1.0,
            "growth_velocity_7d": 0.02,
            "has_anomaly": False,
            "anomaly_severity": 0.0,
            "anomaly_type": "NONE",
            "anomaly_duration": 0,
            "sar_vv_trend_7d": 0.0,
            "sar_roughness_change": 0.0,
            "spatial_stability": "STABLE",
            "spatial_confidence": 1.0,
            "sar_available": True,
            "low_sar_cadence": False,
            "rain_available": True,
            "temp_available": True,
            "optical_available": True,
            "missing_inputs": [],
            "sar_obs_count": 10,
            "optical_obs_count": 5,
            "heat_stress_days": 0,
            "cold_stress_days": 0,
            "saturation_days": 0
        }
        defaults.update(overrides)
        return DecisionFeatures(**defaults)

    def test_invariant_datagap_confidence_capped(self):
        """
        Invariant A: DATA_GAP confidence can’t be 1.0 under degradation.
        Test case: Force NO_SAR + PARTIAL_DATA.
        Expect: data_gap.confidence <= 0.8
        """
        print("\nTesting Invariant A: DATA_GAP Confidence Cap...")
        
        # Scenario: Missing SAR
        features = self._create_mock_features(
            missing_inputs=[Driver.SAR_VV],
            sar_available=False
        )
        
        engine = DiagnosisEngine()
        # Only diagnose data gap
        diag = engine._diagnose_data_gap(features)
        
        self.assertIsNotNone(diag, "Should diagnose DATA_GAP")
        self.assertEqual(diag.problem_id, ProblemType.DATA_GAP.value)
        
        print(f"  DATA_GAP Confidence: {diag.confidence}")
        
        # Assertions
        self.assertLessEqual(diag.confidence, 0.8, "DATA_GAP confidence must be penalized (<=0.8)")
        self.assertGreater(diag.probability, 0.9, "DATA_GAP probability should still be high")

    def test_invariant_water_stress_rain_penalty(self):
        """
        Invariant B: Wet field can’t produce Water Stress high probability.
        Test case: rain_14d = 73mm, ndvi_stall/drop = true (confusing signal).
        Expect: water_stress.probability < 0.35
        Expect: evidence_trace includes rain contraindication
        """
        print("\nTesting Invariant B: Water Stress Rain Penalty...")
        
        features = self._create_mock_features(
            rain_sum_14d=73.0,
            rain_sum_7d=30.0,
            days_since_rain=2, # Recently rained
            has_anomaly=True,
            anomaly_type="DROP",
            anomaly_severity=0.4, # Significant drop
            optical_available=True,
            rain_available=True
        )
        
        engine = DiagnosisEngine()
        diag = engine._diagnose_water_stress(features)
        
        prob = diag.probability if diag else 0.0
        print(f"  Water Stress Probability: {prob:.4f}")
        
        if diag:
            # Check Evidence
            found_rain_contra = False
            for ev in diag.evidence_trace:
                if ev.feature_name == "rain_sum_14d" and ev.contribution < 0:
                    found_rain_contra = True
                    print(f"  Found Contraindication: {ev.feature_name} = {ev.value} (Contrib: {ev.contribution})")
                    
            self.assertTrue(found_rain_contra, "Must include rain contraindication evidence")
            self.assertLess(diag.probability, 0.35, "Prob must be low (<0.35) despite anomaly")
        else:
            print("  Water Stress: None (Correctly filtered out)")


    def test_invariant_gating_blocks_intervene(self):
        """
        Invariant C: Severe DATA_GAP blocks INTERVENE actions.
        Test case: GlobalQuality has NO_SAR, Plan has INTERVENE task.
        Expect: Final plan has no INTERVENE task.
        Expect: VERIFY/MONITOR remain.
        """
        print("\nTesting Invariant C: Gating Blocks INTERVENE...")
        
        # 1. Create Unsafe Plan
        unsafe_plan = ExecutionPlan(
            tasks=[
                TaskNode(task_id="T1", type="INTERVENE", instructions="Irrigate 20mm", required_inputs=[], completion_signal="DONE", depends_on=[]),
                TaskNode(task_id="T2", type="VERIFY", instructions="Scout Soil", required_inputs=[], completion_signal="DONE", depends_on=[]),
                TaskNode(task_id="T3", type="MONITOR", instructions="Wait for Data", required_inputs=[], completion_signal="DONE", depends_on=[])
            ],
            edges=[],
            recommended_start_date="2024-01-01",
            review_date="2024-01-02"
        )
        
        # 2. Create Degraded Quality
        quality = GlobalQuality(
            modes=[GlobalDegradation.NO_SAR, GlobalDegradation.PARTIAL_DATA],
            reliability_score=0.6,
            missing_drivers=["SAR_VV"],
            critical_errors=[],
            critical_failure=False
        )
        
        # 3. Apply Filter
        safe_plan = filter_unsafe_actions(unsafe_plan, quality)
        
        # 4. Assertions
        task_types = [t.type for t in safe_plan.tasks]
        print(f"  Original Task Types: {['INTERVENE', 'VERIFY', 'MONITOR']}")
        print(f"  Filtered Task Types: {task_types}")
        
        self.assertNotIn("INTERVENE", task_types, "INTERVENE task must be removed under NO_SAR")
        self.assertIn("VERIFY", task_types, "VERIFY task should remain")
        self.assertIn("MONITOR", task_types, "MONITOR task should remain")

if __name__ == "__main__":
    unittest.main()
