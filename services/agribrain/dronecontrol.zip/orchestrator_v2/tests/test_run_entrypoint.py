import pytest
import os
import sys
from importlib import import_module

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../")))

from services.agribrain.orchestrator_v2.run_entrypoint import (
    run_full_mode, run_chat_mode, run_surfaces_mode, _build_inputs
)
from services.agribrain.orchestrator_v2.intents import Intent

MOCK_CTX = {
    "plot_id": "P-TEST-1",
    "lat": 35.0,
    "lng": -120.0,
    "crop": "wheat",
    "stage": "VEGETATIVE"
}

class MockArgs:
    exp = "INTERMEDIATE"
    history = ""


def test_build_inputs():
    inputs = _build_inputs(MOCK_CTX, query="is it raining")
    assert inputs.plot_id == "P-TEST-1"
    assert inputs.crop_config["crop"] == "wheat"
    assert inputs.crop_config["stage"] == "VEGETATIVE"


def test_run_full_mode():
    res = run_full_mode(MOCK_CTX, query="how is my field")
    
    assert res["plot_id"] == "P-TEST-1"
    # "how is my field" -> DIAGNOSIS intent -> chat_adapter sets assistant_mode="MONITORING"
    assert res["intent"] in ("MONITORING", "FULL", "UNKNOWN")
    
    # Assert layer run outputs are captured, though dependent on the mocked tensor inside L1 for this test environment.
    assert "layer_results" in res
    assert "global_quality" in res
    assert "unified_plan" in res


def test_run_chat_mode_greeting():
    res = run_chat_mode(MOCK_CTX, "hello agribrain", MockArgs())
    
    assert res["intent"] == "WELCOME"
    assert res["plot_id"] == "NONE"
    assert "explanations" in res
    assert res["explanations"]["summary"]["headline"].startswith("Hi")


def test_run_chat_mode_knowledge_fallback():
    # If the user asks a strictly non-plot agronomic question
    res = run_chat_mode(MOCK_CTX, "what is the chemical composition of NPK fertilizer", MockArgs())
    
    assert res["intent"] == "GENERAL"
    assert res["plot_id"] == "NONE"
    assert "explanations" in res


def test_run_chat_mode_data_query():
    # A plot-specific data query should trigger pipeline execution, not a fallback
    res = run_chat_mode(MOCK_CTX, "how much did it rain yesterday?", MockArgs())
    
    # Pipeline path: chat_adapter sets assistant_mode="DATA_ONLY" for data queries
    assert res["intent"] in ("DATA_ONLY", "DATA_QUERY", "MONITORING", "FULL")
    assert res["plot_id"] == "P-TEST-1"  # Attached to plot
    assert "explanations" in res
    assert "layer_results" in res


def test_run_surfaces_mode():
    res = run_surfaces_mode(MOCK_CTX, query="")
    
    assert res["plot_id"] == "P-TEST-1"
    assert "layer_results" in res
    assert "surfaces" in res
    assert isinstance(res["surfaces"], list)
    assert len(res["surfaces"]) > 0, "surfaces mode returned 0 surfaces"
    
    l10_res = res["layer_results"].get("layer_10", {})
    assert l10_res.get("status") == "OK", f"Layer 10 degraded: {l10_res}"
    
    assert "explainability_pack" in res
    assert isinstance(res["explainability_pack"], dict)
    assert "scenario_pack" in res
    assert isinstance(res["scenario_pack"], list)
    assert "history_pack" in res
    assert isinstance(res["history_pack"], list)
