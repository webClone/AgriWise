
import unittest
from unittest.mock import MagicMock, patch
from dataclasses import asdict

from services.agribrain.orchestrator_v2.runner import run_orchestrator
from services.agribrain.orchestrator_v2.schema import OrchestratorInput, LayerStatus, GlobalDegradation, LayerResult
from services.agribrain.orchestrator_v2.registry import LayerId

class TestOrchestratorV2(unittest.TestCase):
    
    def setUp(self):
        self.inputs = OrchestratorInput(
            plot_id="P1", geometry_hash="GEO123", date_range={"start": "2025"},
            crop_config={}, operational_context={}, policy_snapshot={}
        )

    @patch("services.agribrain.orchestrator_v2.runner._safe_run")
    def test_determinism(self, mock_run):
        print("\n🎼 Orchestrator: Verifying Deterministic ID")
        # Mock successful runs
        # Configure output to have ample attributes to avoid MagicMock leaking into math
        out_mock = MagicMock()
        out_mock.run_id = "L-MOCK"
        out_mock.quality_metrics = None # Force default 1.0 reliability
        
        # Return real LayerResult so asdict() works
        mock_run.return_value = LayerResult(
            layer_id="MOCK",
            status=LayerStatus.OK,
            output=out_mock
        )
        
        res1 = run_orchestrator(self.inputs)
        res2 = run_orchestrator(self.inputs)
        
        self.assertEqual(res1.meta.orchestrator_run_id, res2.meta.orchestrator_run_id)
        self.assertTrue(res1.meta.orchestrator_run_id.startswith("AGB2-"))
        print(f"   ✅ ID Stable: {res1.meta.orchestrator_run_id}")

    @patch("services.agribrain.orchestrator_v2.runner._safe_run")
    def test_partial_failure_resilience(self, mock_run):
        print("\n🎼 Orchestrator: Verifying Partial Failure (L4)")
        
        # Side effect: match calls based on LayerId logic in runner
        # Currently runner calls _safe_run(L1...), then _safe_run(L2...).
        # We can implement a side_effect function
        
        def side_effect(lid, *args):
            status = LayerStatus.OK
            if lid == LayerId.L4:
                status = LayerStatus.FAILED
            
            out_mock = MagicMock()
            out_mock.run_id = f"{lid.value}-OK"
            out_mock.quality_metrics = None
            
            return LayerResult(
                layer_id=lid.value,
                status=status, 
                output=out_mock if status == LayerStatus.OK else None,
                errors=["L4 Crash"] if status == LayerStatus.FAILED else []
            )
            
        mock_run.side_effect = side_effect
        
        res = run_orchestrator(self.inputs)
        
        # Check Global Status: L4 should be failed or skipped
        if res.layer_4 is not None:
            self.assertEqual(res.layer_4.status, LayerStatus.FAILED)
        else:
            print("   (L4 was None — runner skipped assignment for failed layers)")
        # System should survive L4 failure
        self.assertTrue(
            res.layer_6 is not None or res.global_quality is not None,
            "System should survive L4 failure",
        )
        print("   ✅ System survived L4 failure.")

    @patch("services.agribrain.orchestrator_v2.runner._safe_run")
    def test_hard_failure(self, mock_run):
        print("\n🎼 Orchestrator: Verifying Hard Failure (L1)")
        
        def side_effect(lid, *args):
            if lid == LayerId.L1:
                return LayerResult(layer_id=lid.value, status=LayerStatus.FAILED, errors=["L1 Missing Data"], output=None)
            return LayerResult(layer_id=lid.value, status=LayerStatus.OK, output=MagicMock())
            
        mock_run.side_effect = side_effect
        
        res = run_orchestrator(self.inputs)
        
        self.assertTrue(res.global_quality.critical_failure, "Should flag critical failure")
        self.assertIsNone(res.layer_2, "L2 should not run")
        print("   ✅ System stopped on L1 failure.")

if __name__ == "__main__":
    unittest.main()
