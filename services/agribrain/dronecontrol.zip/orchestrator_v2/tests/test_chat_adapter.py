
import unittest
from unittest.mock import MagicMock, patch
from dataclasses import asdict

from services.agribrain.orchestrator_v2.schema import RunArtifact, RunMeta, GlobalQuality, GlobalDegradation
from services.agribrain.orchestrator_v2.chat_adapter import build_chat_payload, ChatPayload
from services.agribrain.layer2_veg_int.schema import PhenologyOutput
from services.agribrain.layer3_decision.diagnosis.inference import Diagnosis

class TestChatAdapter(unittest.TestCase):
    
    def test_payload_construction(self):
        print("\n💬 Chat Adapter: Verifying Payload Construction")
        
        # 1. Mock Artifact
        meta = RunMeta("AGB2-TEST", "hash", "now", "2.1", {}, {}, "")
        gq = GlobalQuality([], 0.85, [], [], False)
        
        # Mock L1 (Rain)
        l1_mock = MagicMock()
        l1_mock.output.plot_timeseries = [{"rain": 2.0} for _ in range(14)] # 28mm total
        
        # Mock L2 (Stage)
        l2_mock = MagicMock()
        l2_mock.output.phenology = PhenologyOutput(["V3"], [0.9], [])
        l2_mock.output.curve.ndvi_fit_d1 = [0.005] # Flat/Stable
        
        # Mock L3 (Diagnosis)
        l3_mock = MagicMock()
        # Diagnosis(problem_id, probability, severity, confidence, evidence_trace, contra_trace, supports, problem_class, drivers_used, drivers_missing)
        d1 = Diagnosis("WATER_STRESS", 0.75, 0.5, 0.8, [], [], {}, "ABIOTIC", [], [])
        l3_mock.output.diagnoses = [d1]
        
        artifact = RunArtifact(
            meta=meta,
            inputs=MagicMock(),
            global_quality=gq,
            layer_1=l1_mock,
            layer_2=l2_mock,
            layer_3=l3_mock,
            final_execution_plan=None
        )
        
        # 2. Build Payload
        payload = build_chat_payload(artifact)
        
        # 3. Verify
        self.assertEqual(payload.run_id, "AGB2-TEST")
        self.assertEqual(payload.global_quality["reliability"], 0.85)
        
        # Check Signals
        signals = {s['name']: s for s in payload.summary["key_signals"]}
        self.assertIn("Rain (14d)", signals)
        self.assertEqual(signals["Rain (14d)"]['value'], "28.0 mm")
        
        # Check Stage
        self.assertEqual(payload.summary["stage"], "V3")
        
        # Check Diagnosis
        self.assertEqual(len(payload.diagnoses), 1)
        self.assertEqual(payload.diagnoses[0].id, "WATER_STRESS")
        self.assertEqual(payload.diagnoses[0].prob, 0.75)
        
        print("   ✅ Payload constructed correctly.")

    @patch('services.agribrain.orchestrator_v2.chat_adapter.requests.post')
    @patch.dict('os.environ', {'OPENROUTER_API_KEY': 'test_key'})
    def test_arf_sanitization_recovery(self, mock_post):
        print("\n💬 Chat Adapter: Verifying ARF Format Sanitizer")
        from services.agribrain.orchestrator_v2.chat_adapter import _generate_arf_v2
        
        # Mock malformed LLM response (JSON strings instead of objects)
        malformed_json = """
        {
            "headline": "Test",
            "direct_answer": "Answer",
            "suitability_score": "80%",
            "confidence_badge": "HIGH",
            "confidence_reason": "Clear",
            "what_it_means": "Test",
            "reasoning_cards": ["Soil is dry", "Temp is high"],
            "recommendations": ["Irrigate today", "Check pest traps"],
            "learning": "This is a string lesson instead of dict.",
            "followups": ["Did you rain?", "How is fruit?"]
        }
        """
        
        mock_response = MagicMock()
        mock_response.status_code = 200
        mock_response.json.return_value = {
            "choices": [{"message": {"content": malformed_json}}]
        }
        mock_post.return_value = mock_response
        
        # Mock memory
        mock_memory = MagicMock()
        mock_memory.experience_level = "INTERMEDIATE"
        mock_memory.known_context = {}
        mock_memory.open_loops = []
        mock_memory.asked_followups = []

        summary = {"headline": "Fallback headline", "explanation": "Fallback explanation"}
        
        # Call the generator
        result = _generate_arf_v2(
            summary=summary,
            diags=[],
            actions=[],
            tasks=[],
            memory=mock_memory,
            user_query="Hello",
            mode="MONITORING",
            quality={"degradation_modes": []},
            history=[]
        )
        
        # Verify it survived and sanitizer worked
        self.assertNotIn("error", result, "Sanitized output still raised schema error")
        self.assertEqual(len(result["recommendations"]), 2)
        self.assertEqual(result["recommendations"][0]["title"], "Irrigate today")
        self.assertEqual(result["recommendations"][0]["type"], "MONITOR")
        
        self.assertEqual(len(result["followups"]), 2)
        self.assertEqual(result["followups"][0]["question"], "Did you rain?")
        
        self.assertEqual(len(result["reasoning_cards"]), 2)
        self.assertEqual(result["reasoning_cards"][0]["claim"], "Soil is dry")
        
        self.assertEqual(result["learning"]["micro_lesson"], "This is a string lesson instead of dict.")
        self.assertEqual(result["learning"]["level"], "INTERMEDIATE")

        print("   ✅ Malformed ARF payload correctly repaired by sanitizer.")

if __name__ == "__main__":
    unittest.main()
