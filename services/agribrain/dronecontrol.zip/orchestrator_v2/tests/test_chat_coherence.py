import unittest
import json
from unittest.mock import patch, MagicMock
from services.agribrain.orchestrator_v2.run_entrypoint import run_chat_mode

class TestChatCoherence(unittest.TestCase):
    
    @patch('services.agribrain.orchestrator_v2.runner.run_orchestrator')
    @patch('services.agribrain.orchestrator_v2.chat_adapter._generate_arf_v2')
    def test_time_window_coherence(self, mock_generate_arf, mock_run_orch):
        print("\n💬 Chat Coherence: Affirming single pipeline path data extraction...")
        from services.agribrain.orchestrator_v2.schema import RunArtifact, RunMeta, GlobalQuality, OrchestratorInput
        
        def mock_run(inputs, store=None, intent=None, user_query=None):
            return RunArtifact(
                meta=RunMeta("COH-123", "hash", "now", "2.1", {}, {}, ""),
                inputs=inputs,
                global_quality=GlobalQuality([], 1.0, [], [], False),
                layer_1=None,
                layer_2=None,
                layer_3=None,
                final_execution_plan=None
            )
        
        mock_run_orch.side_effect = mock_run
        mock_generate_arf.return_value = {"error": "Mocked ARF"} 
        
        ctx = {"plot_id": "PLOT_XYZ", "lat": 1.0, "lng": 2.0}
        
        class Args:
            exp = "INTERMEDIATE"
            history = ""
            
        args = Args()
        
        # User query with temporal keyword
        result = run_chat_mode(ctx, "How much rain last month?", args)
        
        # Unpack envelope
        env_start = result["time_window"]["start"]
        env_end = result["time_window"]["end"]
        
        chat_summary = result["explanations"]["summary"]
        chat_period = chat_summary.get("period", "")
        
        self.assertIn(env_start, chat_period, "Start date in chat payload deviates from canonical envelope.")
        self.assertIn(env_end, chat_period, "End date in chat payload deviates from canonical envelope.")
        
        print(f"   ✅ Coherence verified. Chat textual window ('{chat_period}') perfectly matches canonical envelope bounds ('{env_start}' - '{env_end}').")

if __name__ == "__main__":
    unittest.main()
