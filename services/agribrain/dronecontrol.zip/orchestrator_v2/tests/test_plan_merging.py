
import unittest
from services.agribrain.layer3_decision.schema import ExecutionPlan, TaskNode
from services.agribrain.orchestrator_v2.gating import merge_execution_plans

class TestPlanMerging(unittest.TestCase):
    
    def test_merge_disjoint_plans(self):
        print("\n🎼 Orchestrator: Verifying Plan Merge (Disjoint)")
        
        # L3 Plan: Irrigation
        t3 = TaskNode("T_IRRIG_01", "IRRIGATE", {}, {}, "CONFIRM", [])
        p3 = ExecutionPlan([t3], [], "", "")
        
        # L5 Plan: Spray
        t5 = TaskNode("T_SPRAY_01", "SPRAY", {}, {}, "CONFIRM", [])
        p5 = ExecutionPlan([t5], [], "", "")
        
        unified = merge_execution_plans(p3, p5)
        
        ids = [t.task_id for t in unified.tasks]
        self.assertEqual(len(unified.tasks), 2)
        # Verify IDs are hashed
        for tid in ids:
            self.assertTrue(tid.startswith("TASK-"), f"Task ID {tid} should be hashed")
            
        print("   ✅ Disjoint tasks merged correctly.")

    def test_merge_overlapping_tasks(self):
        print("\n🎼 Orchestrator: Verifying Plan Merge (Overlap)")
        
        # L3: Scout
        t3 = TaskNode("T_SCOUT_01", "SCOUT", {}, {}, "CONFIRM", [])
        p3 = ExecutionPlan([t3], [], "", "")
        
        # L5: Scout (Same ID, maybe slightly diff instructions)
        t5 = TaskNode("T_SCOUT_01", "SCOUT", {}, {}, "CONFIRM", [])
        p5 = ExecutionPlan([t5], [], "", "")
        
        unified = merge_execution_plans(p3, p5)
        
        self.assertEqual(len(unified.tasks), 1, "Should deduplicate identical IDs")
        self.assertTrue(unified.tasks[0].task_id.startswith("TASK-"), "Should use deterministic UID")
        print("   ✅ Overlapping tasks deduplicated.")

    def test_deduplication_different_ids(self):
        print("\n🎼 Orchestrator: Verifying Semantic Dedupe (Diff IDs)")
        
        # L3 says: Scout Plot (Task A)
        t3 = TaskNode("TASK_A", "SCOUT", {"target": "whole_plot"}, {"method": "drone"}, "CONFIRM", [])
        p3 = ExecutionPlan([t3], [], "", "")
        
        # L5 says: Scout Plot (Task B) - Identical semantics
        t5 = TaskNode("TASK_B", "SCOUT", {"target": "whole_plot"}, {"method": "drone"}, "CONFIRM", [])
        p5 = ExecutionPlan([t5], [], "", "")
        
        unified = merge_execution_plans(p3, p5)
        
        self.assertEqual(len(unified.tasks), 1, "Should deduplicate based on semantics even if IDs differ")
        self.assertTrue(unified.tasks[0].task_id.startswith("TASK-"), "Should use deterministic UID")
        print("   ✅ Semantic deduplication successful.")

    def test_edge_remapping_after_merge(self):
        """Verify that edges and depends_on are remapped when task IDs change."""
        print("\n🎼 Orchestrator: Verifying Edge Remapping After Merge")
        
        # L3: Task A depends on nothing, Task B depends on A
        t3a = TaskNode("OLD_A", "MONITOR", {"target": "field"}, {}, "CONFIRM", [])
        t3b = TaskNode("OLD_B", "IRRIGATE", {"target": "zone_a"}, {}, "CONFIRM", ["OLD_A"])
        p3 = ExecutionPlan([t3a, t3b], [["OLD_A", "OLD_B"]], "", "")
        
        unified = merge_execution_plans(p3, None)
        
        # Both tasks should have TASK-* IDs
        self.assertEqual(len(unified.tasks), 2)
        for t in unified.tasks:
            self.assertTrue(t.task_id.startswith("TASK-"), f"Task {t.task_id} should be hashed")
        
        # Find the remapped B task
        task_b = [t for t in unified.tasks if t.type == "IRRIGATE"][0]
        task_a = [t for t in unified.tasks if t.type == "MONITOR"][0]
        
        # depends_on should now reference the NEW UID of task A, not OLD_A
        self.assertIn(task_a.task_id, task_b.depends_on,
                      f"depends_on should reference new UID {task_a.task_id}, got {task_b.depends_on}")
        self.assertNotIn("OLD_A", task_b.depends_on,
                         "depends_on should NOT contain old ID 'OLD_A'")
        
        # Edges should also be remapped
        self.assertEqual(len(unified.edges), 1)
        edge = unified.edges[0]
        self.assertEqual(edge[0], task_a.task_id, "Edge source should be new UID")
        self.assertEqual(edge[1], task_b.task_id, "Edge target should be new UID")
        
        print(f"   ✅ Edges remapped: {edge}")

if __name__ == "__main__":
    unittest.main()
