"""
Verification Script for Layer 2 (Vegetation Intelligence)
Tests index computation, phenology classification, stress detection, and biomass estimation.
"""

import sys
import os
import pandas as pd
import numpy as np
from datetime import datetime

# Add services directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

def test_layer2():
    print("🧪 Starting Layer 2 Verification...")
    results = {}
    
    # Mock Data Creation
    dates = pd.date_range(start="2023-01-01", periods=10, freq='D')
    # NDVI rising then dropping (Stress)
    ndvi_vals = [0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.75, 0.6, 0.5, 0.45] 
    gdd_vals = [10, 10, 15, 15, 20, 20, 25, 25, 10, 10]
    
    ndvi_series = pd.Series(ndvi_vals, index=dates)
    gdd_series = pd.Series(gdd_vals, index=dates)
    
    # 1. Test Index Engine
    try:
        from layer2_vegetation.vegetation_indices import veg_index_engine, FieldTensor
        print("✅ Import: Vegetation Index Engine")
        
        # Mock FieldTensor
        t, w, h, f = 10, 2, 2, 2
        data = np.zeros((t, w, h, f))
        # Fill NDVI (idx 0) with our series
        for i, val in enumerate(ndvi_vals):
            data[i, :, :, 0] = val
            
        conf = np.ones((t, w, h, f))
        features = ["ndvi", "evi"]
        meta = {"plot_id": "TEST", "units": {}, "spatial_resolution": "10m", "crs": "EPSG:4326"}
        
        tensor = FieldTensor(data, conf, dates, features, meta)
        
        idx_tensor, _ = veg_index_engine.compute_indices(tensor)
        
        if idx_tensor.data.shape[-1] >= 1: # Has indices
            results['index_engine'] = "SUCCESS"
        else:
             results['index_engine'] = "FAILED"
            
    except Exception as e:
        results['index_engine'] = f"ERROR: {e}"

    # 2. Test Growth Stage
    try:
        from layer2_vegetation.growth_stage import growth_engine
        print("✅ Import: Growth Stage Classifier")
        
        res = growth_engine.classify_zone(ndvi_series, gdd_series, "tomato")
        if "current_stage_label" in res:
             results['growth_stage'] = f"SUCCESS ({res['current_stage_label']})"
        else:
             results['growth_stage'] = "FAILED"
             
    except Exception as e:
        results['growth_stage'] = f"ERROR: {e}"
        
    # 3. Test Stress Detector
    try:
        from layer2_vegetation.stress_detector import stress_engine
        print("✅ Import: Stress Detector")
        
        # Test trace with drop
        res = stress_engine.detect_stress(ndvi_series)
        # Should detect stress due to drop at end
        if res['stress_prob'] > 0:
             results['stress_detection'] = f"SUCCESS (Prob: {res['stress_prob']}%)"
        else:
             results['stress_detection'] = "WARNING (No stress detected on drop)"
             
    except Exception as e:
        results['stress_detection'] = f"ERROR: {e}"
        
    # 4. Test Biomass
    try:
        from layer2_vegetation.biomass_estimator import biomass_engine
        print("✅ Import: Biomass Estimator")
        
        res = biomass_engine.estimate_biomass(ndvi_series, gdd_series)
        if res['biomass_kg_ha'] > 0:
             results['biomass'] = f"SUCCESS ({res['biomass_kg_ha']:.1f} kg/ha)"
        else:
             results['biomass'] = "FAILED"
             
    except Exception as e:
        results['biomass'] = f"ERROR: {e}"

    print("\n--- Summary ---")
    for k, v in results.items():
        print(f"{k.upper()}: {v}")
        
    return results

if __name__ == "__main__":
    test_layer2()
