"""
Verification Script for Layer 9 (GenAI Interface)
Tests Advisor, Alerts, Q&A, Coach, Reports, and Policy.
"""

import sys
import os
import json

# Add services directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

def test_layer9():
    print("🧪 Starting Layer 9 Verification...")
    results = {}
    
    # Mock Data
    mock_context = {
        "plot": {"crop": "Wheat", "id": "P-101"},
        "trust": {"trust_score": 65, "trust_level": "Moderate", "issues": ["Satellite age: 8d"]},
        "yield": {"mean": 5.5, "p10": 5.0, "p90": 6.0, "attribution": {"water": 0.3}},
        "risk": {"risk_score": 60, "level": "Moderate", "drivers": ["Water Stress"]},
        "top_actions": [
            {"action": "Irrigate", "expected_profit": 150, "confidence": "High", "reason": "Severe stress"}
        ]
    }

    # 1. Advisor
    try:
        from layer9_interface.advisor_llm import advisor
        print("✅ Import: Advisor")
        
        prompt = advisor.prepare_context(
            mock_context["plot"], mock_context["trust"], mock_context["yield"], mock_context["risk"], mock_context["top_actions"]
        )
        if "Wheat" in prompt and "Satellite age" in prompt:
             results['advisor'] = "SUCCESS (Prompt context correct)"
        else:
             results['advisor'] = "FAILED"
             
    except Exception as e:
        results['advisor'] = f"ERROR: {e}"

    # 4. Alerts (Order matches user pref)
    try:
        from layer9_interface.alerts_llm import alert_composer
        print("✅ Import: Alerts")
        
        alert = alert_composer.compose_alert("Heatwave", {"action": "Irrigate"}, "Moderate")
        if "Heatwave" in alert["push_notification"] and "Irrigate" in alert["push_notification"]:
             results['alerts'] = "SUCCESS (Content generated)"
        else:
             results['alerts'] = "FAILED"
             
    except Exception as e:
        results['alerts'] = f"ERROR: {e}"

    # 2. Q&A
    try:
        from layer9_interface.qa_llm import qa_bot
        print("✅ Import: Q&A")
        
        ans = qa_bot.handle_query("Why is my yield low?", mock_context)
        if "water" in ans["answer"].lower() and ans["intent"] == "explain":
             results['qa'] = "SUCCESS (Correct intent and attribution)"
        else:
             results['qa'] = "FAILED"
             
    except Exception as e:
        results['qa'] = f"ERROR: {e}"

    # 5. Coach
    try:
        from layer9_interface.coach_llm import coach
        print("✅ Import: Coach")
        
        tip = coach.generate_coaching_tip(mock_context["trust"])
        if "photo" in tip["tip"] or "Update" in tip["tip"]:
             results['coach'] = f"SUCCESS (Tip: {tip['tip']})"
        else:
             results['coach'] = "FAILED"
             
    except Exception as e:
        results['coach'] = f"ERROR: {e}"
        
    # 3. Reports
    try:
        from layer9_interface.report_llm import reporter
        print("✅ Import: Report")
        
        rpt = reporter.generate_report(mock_context, "farmer")
        if "Outlook" in rpt and "Wheat" in rpt:
             results['report'] = "SUCCESS (Markdown generated)"
        else:
             results['report'] = "FAILED"
             
    except Exception as e:
        results['report'] = f"ERROR: {e}"

    # 6. Policy
    try:
        from layer9_interface.policy_router import policy
        print("✅ Import: Policy")
        
        safe_msg = policy.filter_advice("Apply Fungicide X.", "spray", "Low")
        if "SAFETY" in safe_msg and "LOW CONFIDENCE" in safe_msg:
             results['policy'] = "SUCCESS (Disclaimer added)"
        else:
             results['policy'] = "FAILED"
             
    except Exception as e:
        results['policy'] = f"ERROR: {e}"

    print("\n--- Summary ---")
    for k, v in results.items():
        print(f"{k.upper()}: {v}")
        
    return results

if __name__ == "__main__":
    test_layer9()
