"""
Verification Script for Layer 8 (Prescriptive AI)
Tests Ranking, Scheduling, Zoning, and Learning logic against current contracts.
"""

import sys
import os
from datetime import datetime

# Add project root to path so `services.agribrain.*` imports work
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../")))

def test_layer8():
    print("🧪 Starting Layer 8 Verification...")
    results = {}
    
    # 1. Action Ranking
    ranked = []
    try:
        from services.agribrain.layer8_prescriptive.action_ranker import action_ranker
        from services.agribrain.layer8_prescriptive.schema import Layer8Input
        print("✅ Import: Action Ranker")
        
        l8_input = Layer8Input(
            diagnoses=[
                {"problem_id": "WATER_STRESS", "probability": 0.8, "severity": 0.7, "confidence": 0.85},
                {"problem_id": "N_DEFICIENCY", "probability": 0.5, "severity": 0.4, "confidence": 0.7},
            ],
            nutrient_states={"N": {"probability_deficient": 0.5, "confidence": 0.7}},
            bio_threats={},
            weather_forecast=[
                {"day": 1, "temp_max": 28, "precip_mm": 0, "wind_speed": 10},
                {"day": 2, "temp_max": 29, "precip_mm": 0, "wind_speed": 5},
            ],
            zone_ids=["plot"],
            audit_grade="B"
        )
        ranked = action_ranker.rank_actions(l8_input)
        
        if len(ranked) > 0 and hasattr(ranked[0], 'action_type'):
             results['ranking'] = f"SUCCESS (Top Action: {ranked[0].action_type.value}, Score: {ranked[0].priority_score:.3f})"
        else:
             results['ranking'] = "FAILED"
             
    except Exception as e:
        results['ranking'] = f"ERROR: {e}"

    # 2. Scheduler (expects List[ActionCard], not raw dicts)
    try:
        from services.agribrain.layer8_prescriptive.scheduler import scheduler
        print("✅ Import: Scheduler")
        
        forecast = [
            {"wind_speed": 20, "precip_mm": 5},  # Day 1: Windy + rain (Blocked)
            {"wind_speed": 5, "precip_mm": 0},    # Day 2: Clear
        ]
        
        # Use the real ActionCards from the ranker output
        if ranked:
            sched = scheduler.schedule_actions(ranked, forecast, datetime.now())
            statuses = [s.status.value for s in sched]
            results['scheduler'] = f"SUCCESS ({len(sched)} actions scheduled, statuses: {statuses})"
        else:
            results['scheduler'] = "SKIPPED (no ranked actions from step 1)"
             
    except Exception as e:
        results['scheduler'] = f"ERROR: {e}"

    # 3. Zone Prioritization (expects action_cards, zone_reliability, zone_ids)
    try:
        from services.agribrain.layer8_prescriptive.zone_prioritizer import zone_engine
        print("✅ Import: Zone Prioritizer")
        
        zone_reliability = {
            "Zone_A": 0.9,   # High reliability
            "Zone_B": 0.3,   # Low reliability — should restrict to monitoring
        }
        zone_ids = ["Zone_A", "Zone_B"]
        
        if ranked:
            plans = zone_engine.prioritize_zones(ranked, zone_reliability, zone_ids)
            priorities = {z: p.priority for z, p in plans.items()}
            results['zoning'] = f"SUCCESS (Zone priorities: {priorities})"
        else:
            results['zoning'] = "SKIPPED (no ranked actions from step 1)"
             
    except Exception as e:
        results['zoning'] = f"ERROR: {e}"

    # 4. Feedback Loop
    try:
        from services.agribrain.layer8_prescriptive.feedback_loop import feedback_engine
        print("✅ Import: Feedback Loop")
        
        update = feedback_engine.update_calibration(
            {"action": "test", "predicted_yield_gain": 1.0},
            {"observed_yield_gain": 0.5}  # Big miss
        )
        
        if update["status"] == "Overestimated":
             results['feedback'] = f"SUCCESS (Detected Overestimation: {update['prediction_error_pct']}%)"
        else:
             results['feedback'] = "FAILED"
             
    except Exception as e:
        results['feedback'] = f"ERROR: {e}"

    print("\n--- Summary ---")
    for k, v in results.items():
        print(f"{k.upper()}: {v}")
        
    return results

if __name__ == "__main__":
    test_layer8()
