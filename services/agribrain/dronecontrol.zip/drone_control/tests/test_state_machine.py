"""
Test: Mission State Machine.

Validates that all valid transitions succeed and invalid ones are rejected.
"""

import pytest
from ..mission_state_machine import MissionStateMachine, InvalidTransitionError
from ..schemas import LiveMissionState


class TestMissionStateMachine:
    
    def test_initial_state_is_planned(self):
        """State machine starts in PLANNED."""
        sm = MissionStateMachine(execution_id="test")
        assert sm.state == LiveMissionState.PLANNED
        assert not sm.is_terminal
        assert sm.is_operational
    
    def test_normal_mission_flow(self):
        """Full happy path: planned → uploaded → ready → arming → in_flight → returning → completed."""
        sm = MissionStateMachine()
        
        sm.transition(LiveMissionState.UPLOADED, "upload")
        assert sm.state == LiveMissionState.UPLOADED
        
        sm.transition(LiveMissionState.READY, "ready")
        assert sm.state == LiveMissionState.READY
        
        sm.transition(LiveMissionState.ARMING, "arm")
        assert sm.state == LiveMissionState.ARMING
        
        sm.transition(LiveMissionState.IN_FLIGHT, "fly")
        assert sm.state == LiveMissionState.IN_FLIGHT
        
        sm.transition(LiveMissionState.RETURNING, "rtl")
        assert sm.state == LiveMissionState.RETURNING
        
        sm.transition(LiveMissionState.COMPLETED, "done")
        assert sm.state == LiveMissionState.COMPLETED
        assert sm.is_terminal
    
    def test_pause_resume_flow(self):
        """in_flight → paused → in_flight."""
        sm = MissionStateMachine()
        sm.transition(LiveMissionState.UPLOADED)
        sm.transition(LiveMissionState.READY)
        sm.transition(LiveMissionState.ARMING)
        sm.transition(LiveMissionState.IN_FLIGHT)
        
        sm.transition(LiveMissionState.PAUSED, "wind")
        assert sm.state == LiveMissionState.PAUSED
        
        sm.transition(LiveMissionState.IN_FLIGHT, "cleared")
        assert sm.state == LiveMissionState.IN_FLIGHT
    
    def test_abort_from_any_operational(self):
        """Can abort from any operational state."""
        for start_state in [
            LiveMissionState.PLANNED,
            LiveMissionState.UPLOADED,
            LiveMissionState.READY,
            LiveMissionState.ARMING,
            LiveMissionState.IN_FLIGHT,
            LiveMissionState.PAUSED,
            LiveMissionState.RETURNING,
        ]:
            sm = MissionStateMachine()
            sm.force_state(start_state)
            sm.transition(LiveMissionState.ABORTED, "test abort")
            assert sm.state == LiveMissionState.ABORTED
            assert sm.is_terminal
    
    def test_fail_from_any_operational(self):
        """Can fail from any operational state."""
        for start_state in [
            LiveMissionState.PLANNED,
            LiveMissionState.UPLOADED,
            LiveMissionState.READY,
            LiveMissionState.ARMING,
            LiveMissionState.IN_FLIGHT,
            LiveMissionState.PAUSED,
            LiveMissionState.RETURNING,
        ]:
            sm = MissionStateMachine()
            sm.force_state(start_state)
            sm.transition(LiveMissionState.FAILED, "test fail")
            assert sm.state == LiveMissionState.FAILED
    
    def test_invalid_transition_raises(self):
        """Invalid transitions raise InvalidTransitionError."""
        sm = MissionStateMachine()
        
        with pytest.raises(InvalidTransitionError):
            sm.transition(LiveMissionState.IN_FLIGHT)  # Can't fly from PLANNED
    
    def test_cannot_leave_terminal_completed(self):
        """Terminal states are final — can't transition out."""
        sm = MissionStateMachine()
        sm.force_state(LiveMissionState.COMPLETED)
        
        with pytest.raises(InvalidTransitionError):
            sm.transition(LiveMissionState.IN_FLIGHT)
    
    def test_cannot_leave_terminal_aborted(self):
        """Can't transition out of ABORTED."""
        sm = MissionStateMachine()
        sm.force_state(LiveMissionState.ABORTED)
        
        with pytest.raises(InvalidTransitionError):
            sm.transition(LiveMissionState.PLANNED)
    
    def test_cannot_leave_terminal_failed(self):
        """Can't transition out of FAILED."""
        sm = MissionStateMachine()
        sm.force_state(LiveMissionState.FAILED)
        
        with pytest.raises(InvalidTransitionError):
            sm.transition(LiveMissionState.RETURNING)
    
    def test_skip_states_rejected(self):
        """Can't skip states (e.g., PLANNED → IN_FLIGHT)."""
        sm = MissionStateMachine()
        
        with pytest.raises(InvalidTransitionError):
            sm.transition(LiveMissionState.ARMING)  # Must go through UPLOADED → READY first
    
    def test_history_tracked(self):
        """State history is tracked for audit."""
        sm = MissionStateMachine(execution_id="audit_test")
        sm.transition(LiveMissionState.UPLOADED, "step 1")
        sm.transition(LiveMissionState.READY, "step 2")
        sm.transition(LiveMissionState.ARMING, "step 3")
        
        history = sm.history
        assert len(history) == 3
        assert history[0].from_state == LiveMissionState.PLANNED
        assert history[0].to_state == LiveMissionState.UPLOADED
        assert history[0].reason == "step 1"
        assert history[2].to_state == LiveMissionState.ARMING
    
    def test_can_transition_to_check(self):
        """can_transition_to returns correct boolean."""
        sm = MissionStateMachine()
        
        assert sm.can_transition_to(LiveMissionState.UPLOADED)
        assert not sm.can_transition_to(LiveMissionState.IN_FLIGHT)
        assert sm.can_transition_to(LiveMissionState.ABORTED)
