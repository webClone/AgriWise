"""Drone control tests package."""
