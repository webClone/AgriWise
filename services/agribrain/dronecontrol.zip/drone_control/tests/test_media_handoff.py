"""
Test: Media Handoff.

Validates that Mapping → photogrammetry and Command → Farmer Photo
routing works correctly with provenance preserved.
"""

import pytest
from ..media_handoff import MediaHandoff
from ..schemas import (
    CaptureRecord,
    CompiledMission,
    MediaManifest,
)
import datetime


def _make_captures(n):
    return [
        CaptureRecord(
            capture_index=i,
            timestamp=datetime.datetime.now(),
            latitude=31.85 + i * 0.001,
            longitude=34.72,
            altitude_m=50.0,
            heading_deg=90.0,
            file_ref=f"mock://capture_{i:04d}.jpg",
            file_size_bytes=8_000_000,
            waypoint_index=i,
        )
        for i in range(n)
    ]


class TestMediaHandoff:
    
    def test_mapping_routes_to_photogrammetry(self):
        """Mapping Mode media is routed to photogrammetry ONLY."""
        handoff = MediaHandoff()
        
        manifest = MediaManifest(
            execution_id="exec_001",
            mission_id="mission_001",
            captures=_make_captures(20),
            total_captures=20,
        )
        
        mission = CompiledMission(
            mission_id="mission_001",
            execution_id="exec_001",
            flight_mode="mapping_mode",
            mission_type="full_plot_map",
            plot_id="orchard_01",
            flight_altitude_m=50.0,
            target_gsd_cm=2.0,
            target_overlap_pct=75.0,
            drone_profile="standard_prosumer",
        )
        
        result = handoff.route(manifest, mission)
        
        assert result.target == "photogrammetry"
        assert result.success
        assert result.capture_count == 20
        assert result.execution_id == "exec_001"
        assert result.mission_id == "mission_001"
    
    def test_command_routes_to_farmer_photo(self):
        """Command/Revisit media is routed to Farmer Photo ONLY."""
        handoff = MediaHandoff()
        
        manifest = MediaManifest(
            execution_id="exec_002",
            mission_id="mission_002",
            captures=_make_captures(5),
            total_captures=5,
        )
        
        mission = CompiledMission(
            mission_id="mission_002",
            execution_id="exec_002",
            flight_mode="command_revisit",
            mission_type="concern_zone_command",
            plot_id="orchard_01",
        )
        
        result = handoff.route(manifest, mission)
        
        assert result.target == "farmer_photo"
        assert result.success
        assert result.capture_count == 5
    
    def test_provenance_preserved_photogrammetry(self):
        """Mission provenance survives mapping handoff."""
        handoff = MediaHandoff()
        
        manifest = MediaManifest(
            execution_id="exec_003",
            captures=_make_captures(15),
            total_captures=15,
        )
        
        mission = CompiledMission(
            mission_id="mission_003",
            execution_id="exec_003",
            flight_mode="mapping_mode",
            plot_id="wheat_field_7",
            drone_profile="dji_m3e",
            compiler_version="v1",
            flight_altitude_m=60.0,
            target_gsd_cm=2.5,
        )
        
        result = handoff.route(manifest, mission)
        
        assert result.provenance["execution_id"] == "exec_003"
        assert result.provenance["mission_id"] == "mission_003"
        assert result.provenance["plot_id"] == "wheat_field_7"
        assert result.provenance["flight_mode"] == "mapping_mode"
        assert result.provenance["flight_altitude_m"] == 60.0
    
    def test_provenance_preserved_farmer_photo(self):
        """Mission provenance survives command handoff."""
        handoff = MediaHandoff()
        
        manifest = MediaManifest(
            execution_id="exec_004",
            captures=_make_captures(3),
            total_captures=3,
        )
        
        mission = CompiledMission(
            mission_id="mission_004",
            execution_id="exec_004",
            flight_mode="command_revisit",
            plot_id="orchard_alpha",
        )
        
        result = handoff.route(manifest, mission)
        
        assert result.provenance["execution_id"] == "exec_004"
        assert result.provenance["flight_mode"] == "command_revisit"
    
    def test_photogrammetry_downstream_has_frame_refs(self):
        """Photogrammetry downstream input includes frame refs and GPS."""
        handoff = MediaHandoff()
        
        manifest = MediaManifest(captures=_make_captures(10), total_captures=10)
        mission = CompiledMission(
            flight_mode="mapping_mode",
            mission_id="m",
            execution_id="e",
        )
        
        result = handoff.route(manifest, mission)
        
        downstream = result.downstream_input
        assert "frame_refs" in downstream
        assert len(downstream["frame_refs"]) == 10
        assert "frame_gps" in downstream
        assert len(downstream["frame_gps"]) == 10
        assert downstream["source_execution_id"] == "e"
    
    def test_farmer_photo_downstream_has_frames(self):
        """Farmer Photo downstream input includes individual frame dicts."""
        handoff = MediaHandoff()
        
        manifest = MediaManifest(captures=_make_captures(4), total_captures=4)
        mission = CompiledMission(
            flight_mode="command_revisit",
            mission_id="m",
            execution_id="e",
            plot_id="p",
        )
        
        result = handoff.route(manifest, mission)
        
        frames = result.downstream_input
        assert isinstance(frames, list)
        assert len(frames) == 4
        assert frames[0]["capture_source"] == "drone"
        assert frames[0]["execution_id"] == "e"
    
    def test_unknown_mode_fails(self):
        """Unknown flight mode returns failed handoff."""
        handoff = MediaHandoff()
        
        manifest = MediaManifest(captures=_make_captures(1), total_captures=1)
        mission = CompiledMission(flight_mode="unknown_mode")
        
        result = handoff.route(manifest, mission)
        
        assert not result.success
        assert result.target == "unknown"
