"""
Test: Dispatcher.

Validates dispatch success, failure paths, and disconnect handling.
"""

import pytest
from ..dispatcher import Dispatcher
from ..schemas import DispatchRequest, LiveMissionState, FailsafePolicy, WeatherSnapshot


class MockWaypoint:
    def __init__(self, lat, lon, alt):
        self.lat = lat
        self.lon = lon
        self.alt_m = alt
        self.action = "capture"
        self.speed_m_s = 5.0


class MockFlightPlan:
    def __init__(self, n_waypoints=10):
        self.plan_id = "test_plan"
        self.intent_id = "test_intent"
        self.drone_profile = "standard_prosumer"
        self.pattern = "boustrophedon"
        self.waypoints = [
            MockWaypoint(31.85 + i * 0.001, 34.72, 50.0)
            for i in range(n_waypoints)
        ]
        self.flight_altitude_m = 50.0
        self.achieved_gsd_cm = 2.0
        self.estimated_flight_time_min = 3.0
        self.estimated_image_count = n_waypoints


class MockIntent:
    def __init__(self):
        self.flight_mode = type('FM', (), {'value': 'mapping_mode'})()
        self.mission_type = type('MT', (), {'value': 'full_plot_map'})()
        self.target_gsd_cm = 2.0
        self.plot_id = "test_plot"
        self.intent_id = "test_intent"
        self.required_overlap_pct = 75.0


class TestDispatcher:
    
    def _make_request(self, n_waypoints=10):
        return DispatchRequest(
            mission_id="test_mission",
            flight_plan=MockFlightPlan(n_waypoints),
            intent=MockIntent(),
            driver_type="mock",
            weather=WeatherSnapshot(),
            failsafe_policy=FailsafePolicy(),
        )
    
    def test_successful_dispatch(self):
        """Upload + start success path works via mock driver."""
        dispatcher = Dispatcher()
        result = dispatcher.dispatch(self._make_request())
        
        assert result.success
        assert result.state == LiveMissionState.COMPLETED
        assert result.execution_id != ""
        assert result.compiled_mission is not None
        assert len(result.compiled_mission.waypoints) == 10
    
    def test_dispatch_returns_vehicle_state(self):
        """Final vehicle state is returned on success."""
        dispatcher = Dispatcher()
        result = dispatcher.dispatch(self._make_request())
        
        assert result.vehicle_state is not None
    
    def test_no_flight_plan_fails(self):
        """Dispatch without a flight plan fails at compile stage."""
        request = self._make_request()
        request.flight_plan = None
        
        dispatcher = Dispatcher()
        result = dispatcher.dispatch(request)
        
        assert not result.success
        assert result.failure_stage == "compile"
    
    def test_unknown_driver_fails(self):
        """Unknown driver type fails at preflight."""
        request = self._make_request()
        request.driver_type = "nonexistent_driver"
        
        dispatcher = Dispatcher()
        result = dispatcher.dispatch(request)
        
        assert not result.success
        assert "driver" in result.failure_reason.lower() or "Unknown" in result.failure_reason
    
    def test_preflight_failure_does_not_upload(self):
        """Failed preflight prevents upload."""
        request = self._make_request()
        # Set impossible GSD to trigger leaf-level rejection
        request.intent.target_gsd_cm = 0.1
        
        dispatcher = Dispatcher()
        result = dispatcher.dispatch(request)
        
        assert not result.success
        assert result.failure_stage == "preflight"
    
    def test_mapping_and_command_same_dispatcher(self):
        """Both Mapping and Command missions use the same dispatcher."""
        dispatcher = Dispatcher()
        
        # Mapping
        mapping_req = self._make_request()
        mapping_result = dispatcher.dispatch(mapping_req)
        assert mapping_result.success
        
        # Command
        command_req = self._make_request(n_waypoints=5)
        command_req.intent.flight_mode = type('FM', (), {'value': 'command_revisit'})()
        command_req.intent.mission_type = type('MT', (), {'value': 'concern_zone_command'})()
        command_result = dispatcher.dispatch(command_req)
        assert command_result.success
    
    def test_execution_id_unique(self):
        """Each dispatch gets a unique execution_id."""
        dispatcher = Dispatcher()
        r1 = dispatcher.dispatch(self._make_request())
        r2 = dispatcher.dispatch(self._make_request())
        
        assert r1.execution_id != r2.execution_id
    
    def test_state_machine_tracks_progress(self):
        """Dispatcher tracks mission state via state machine."""
        dispatcher = Dispatcher()
        result = dispatcher.dispatch(self._make_request())
        
        # After completion, state should be COMPLETED
        assert result.state == LiveMissionState.COMPLETED
