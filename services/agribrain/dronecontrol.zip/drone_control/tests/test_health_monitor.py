"""
Test: Health Monitor.

Validates detection of low battery, drift, overlap risk, lost link, capture failure.
"""

import pytest
from ..health_monitor import HealthMonitor
from ..schemas import (
    FailsafeAction,
    FailsafePolicy,
    HealthSeverity,
    TelemetryPacket,
    VehicleState,
    CompiledMission,
)


class TestHealthMonitor:
    
    def _make_packet(self, **overrides):
        state_overrides = {}
        packet_overrides = {}
        for k, v in overrides.items():
            if k in ('battery_pct', 'gps_fix', 'gps_satellites', 'gps_hdop',
                      'wind_estimate_m_s', 'link_quality_pct', 'storage_available_mb'):
                state_overrides[k] = v
            else:
                packet_overrides[k] = v
        
        state = VehicleState(
            armed=True,
            battery_pct=state_overrides.get('battery_pct', 80.0),
            gps_fix=state_overrides.get('gps_fix', True),
            gps_satellites=state_overrides.get('gps_satellites', 14),
            gps_hdop=state_overrides.get('gps_hdop', 1.0),
            wind_estimate_m_s=state_overrides.get('wind_estimate_m_s', 3.0),
            link_quality_pct=state_overrides.get('link_quality_pct', 100.0),
            storage_available_mb=state_overrides.get('storage_available_mb', 64000),
        )
        
        return TelemetryPacket(
            state=state,
            sequence=packet_overrides.get('sequence', 0),
            off_track_m=packet_overrides.get('off_track_m', 0.0),
            altitude_deviation_m=packet_overrides.get('altitude_deviation_m', 0.0),
            mission_progress_pct=packet_overrides.get('mission_progress_pct', 50.0),
            capture_count=packet_overrides.get('capture_count', 25),
            expected_captures=packet_overrides.get('expected_captures', 50),
        )
    
    def test_nominal_no_warnings(self):
        """No warnings on nominal telemetry."""
        monitor = HealthMonitor()
        packet = self._make_packet()
        warnings = monitor.evaluate(packet)
        
        assert len(warnings) == 0
    
    def test_low_battery_warning(self):
        """Low battery triggers HIGH warning."""
        monitor = HealthMonitor()
        packet = self._make_packet(battery_pct=25.0)
        warnings = monitor.evaluate(packet)
        
        assert len(warnings) >= 1
        assert any(w.condition == "battery_low" for w in warnings)
        assert any(w.severity == HealthSeverity.HIGH for w in warnings)
    
    def test_critical_battery_rtl(self):
        """Critical battery triggers RTL."""
        monitor = HealthMonitor()
        packet = self._make_packet(battery_pct=15.0)
        warnings = monitor.evaluate(packet)
        
        assert any(w.condition == "battery_critical" for w in warnings)
        assert any(w.recommended_action == FailsafeAction.RTL for w in warnings)
    
    def test_emergency_battery_land_now(self):
        """Emergency battery triggers LAND_NOW."""
        monitor = HealthMonitor()
        packet = self._make_packet(battery_pct=5.0)
        warnings = monitor.evaluate(packet)
        
        assert any(w.condition == "battery_emergency" for w in warnings)
        assert any(w.recommended_action == FailsafeAction.LAND_NOW for w in warnings)
    
    def test_gps_loss_detected(self):
        """GPS fix loss triggers CRITICAL."""
        monitor = HealthMonitor()
        packet = self._make_packet(gps_fix=False)
        warnings = monitor.evaluate(packet)
        
        assert any(w.condition == "gps_loss" for w in warnings)
        assert any(w.severity == HealthSeverity.CRITICAL for w in warnings)
    
    def test_gps_degradation_detected(self):
        """Low satellite count triggers warning."""
        monitor = HealthMonitor()
        packet = self._make_packet(gps_satellites=3)
        warnings = monitor.evaluate(packet)
        
        assert any(w.condition == "gps_degraded" for w in warnings)
    
    def test_high_wind_detected(self):
        """Wind above threshold triggers pause."""
        monitor = HealthMonitor()
        packet = self._make_packet(wind_estimate_m_s=12.0)
        warnings = monitor.evaluate(packet)
        
        assert any(w.condition == "wind_high" for w in warnings)
        assert any(w.recommended_action == FailsafeAction.PAUSE for w in warnings)
    
    def test_extreme_wind_rtl(self):
        """Extreme wind triggers RTL."""
        monitor = HealthMonitor()
        packet = self._make_packet(wind_estimate_m_s=20.0)
        warnings = monitor.evaluate(packet)
        
        assert any(w.condition == "wind_extreme" for w in warnings)
        assert any(w.recommended_action == FailsafeAction.RTL for w in warnings)
    
    def test_lost_link_detected(self):
        """Link loss triggers CRITICAL."""
        monitor = HealthMonitor()
        packet = self._make_packet(link_quality_pct=0.0)
        warnings = monitor.evaluate(packet)
        
        assert any(w.condition == "link_loss" for w in warnings)
        assert any(w.severity == HealthSeverity.CRITICAL for w in warnings)
    
    def test_drift_detected(self):
        """Off-track drift triggers warning."""
        monitor = HealthMonitor()
        packet = self._make_packet(off_track_m=8.0)
        warnings = monitor.evaluate(packet)
        
        assert any(w.condition == "drift" for w in warnings)
    
    def test_capture_failure_detected(self):
        """Missing captures trigger overlap risk warning."""
        monitor = HealthMonitor()
        mission = CompiledMission(estimated_captures=50)
        
        # 50% progress but only 18 captures (should have ~25, missed 7 > warn threshold 5)
        packet = self._make_packet(
            mission_progress_pct=50.0,
            capture_count=18,
            expected_captures=50,
        )
        warnings = monitor.evaluate(packet, mission)
        
        assert any(w.condition == "capture_failure" for w in warnings)
    
    def test_storage_low_detected(self):
        """Low storage triggers CRITICAL."""
        monitor = HealthMonitor()
        packet = self._make_packet(storage_available_mb=100)
        warnings = monitor.evaluate(packet)
        
        assert any(w.condition == "storage_low" for w in warnings)
    
    def test_warnings_have_severity_and_action(self):
        """All warnings have structured severity and recommended action."""
        monitor = HealthMonitor()
        packet = self._make_packet(battery_pct=5.0, gps_fix=False)
        warnings = monitor.evaluate(packet)
        
        for w in warnings:
            assert isinstance(w.severity, HealthSeverity)
            assert isinstance(w.recommended_action, FailsafeAction)
            assert w.message != ""
