"""
Test: Execution Reporter.

Validates that every mission produces an execution report, even failed ones.
"""

import pytest
from ..execution_reporter import ExecutionReporter
from ..mission_state_machine import MissionStateMachine
from ..telemetry_ingest import TelemetryIngestor
from ..schemas import (
    CompiledMission,
    CompiledWaypoint,
    LiveMissionState,
    MediaManifest,
    TelemetryPacket,
    VehicleState,
)
from ..media_handoff import HandoffResult


class TestExecutionReporter:
    
    def _run_successful_mission(self):
        """Simulate a successful mission for reporting."""
        sm = MissionStateMachine(execution_id="report_test")
        sm.transition(LiveMissionState.UPLOADED)
        sm.transition(LiveMissionState.READY)
        sm.transition(LiveMissionState.ARMING)
        sm.transition(LiveMissionState.IN_FLIGHT)
        
        mission = CompiledMission(
            mission_id="m001",
            execution_id="report_test",
            plot_id="orchard_01",
            flight_mode="mapping_mode",
            mission_type="full_plot_map",
            estimated_distance_m=1200.0,
            estimated_captures=50,
            waypoints=[CompiledWaypoint(index=i) for i in range(20)],
            target_overlap_pct=75.0,
        )
        
        ingestor = TelemetryIngestor(execution_id="report_test")
        for i in range(20):
            pkt = TelemetryPacket(
                execution_id="report_test",
                sequence=i,
                state=VehicleState(
                    battery_pct=100.0 - i * 2.0,
                    latitude=31.85 + i * 0.001,
                    longitude=34.72,
                    altitude_m=50.0,
                    groundspeed_m_s=5.0,
                ),
                current_waypoint_index=i,
                total_waypoints=20,
                mission_progress_pct=(i + 1) / 20 * 100.0,
                capture_count=i + 1,
                expected_captures=50,
            )
            ingestor.ingest(pkt)
        
        sm.transition(LiveMissionState.RETURNING)
        sm.transition(LiveMissionState.COMPLETED)
        
        return sm, mission, ingestor
    
    def test_successful_mission_report(self):
        """Successful mission produces a complete report."""
        sm, mission, ingestor = self._run_successful_mission()
        
        reporter = ExecutionReporter()
        report = reporter.build_report(
            state_machine=sm,
            compiled_mission=mission,
            telemetry=ingestor,
        )
        
        assert report.success
        assert report.final_state == LiveMissionState.COMPLETED
        assert report.execution_id == "report_test"
        assert report.mission_id == "m001"
        assert report.plot_id == "orchard_01"
        assert report.flight_mode == "mapping_mode"
        assert report.planned_distance_m == 1200.0
        assert report.flown_distance_m > 0
        assert report.battery_used_pct > 0
        assert report.actual_captures == 20
    
    def test_failed_mission_still_produces_report(self):
        """Failed mission produces an audit report."""
        sm = MissionStateMachine(execution_id="fail_test")
        sm.transition(LiveMissionState.UPLOADED)
        sm.transition(LiveMissionState.FAILED, "Upload error")
        
        reporter = ExecutionReporter()
        report = reporter.build_report(state_machine=sm)
        
        assert not report.success
        assert report.final_state == LiveMissionState.FAILED
        assert report.execution_id == "fail_test"
        assert report.duration_s >= 0
    
    def test_aborted_mission_report(self):
        """Aborted mission produces report."""
        sm = MissionStateMachine(execution_id="abort_test")
        sm.transition(LiveMissionState.UPLOADED)
        sm.transition(LiveMissionState.READY)
        sm.transition(LiveMissionState.ARMING)
        sm.transition(LiveMissionState.IN_FLIGHT)
        sm.transition(LiveMissionState.ABORTED, "low battery")
        
        reporter = ExecutionReporter()
        report = reporter.build_report(state_machine=sm)
        
        assert not report.success
        assert report.final_state == LiveMissionState.ABORTED
    
    def test_battery_usage_tracked(self):
        """Battery start/end/used are tracked."""
        sm, mission, ingestor = self._run_successful_mission()
        
        reporter = ExecutionReporter()
        report = reporter.build_report(
            state_machine=sm,
            compiled_mission=mission,
            telemetry=ingestor,
        )
        
        assert report.battery_start_pct == 100.0
        assert report.battery_end_pct < 100.0
        assert report.battery_used_pct > 0
    
    def test_media_handoff_status(self):
        """Report includes media handoff status."""
        sm, mission, ingestor = self._run_successful_mission()
        
        handoff = HandoffResult(
            target="photogrammetry",
            success=True,
            capture_count=20,
        )
        
        reporter = ExecutionReporter()
        report = reporter.build_report(
            state_machine=sm,
            compiled_mission=mission,
            telemetry=ingestor,
            handoff=handoff,
        )
        
        assert report.media_handoff_status == "completed"
        assert report.media_handoff_target == "photogrammetry"
    
    def test_planned_vs_flown(self):
        """Report includes planned vs flown comparison."""
        sm, mission, ingestor = self._run_successful_mission()
        
        reporter = ExecutionReporter()
        report = reporter.build_report(
            state_machine=sm,
            compiled_mission=mission,
            telemetry=ingestor,
        )
        
        assert report.planned_distance_m > 0
        assert report.flown_distance_m > 0
        assert report.planned_waypoints == 20
        assert report.completed_waypoints > 0
