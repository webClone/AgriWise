"""
Test: Preflight Gate.

Validates that impossible missions are rejected before upload.
"""

import pytest
from ..preflight import PreflightGate
from ..schemas import DispatchRequest, FailsafePolicy, VehicleState, WeatherSnapshot


class MockIntent:
    def __init__(self, flight_mode="mapping_mode", mission_type="full_plot_map", gsd=2.0):
        self.flight_mode = type('FM', (), {'value': flight_mode})()
        self.mission_type = type('MT', (), {'value': mission_type})()
        self.target_gsd_cm = gsd


class MockPlan:
    def __init__(self, time_min=5.0):
        self.estimated_flight_time_min = time_min


class TestPreflightGate:
    
    def _make_request(self, intent=None, plan=None, weather=None, driver="mock"):
        return DispatchRequest(
            mission_id="test",
            intent=intent or MockIntent(),
            flight_plan=plan or MockPlan(),
            weather=weather or WeatherSnapshot(),
            driver_type=driver,
        )
    
    def _make_good_state(self):
        return VehicleState(
            armed=False,
            battery_pct=95.0,
            gps_fix=True,
            gps_satellites=14,
            gps_hdop=1.0,
            wind_estimate_m_s=3.0,
            link_quality_pct=100.0,
            storage_available_mb=64000,
            camera_ready=True,
        )
    
    def test_clean_preflight_passes(self):
        """All checks pass with good conditions."""
        gate = PreflightGate()
        result = gate.evaluate(self._make_request(), self._make_good_state())
        
        assert result.passed
        assert len(result.failure_reasons) == 0
    
    def test_reject_low_battery(self):
        """Reject when battery is below critical threshold."""
        gate = PreflightGate()
        state = self._make_good_state()
        state.battery_pct = 15.0
        
        result = gate.evaluate(self._make_request(), state)
        
        assert not result.passed
        assert any("battery" in r.lower() or "Battery" in r for r in result.failure_reasons)
    
    def test_reject_battery_insufficient_for_mission(self):
        """Reject when battery won't last the full mission."""
        gate = PreflightGate()
        state = self._make_good_state()
        state.battery_pct = 35.0  # 35% available
        
        # Mission needs 30 minutes → ~45% battery
        plan = MockPlan(time_min=30.0)
        request = self._make_request(plan=plan)
        
        result = gate.evaluate(request, state)
        
        assert not result.passed
    
    def test_reject_no_gps_fix(self):
        """Reject when no GPS fix."""
        gate = PreflightGate()
        state = self._make_good_state()
        state.gps_fix = False
        
        result = gate.evaluate(self._make_request(), state)
        
        assert not result.passed
        assert any("gps" in r.lower() or "GPS" in r for r in result.failure_reasons)
    
    def test_reject_few_gps_satellites(self):
        """Reject when GPS satellites below minimum."""
        gate = PreflightGate()
        state = self._make_good_state()
        state.gps_satellites = 3
        
        result = gate.evaluate(self._make_request(), state)
        
        assert not result.passed
    
    def test_reject_unsafe_wind(self):
        """Reject when wind exceeds safe threshold."""
        gate = PreflightGate()
        weather = WeatherSnapshot(wind_speed_m_s=15.0)
        request = self._make_request(weather=weather)
        
        result = gate.evaluate(request, self._make_good_state())
        
        assert not result.passed
        assert any("wind" in r.lower() or "Wind" in r for r in result.failure_reasons)
    
    def test_reject_precipitation(self):
        """Reject when precipitation is active."""
        gate = PreflightGate()
        weather = WeatherSnapshot(precipitation=True)
        request = self._make_request(weather=weather)
        
        result = gate.evaluate(request, self._make_good_state())
        
        assert not result.passed
    
    def test_reject_leaf_level_full_plot(self):
        """HARD GATE: leaf-level (< 1.0cm GSD) full-plot Mapping is rejected."""
        gate = PreflightGate()
        intent = MockIntent(flight_mode="mapping_mode", mission_type="full_plot_map", gsd=0.3)
        request = self._make_request(intent=intent)
        
        result = gate.evaluate(request, self._make_good_state())
        
        assert not result.passed
        assert any("leaf" in r.lower() or "1.0cm" in r for r in result.failure_reasons)
    
    def test_allow_leaf_level_command_revisit(self):
        """Leaf-level IS allowed for Command/Revisit mode."""
        gate = PreflightGate()
        intent = MockIntent(flight_mode="command_revisit", mission_type="concern_zone_command", gsd=0.3)
        request = self._make_request(intent=intent)
        
        result = gate.evaluate(request, self._make_good_state())
        
        assert result.passed
    
    def test_reject_camera_not_ready(self):
        """Reject when camera is not ready."""
        gate = PreflightGate()
        state = self._make_good_state()
        state.camera_ready = False
        
        result = gate.evaluate(self._make_request(), state)
        
        assert not result.passed
    
    def test_machine_readable_failures(self):
        """Preflight returns machine-readable fail reasons."""
        gate = PreflightGate()
        state = VehicleState(
            battery_pct=5.0,
            gps_fix=False,
            camera_ready=False,
        )
        
        result = gate.evaluate(self._make_request(), state)
        
        assert not result.passed
        assert len(result.failure_reasons) >= 2
        assert all(isinstance(r, str) for r in result.failure_reasons)
