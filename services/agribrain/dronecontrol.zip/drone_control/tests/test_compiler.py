"""
Test: Mission Compiler.

Validates that FlightPlan compiles into vendor-neutral CompiledMission
with correct capture cadence, heading policy, and mission intent.
"""

import pytest
from ..mission_compiler import MissionCompiler
from ..schemas import CompiledMission


# --- Helpers ---

class MockWaypoint:
    def __init__(self, lat, lon, alt, action="capture", speed=5.0):
        self.lat = lat
        self.lon = lon
        self.alt_m = alt
        self.action = action
        self.speed_m_s = speed


class MockFlightPlan:
    def __init__(self, waypoints, pattern="boustrophedon", altitude=50.0, gsd=2.0):
        self.plan_id = "test_plan_001"
        self.intent_id = "test_intent_001"
        self.drone_profile = "standard_prosumer"
        self.pattern = pattern
        self.waypoints = waypoints
        self.flight_altitude_m = altitude
        self.achieved_gsd_cm = gsd
        self.estimated_flight_time_min = 5.0
        self.estimated_image_count = len(waypoints)


class MockIntent:
    def __init__(self, flight_mode="mapping_mode", mission_type="full_plot_map", plot_id="plot_01"):
        self.flight_mode = flight_mode
        self.mission_type = mission_type
        self.plot_id = plot_id
        self.intent_id = "test_intent_001"
        self.target_gsd_cm = 2.0
        self.required_overlap_pct = 75.0


# --- Tests ---

class TestMissionCompiler:
    """Mapping, row-aligned, orchard, and command missions compile correctly."""
    
    def test_boustrophedon_compiles(self):
        """Boustrophedon plans compile into executable waypoint/capture sequences."""
        wps = [MockWaypoint(31.85 + i * 0.001, 34.72, 50.0) for i in range(10)]
        plan = MockFlightPlan(wps, pattern="boustrophedon")
        intent = MockIntent(flight_mode="mapping_mode", mission_type="full_plot_map")
        
        compiler = MissionCompiler()
        result = compiler.compile(plan, intent, mission_id="test_001")
        
        assert isinstance(result, CompiledMission)
        assert len(result.waypoints) == 10
        assert result.pattern == "boustrophedon"
        assert result.flight_mode == "mapping_mode"
        assert result.mission_type == "full_plot_map"
        assert result.compiler_version == "v1"
        assert result.source_plan_id == "test_plan_001"
    
    def test_row_aligned_preserves_azimuth(self):
        """Row-aligned plans preserve heading policy."""
        wps = [MockWaypoint(31.85, 34.72 + i * 0.001, 40.0) for i in range(8)]
        plan = MockFlightPlan(wps, pattern="row_aligned", altitude=40.0)
        intent = MockIntent(flight_mode="mapping_mode", mission_type="row_audit")
        
        compiler = MissionCompiler()
        result = compiler.compile(plan, intent)
        
        assert result.pattern == "row_aligned"
        assert result.mission_type == "row_audit"
        assert result.heading_policy == "course"  # Mapping default
    
    def test_spiral_compiles_for_command(self):
        """Spiral/orbit plans compile for command-zone inspection."""
        wps = [MockWaypoint(31.85, 34.72, 20.0, action="hover") for _ in range(6)]
        plan = MockFlightPlan(wps, pattern="spiral", altitude=20.0, gsd=0.5)
        intent = MockIntent(flight_mode="command_revisit", mission_type="concern_zone_command")
        
        compiler = MissionCompiler()
        result = compiler.compile(plan, intent)
        
        assert result.pattern == "spiral"
        assert result.flight_mode == "command_revisit"
        assert result.heading_policy == "poi"  # Command default
        assert result.gimbal_pitch_deg == -45.0  # Command default (not nadir)
    
    def test_mapping_vs_command_compile_differently(self):
        """Mapping and Command compile with different heading/gimbal defaults."""
        wps = [MockWaypoint(31.85 + i * 0.001, 34.72, 50.0) for i in range(5)]
        plan = MockFlightPlan(wps)
        
        compiler = MissionCompiler()
        
        mapping = compiler.compile(plan, MockIntent(flight_mode="mapping_mode"))
        command = compiler.compile(plan, MockIntent(flight_mode="command_revisit"))
        
        # Heading policy differs
        assert mapping.heading_policy == "course"
        assert command.heading_policy == "poi"
        
        # Gimbal differs
        assert mapping.gimbal_pitch_deg == -90.0
        assert command.gimbal_pitch_deg == -45.0
    
    def test_capture_cadence_preserved(self):
        """Camera trigger cadence survives compilation."""
        wps = [MockWaypoint(31.85 + i * 0.001, 34.72, 50.0) for i in range(5)]
        plan = MockFlightPlan(wps)
        plan.capture_cadence_s = 3.0
        
        compiler = MissionCompiler()
        result = compiler.compile(plan, MockIntent())
        
        assert result.capture_cadence_s == 3.0
    
    def test_capture_count_correct(self):
        """Correct number of captures from waypoints with capture actions."""
        wps = [
            MockWaypoint(31.85, 34.72, 50.0, action="capture"),
            MockWaypoint(31.851, 34.72, 50.0, action="capture"),
            MockWaypoint(31.852, 34.72, 50.0, action="start_capture"),
            MockWaypoint(31.853, 34.72, 50.0, action="stop_capture"),
            MockWaypoint(31.854, 34.72, 50.0, action="capture"),
        ]
        plan = MockFlightPlan(wps)
        
        compiler = MissionCompiler()
        result = compiler.compile(plan, MockIntent())
        
        captures = sum(1 for wp in result.waypoints if wp.capture)
        assert captures == 5
        assert result.estimated_captures == 5
    
    def test_empty_plan_compiles(self):
        """Empty waypoint list produces empty compiled mission."""
        plan = MockFlightPlan([])
        compiler = MissionCompiler()
        result = compiler.compile(plan, MockIntent())
        
        assert len(result.waypoints) == 0
        assert result.estimated_captures == 0
    
    def test_mission_provenance_preserved(self):
        """Mission intent and planner metadata survive compilation."""
        wps = [MockWaypoint(31.85, 34.72, 50.0) for _ in range(3)]
        plan = MockFlightPlan(wps)
        intent = MockIntent(plot_id="orchard_alpha")
        
        compiler = MissionCompiler()
        result = compiler.compile(plan, intent, mission_id="mission_42")
        
        assert result.mission_id == "mission_42"
        assert result.plot_id == "orchard_alpha"
        assert result.intent_id == "test_intent_001"
        assert result.source_plan_id == "test_plan_001"
        assert result.drone_profile == "standard_prosumer"
