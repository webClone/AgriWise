"""
Verification Script for Layer 3 (Water Intelligence)
Tests ET calculation, Soil Moisture Balance, Stress Detection, and Irrigation logic.
"""

import sys
import os
import pandas as pd
import numpy as np

# Add services directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

def test_layer3():
    print("🧪 Starting Layer 3 Verification...")
    results = {}
    
    # Mock Data
    dates = pd.date_range(start="2023-06-01", periods=10, freq='D')
    t_min = pd.Series([15]*10, index=dates)
    t_max = pd.Series([30]*10, index=dates) # Hot
    precip = pd.Series([0]*10, index=dates) # Dry spell
    ndvi = pd.Series([0.6]*10, index=dates) # Healthy canopy initially
    ndmi = pd.Series([-0.1]*10, index=dates) # Low water content (Stress signature)
    
    # 1. Test ET Engine
    try:
        from layer3_water.evapotranspiration import et_engine
        print("✅ Import: ET Engine")
        
        et0 = et_engine.calculate_et0_hargreaves(t_min, t_max, 36.0, dates)
        kc = et_engine.calculate_dynamic_kc(ndvi, "vegetative")
        etc = et_engine.compute_etc(et0, kc)
        
        if etc.mean() > 0:
            results['et_calc'] = f"SUCCESS (Avg ETc: {etc.mean():.2f} mm/day)"
        else:
             results['et_calc'] = "FAILED"
            
    except Exception as e:
        results['et_calc'] = f"ERROR: {e}"

    # 2. Test Soil Moisture (Bucket)
    try:
        from layer3_water.soil_moisture import soil_engine
        print("✅ Import: Soil Moisture Engine")
        
        # Run balance on dry spell
        balance_df = soil_engine.run_water_balance(precip, etc, soil_type="loam")
        
        # Should see depletion increase
        start_dep = balance_df.iloc[0]['depletion_mm']
        end_dep = balance_df.iloc[-1]['depletion_mm']
        
        if end_dep > start_dep:
             results['soil_moisture'] = f"SUCCESS (Depletion rose: {start_dep:.1f} -> {end_dep:.1f} mm)"
        else:
             results['soil_moisture'] = "FAILED (Depletion did not increase in dry spell)"
             
    except Exception as e:
        results['soil_moisture'] = f"ERROR: {e}"

    # 3. Test Stress Detector
    try:
        from layer3_water.water_stress import water_stress_engine
        print("✅ Import: Water Stress Detector")
        
        stress = water_stress_engine.detect_water_stress(balance_df, ndmi)
        
        if stress['water_stress_prob'] > 20: # High due to low NDMI
             results['stress_detect'] = f"SUCCESS (Prob: {stress['water_stress_prob']}%)"
        else:
             results['stress_detect'] = f"WARNING (Prob low: {stress['water_stress_prob']}%)"
             
    except Exception as e:
        results['stress_detect'] = f"ERROR: {e}"

    # 4. Irrigation Optimizer
    try:
        from layer3_water.irrigation_optimizer import irrigation_engine
        print("✅ Import: Irrigation Optimizer")
        
        advice = irrigation_engine.recommend_irrigation(balance_df, soil_type="loam")
        
        if advice['action'] == 'irrigate':
             results['irrigation'] = f"SUCCESS (Advised: {advice['amount_mm']} mm)"
        else:
             results['irrigation'] = f"Wait... Action is {advice['action']} (Check threshold)"
             
    except Exception as e:
        results['irrigation'] = f"ERROR: {e}"

    print("\n--- Summary ---")
    for k, v in results.items():
        print(f"{k.upper()}: {v}")
        
    return results

if __name__ == "__main__":
    test_layer3()
