"""
Verification Script for Layer 7 (Risk & Scenario Intelligence)
Tests Risk, Climate, Scenario, and Trust engines.
"""

import sys
import os
from datetime import datetime, timedelta

# Add services directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

def test_layer7():
    print("🧪 Starting Layer 7 Verification...")
    results = {}
    
    # 1. Composite Risk
    try:
        from layer7_risk.risk_composite import risk_engine
        print("✅ Import: Risk Engine")
        
        # High Disease detected
        risk = risk_engine.calculate_composite_risk(
            water_stress_prob=10, 
            nutrient_stress_prob=10, 
            disease_risk_prob=80, 
            climate_shock_prob=0, 
            stage_label="flowering"
        )
        
        # Expect High Risk dominated by Disease
        if risk["risk_level"] == "Moderate" or risk["risk_level"] == "High":
             results['composite_risk'] = f"SUCCESS (Level: {risk['risk_level']}, Score: {risk['risk_score']})"
        else:
             results['composite_risk'] = f"FAILED (Score: {risk['risk_score']})"
             
    except Exception as e:
        results['composite_risk'] = f"ERROR: {e}"

    # 2. Climate Shock
    try:
        from layer7_risk.climate_shock import climate_engine
        print("✅ Import: Climate Engine")
        
        forecast = [{"temp_max": 38, "precip_mm": 0}] # Heatwave
        shock = climate_engine.detect_shocks(forecast)
        
        if shock["is_severe"] and "Heatwave" in shock["events"][0]:
             results['climate_shock'] = f"SUCCESS (Detected: {shock['events'][0]})"
        else:
             results['climate_shock'] = "FAILED"
             
    except Exception as e:
        results['climate_shock'] = f"ERROR: {e}"

    # 3. Scenario Simulator
    try:
        from layer7_risk.scenario_simulator import scenario_engine
        print("✅ Import: Scenario Engine")
        
        # High water stress baseline
        baseline = {"water_loss_factor": 0.4, "nutrient_loss_factor": 0.05}
        
        # Simulate Irrigation
        sim = scenario_engine.simulate_intervention(baseline, "irrigate", 10.0, 200.0)
        
        if sim["yield_delta"] > 0 and sim["roi_pct"] > 0:
             results['scenario_sim'] = f"SUCCESS (ROI: {sim['roi_pct']}%, Yield Gain: {sim['yield_delta']}t)"
        else:
             results['scenario_sim'] = "FAILED"
             
    except Exception as e:
        results['scenario_sim'] = f"ERROR: {e}"

    # 4. Trust Monitor
    try:
        from layer7_risk.trust_monitor import trust_monitor
        print("✅ Import: Trust Monitor")
        
        # Old satellite data
        old_date = datetime.now() - timedelta(days=12)
        trust = trust_monitor.evaluate_trust(old_date, sensor_active=False, forecast_available=True)
        
        if trust["trust_score"] < 60:
             results['trust_monitor'] = f"SUCCESS (Score: {trust['trust_score']}, Issues: {len(trust['issues'])})"
        else:
             results['trust_monitor'] = f"FAILED (Score too high: {trust['trust_score']})"
             
    except Exception as e:
        results['trust_monitor'] = f"ERROR: {e}"

    print("\n--- Summary ---")
    for k, v in results.items():
        print(f"{k.upper()}: {v}")
        
    return results

if __name__ == "__main__":
    test_layer7()
