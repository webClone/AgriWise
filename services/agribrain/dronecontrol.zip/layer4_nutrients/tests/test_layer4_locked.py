
import unittest
from datetime import datetime, timedelta
from typing import List, Dict

from services.agribrain.layer1_fusion.schema import FieldTensor, FieldTensorChannels
from services.agribrain.layer2_veg_int.schema import VegIntOutput, PhenologyOutput, ModeledCurveOutput, SpatialMetrics
from services.agribrain.layer3_decision.schema import PlotContext, DecisionOutput, DegradationMode, ExecutionPlan as L3Exec, QualityMetrics as L3Qual, AuditTrail as L3Audit
from services.agribrain.layer4_nutrients.runner import run_layer4_nutrients
from services.agribrain.layer4_nutrients.schema import (
    NutrientIntelligenceOutput, ActionId, Severity, RiskIfWrong, ApplicationMethod, RunMeta,
    Nutrient, Confounder, TimingWindow, SplitApplication, EnvironmentalRisk
)
from services.agribrain.orchestrator_v2.schema import OrchestratorInput

class TestLayer4LockedContract(unittest.TestCase):

    def setUp(self):
        self.dates = [(datetime(2025, 6, 1) + timedelta(days=i)).strftime("%Y-%m-%d") for i in range(30)]
        self.inputs = OrchestratorInput(
            plot_id="P1", geometry_hash="GEO123",
            date_range={"start": self.dates[0], "end": self.dates[-1]},
            crop_config={"crop": "Corn", "planting_date": "2025-05-01"},
            operational_context={"irrigation_type": "pivot", "constraints": {"nitrogen_limit_kg_ha": 300.0}},
            policy_snapshot={},
        )
        self.dummy_l3 = DecisionOutput(
            run_id_l3="L3_RUN", lineage={}, timestamp_utc=self.dates[-1],
            diagnoses=[], recommendations=[],
            execution_plan=L3Exec([], [], "", ""),
            quality_metrics=L3Qual(1.0, [], {}, {}, DegradationMode.NORMAL),
            audit=L3Audit({}, [], []),
        )

    def _make_mocks(self, rain_val=0.0, ndvi_val=0.7, tmax_val=30.0, stage="VEGETATIVE", d1=0.015, stable=True):
        ft_store = []
        for i in range(30):
            ft_store.append({
                "date": self.dates[i],
                FieldTensorChannels.PRECIPITATION.value: rain_val,
                FieldTensorChannels.TEMP_MAX.value: tmax_val,
                FieldTensorChannels.NDVI.value: ndvi_val,
            })
        ft = FieldTensor(plot_id="p1", run_id="r1")
        ft.daily_state = {
            "precipitation": [rain_val]*30,
            "temp_max": [tmax_val]*30,
            "ndvi": [ndvi_val]*30,
        }
        ft.plot_timeseries = ft_store

        pheno = PhenologyOutput(
            stage_by_day=[stage]*30, key_dates={}, confidence_by_day=[0.9]*30,
        )
        curve = ModeledCurveOutput(
            ndvi_fit=[ndvi_val]*30, ndvi_fit_d1=[d1]*30, quality=None, ndvi_fit_unc=[0.05]*30,
        )
        stability = SpatialMetrics(0.05, 0.05, "STABLE" if stable else "HETEROGENEOUS", 1.0)
        vi = VegIntOutput(
            run_id="r2", layer1_run_id="r1",
            curve=curve, phenology=pheno, anomalies=[], stability=stability, provenance={},
        )
        return ft, vi

    def test_invariant_class_types(self):
        print("\n🔒 Test Strict Types (Nutrient, Confounder, Dataclasses)")
        ft, vi = self._make_mocks(rain_val=5.0, ndvi_val=0.5)
        res = run_layer4_nutrients(self.inputs, ft, vi, self.dummy_l3)
        self.assertIn(Nutrient.N, res.nutrient_states)
        self.assertIsInstance(list(res.nutrient_states.keys())[0], Nutrient)
        n_state = res.nutrient_states[Nutrient.N]
        if n_state.confounders:
            self.assertIsInstance(n_state.confounders[0], Confounder)
        for rx in res.prescriptions:
            self.assertIsInstance(rx.timing_window, TimingWindow)
            self.assertIsInstance(rx.environmental_risk, EnvironmentalRisk)
            self.assertIsInstance(rx.rate_kg_ha, float)

    def test_invariant_A_prob_vs_confidence(self):
        print("\n🔒 Test Invariant A: Probability vs Confidence Separation")
        ft1, vi1 = self._make_mocks(rain_val=5.0, ndvi_val=0.5, d1=0.005)
        res1 = run_layer4_nutrients(self.inputs, ft1, vi1, self.dummy_l3)
        n1 = res1.nutrient_states[Nutrient.N]

        ft2, vi2 = self._make_mocks(rain_val=0.0, ndvi_val=0.5, d1=0.005)
        res2 = run_layer4_nutrients(self.inputs, ft2, vi2, self.dummy_l3)
        n2 = res2.nutrient_states[Nutrient.N]
        print(f"   Case1: P={n1.probability_deficient:.2f}, C={n1.confidence:.2f}")
        print(f"   Case2: P={n2.probability_deficient:.2f}, C={n2.confidence:.2f}")

    def test_invariant_B_evidence_change(self):
        print("\n🔒 Test Invariant B: Evidence Impact")
        ft1, vi1 = self._make_mocks(rain_val=5.0, ndvi_val=0.6)
        res1 = run_layer4_nutrients(self.inputs, ft1, vi1, self.dummy_l3)
        n1 = res1.nutrient_states[Nutrient.N]

        ft2, vi2 = self._make_mocks(rain_val=5.0, ndvi_val=0.2)
        res2 = run_layer4_nutrients(self.inputs, ft2, vi2, self.dummy_l3)
        n2 = res2.nutrient_states[Nutrient.N]
        print(f"   Case 1 (Mod): P={n1.probability_deficient:.2f}")
        print(f"   Case 2 (Sev): P={n2.probability_deficient:.2f}")
        self.assertGreater(n2.probability_deficient, n1.probability_deficient)

    def test_invariant_C_leaching_gating(self):
        print("\n🔒 Test Invariant C: Leaching Risk Gating")
        ft, vi = self._make_mocks(rain_val=30.0, ndvi_val=0.5)
        res = run_layer4_nutrients(self.inputs, ft, vi, self.dummy_l3)
        # Check for leaching risk awareness in prescriptions
        for rx in res.prescriptions:
            if rx.environmental_risk.leaching > 0.5:
                print(f"   -> High leaching risk detected: {rx.environmental_risk.leaching:.2f}")

    def test_invariant_E_determinism(self):
        print("\n🔒 Test Invariant E: Determinism & Run IDs")
        ft, vi = self._make_mocks(rain_val=5.0, ndvi_val=0.5)
        res1 = run_layer4_nutrients(self.inputs, ft, vi, self.dummy_l3)
        res2 = run_layer4_nutrients(self.inputs, ft, vi, self.dummy_l3)
        print(f"   Run ID 1: {res1.run_meta.run_id}")
        print(f"   Run ID 2: {res2.run_meta.run_id}")
        self.assertTrue(res1.run_meta.run_id.startswith("L4-"))
        self.assertEqual(res1.run_meta.run_id, res2.run_meta.run_id)
        self.assertEqual(
            res1.nutrient_states[Nutrient.N].probability_deficient,
            res2.nutrient_states[Nutrient.N].probability_deficient,
        )

if __name__ == "__main__":
    unittest.main()
