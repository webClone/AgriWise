
import unittest
from datetime import datetime, timedelta
from typing import List, Dict

from services.agribrain.layer1_fusion.schema import FieldTensor, FieldTensorChannels
from services.agribrain.layer2_veg_int.schema import VegIntOutput, PhenologyOutput, ModeledCurveOutput, SpatialMetrics
from services.agribrain.layer3_decision.schema import PlotContext, DecisionOutput, DegradationMode, ExecutionPlan as L3Exec, QualityMetrics as L3Qual, AuditTrail as L3Audit
from services.agribrain.layer4_nutrients.runner import run_layer4_nutrients
from services.agribrain.layer4_nutrients.schema import NutrientIntelligenceOutput, Nutrient
from services.agribrain.orchestrator_v2.schema import OrchestratorInput

class TestLayer4ResearchGrade(unittest.TestCase):

    def setUp(self):
        self.dates = [(datetime(2025, 6, 1) + timedelta(days=i)).strftime("%Y-%m-%d") for i in range(30)]
        self.inputs = OrchestratorInput(
            plot_id="P1", geometry_hash="GEO123",
            date_range={"start": self.dates[0], "end": self.dates[-1]},
            crop_config={"crop": "Corn", "planting_date": "2025-05-01"},
            operational_context={"irrigation_type": "pivot"},
            policy_snapshot={},
        )

    def _make_mocks(self, rain_val=0.0, ndvi_val=0.7, tmax_val=30.0, stage="VEGETATIVE", d1=0.015, stable=True):
        ft_store = []
        for i in range(30):
            ft_store.append({
                "date": self.dates[i],
                FieldTensorChannels.PRECIPITATION.value: rain_val,
                FieldTensorChannels.TEMP_MAX.value: tmax_val,
                FieldTensorChannels.NDVI.value: ndvi_val,
            })
        ft = FieldTensor(plot_id="p1", run_id="r1")
        ft.daily_state = {
            "precipitation": [rain_val]*30,
            "temp_max": [tmax_val]*30,
            "ndvi": [ndvi_val]*30,
        }
        ft.plot_timeseries = ft_store

        pheno = PhenologyOutput(stage_by_day=[stage]*30, confidence_by_day=[0.9]*30, key_dates={})
        curve = ModeledCurveOutput(ndvi_fit=[ndvi_val]*30, ndvi_fit_d1=[d1]*30, quality=None, ndvi_fit_unc=[0.05]*30)
        stability = SpatialMetrics(0.05, 0.05, "STABLE" if stable else "HETEROGENEOUS", 1.0)
        vi = VegIntOutput(run_id="r2", layer1_run_id="r1", curve=curve, phenology=pheno, anomalies=[], stability=stability, provenance={})

        ep = L3Exec(tasks=[], edges=[], recommended_start_date="", review_date="")
        qm = L3Qual(decision_reliability=1.0, missing_drivers=[], data_completeness={}, l2_confidence_summary={}, degradation_mode=DegradationMode.NORMAL)
        at = L3Audit(features_snapshot={}, log_odds_table=[], policy_checks=[])
        l3 = DecisionOutput(run_id_l3="r3", lineage={}, timestamp_utc=self.dates[-1],
                            diagnoses=[], recommendations=[], execution_plan=ep,
                            quality_metrics=qm, audit=at)
        return ft, vi, l3

    def test_true_nitrogen_deficiency(self):
        print("\n🧪 Test: True N Deficiency (Low NDVI + Good Water)")
        ft, vi, l3 = self._make_mocks(rain_val=5.0, ndvi_val=0.6, d1=0.01, stage="VEGETATIVE")
        res = run_layer4_nutrients(self.inputs, ft, vi, l3)
        n_state = res.nutrient_states.get(Nutrient.N)
        self.assertIsNotNone(n_state)
        print(f"   -> N State: ProbDef={n_state.probability_deficient:.2f}, Conf={n_state.confidence:.2f}")
        self.assertGreater(n_state.probability_deficient, 0.5)
        self.assertTrue(len(res.prescriptions) > 0)

    def test_water_stress_confounder(self):
        print("\n🧪 Test: Water Stress Confounder")
        ft, vi, l3 = self._make_mocks(rain_val=0.0, ndvi_val=0.6, d1=0.00, stage="VEGETATIVE")
        res = run_layer4_nutrients(self.inputs, ft, vi, l3)
        n_state = res.nutrient_states.get(Nutrient.N)
        self.assertIsNotNone(n_state)
        print(f"   -> N State: ProbDef={n_state.probability_deficient:.2f}, Conf={n_state.confidence:.2f}")
        # Under water stress, confounders should reduce confidence
        if n_state.confounders:
            print(f"   -> Confounders: {n_state.confounders}")

    def test_leaching_compliance_gate(self):
        print("\n🧪 Test: Leaching Risk Gate")
        ft, vi, l3 = self._make_mocks(rain_val=25.0, ndvi_val=0.6, d1=0.01, stage="VEGETATIVE")
        res = run_layer4_nutrients(self.inputs, ft, vi, l3)
        n_state = res.nutrient_states.get(Nutrient.N)
        print(f"   -> N State Prob: {n_state.probability_deficient:.2f}")
        # Check environmental risk awareness
        for rx in res.prescriptions:
            if rx.environmental_risk.leaching > 0.3:
                print(f"   -> Leaching risk for {rx.action_id}: {rx.environmental_risk.leaching:.2f}")

if __name__ == "__main__":
    unittest.main()
