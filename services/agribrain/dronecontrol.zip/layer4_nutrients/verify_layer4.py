"""
Verification Script for Layer 4 (Nutrient Intelligence)
Tests N-Deficiency, Response Curve, and Optimization logic.
"""

import sys
import os
import pandas as pd
import numpy as np

# Add services directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

def test_layer4():
    print("🧪 Starting Layer 4 Verification...")
    results = {}
    
    # Mock Data
    dates = pd.date_range(start="2023-06-01", periods=5, freq='D')
    ndvi_low = pd.Series([0.5, 0.52, 0.51, 0.5, 0.49], index=dates) # Stunted
    
    # 1. Test Nitrogen Deficiency
    try:
        from layer4_nutrients.nitrogen_deficiency import n_def_engine
        print("✅ Import: N-Deficiency Engine")
        
        # Test Case A: Low NDVI, No Water Stress -> High N Def
        res_a = n_def_engine.detect_deficiency(ndvi_low, "vegetative", water_stress_prob=10.0)
        
        # Test Case B: Low NDVI, High Water Stress -> Low N Def (Gated)
        res_b = n_def_engine.detect_deficiency(ndvi_low, "vegetative", water_stress_prob=80.0)
        
        if res_a["n_deficiency_prob"] > res_b["n_deficiency_prob"]:
            results['n_deficiency_gating'] = "SUCCESS (Prob reduced by water stress)"
        else:
            results['n_deficiency_gating'] = "FAILED (Gating logic issue)"
            
    except Exception as e:
        results['n_deficiency_gating'] = f"ERROR: {e}"

    # 2. Test Nutrient Response
    try:
        from layer4_nutrients.nutrient_response import response_engine
        print("✅ Import: Nutrient Response Model")
        
        resp = response_engine.simulate_response("wheat", current_n_prob=70, water_stress_prob=10)
        curve = resp["response_curve"]
        
        # Check diminishing returns (Gain at 100 < 4*Gain at 25 usually)
        if len(curve) > 0 and curve[-1]["yield_t_ha"] > resp["baseline_yield_t_ha"]:
             results['response_curve'] = f"SUCCESS (Gain: +{curve[-1]['gain_t_ha']} t/ha)"
        else:
             results['response_curve'] = "FAILED"
             
    except Exception as e:
        results['response_curve'] = f"ERROR: {e}"

    # 3. Test Optimizer
    try:
        from layer4_nutrients.fertilizer_optimizer import fertilizer_engine
        print("✅ Import: Fertilizer Optimizer")
        
        # Scenario: Good response, No rain
        plan = fertilizer_engine.optimization_plan(resp["response_curve"], "wheat", rain_forecast_mm=0.0)
        
        # Scenario: Rain
        plan_rain = fertilizer_engine.optimization_plan(resp["response_curve"], "wheat", rain_forecast_mm=50.0)
        
        if plan['action'] == 'apply' and plan_rain['action'] == 'hold':
             results['optimizer'] = f"SUCCESS (Dose: {plan['dose_kg_ha']}kg, Rain blocked application)"
        else:
             results['optimizer'] = f"FAILED (Plan: {plan['action']} / RainPlan: {plan_rain['action']})"
             
    except Exception as e:
        results['optimizer'] = f"ERROR: {e}"

    print("\n--- Summary ---")
    for k, v in results.items():
        print(f"{k.upper()}: {v}")
        
    return results

if __name__ == "__main__":
    test_layer4()
