# ⚠️ DEPRECATED — Legacy verification script (moved here Phase 3 Quarantine, 2026-03-25)
#    This references the old orchestrator.py which is now at legacy/orchestrator_v1.py.
#    Use orchestrator_v2/ tests instead.

import sys
import os
import json

# Add services to path
sys.path.append(os.path.join(os.getcwd(), 'services'))

from agribrain.orchestrator import AgriBrainOrchestrator

def main():
    print("--- STARTING VERIFICATION ---")
    
    # Mock Injected Context (Simulating DB data)
    injected_context = {
        "crop": "Tomato",
        "stage": "Flowering",
        "lat": 36.0,
        "lng": 3.0,
        "sensors": {
            "soil_moisture": 25, # LOW moisture -> Should trigger HIGH stress
            "temperature": 35    # HOT -> Should update weather
        },
        "soil": {
            "type": "Clay",
            "ph": 7.0
        }
    }
    
    orch = AgriBrainOrchestrator()
    print("Running Analysis with Injected Context...")
    
    # Capture stdout to avoid clutter
    # Actually, orchestrator prints JSON to stdout, so we just run it.
    orch.run_analysis("TEST-VERIFY", user_query="What is the risk level?", injected_context=injected_context)

if __name__ == "__main__":
    main()
