"""
Tests for Drone Mission Planner.

Validates geometry algorithms, feasibility gating, and execution quality scoring.
"""

import math
import pytest
from services.agribrain.drone_mission.schemas import MissionIntent, MissionType, FlightMode, CoveragePattern
from services.agribrain.drone_mission.planner import DroneMissionPlanner
from services.agribrain.drone_mission.capability_profiles import get_profile
from services.agribrain.drone_mission.coverage_patterns import compute_execution_quality
from services.agribrain.layer0.perception.drone_rgb.benchmark.cases import STANDARD_POLYGON

def test_planner_feasibility_gate():
    """Test that the leaf-level rule is enforced."""
    planner = DroneMissionPlanner()
    
    # 1. Invalid: Full plot mapping at leaf-level GSD
    intent_invalid = MissionIntent(
        intent_id="test_invalid",
        plot_id="test",
        mission_type=MissionType.FULL_PLOT_MAP,
        flight_mode=FlightMode.MAPPING_MODE,
        polygon_geojson=STANDARD_POLYGON,
        target_gsd_cm=0.5 # Leaf level
    )
    
    plan1 = planner.plan_mission(intent_invalid)
    assert not plan1.is_feasible
    assert "rejects GSD" in plan1.infeasibility_reason
    
    # 2. Valid: Command revisit at leaf-level GSD
    intent_valid = MissionIntent(
        intent_id="test_valid",
        plot_id="test",
        mission_type=MissionType.CONCERN_ZONE_COMMAND,
        flight_mode=FlightMode.COMMAND_REVISIT_MODE,
        polygon_geojson=STANDARD_POLYGON,
        target_gsd_cm=0.5
    )
    
    plan2 = planner.plan_mission(intent_valid)
    assert plan2.is_feasible

def test_planner_row_aligned_geometry():
    """Test that row-aligned pattern respects the azimuth."""
    planner = DroneMissionPlanner()
    
    intent = MissionIntent(
        intent_id="test_row",
        plot_id="test",
        mission_type=MissionType.ROW_AUDIT,
        flight_mode=FlightMode.MAPPING_MODE,
        polygon_geojson=STANDARD_POLYGON,
        target_gsd_cm=2.0
    )
    
    plan = planner.plan_mission(intent)
    
    assert plan.pattern == CoveragePattern.ROW_ALIGNED
    assert len(plan.waypoints) > 0


def test_row_aligned_pass_azimuth_numerical():
    """Test that row-aligned waypoints produce passes at the correct azimuth.
    
    Plans a row-aligned mission with 0° azimuth (North-South rows).
    The dominant pass bearing (between consecutive same-direction waypoints)
    should be approximately 0° or 180° (N-S direction), within ±10°.
    """
    planner = DroneMissionPlanner()
    
    # Use a larger polygon so we get multiple passes
    large_polygon = {
        "type": "Polygon",
        "coordinates": [[
            [0.0, 0.0], [0.003, 0.0], [0.003, 0.003], [0.0, 0.003], [0.0, 0.0]
        ]]
    }
    
    intent = MissionIntent(
        intent_id="test_azimuth",
        plot_id="test",
        mission_type=MissionType.ROW_AUDIT,
        flight_mode=FlightMode.MAPPING_MODE,
        polygon_geojson=large_polygon,
        target_gsd_cm=2.0
    )
    
    plan = planner.plan_mission(intent)
    assert plan.is_feasible
    assert len(plan.waypoints) >= 4  # Need at least 2 passes

    # Compute bearing for each consecutive waypoint pair
    bearings = []
    for i in range(len(plan.waypoints) - 1):
        w1, w2 = plan.waypoints[i], plan.waypoints[i + 1]
        dlat = (w2.lat - w1.lat) * 111000.0
        dlon = (w2.lon - w1.lon) * 85000.0
        dist = math.sqrt(dlat ** 2 + dlon ** 2)
        if dist < 1.0:
            continue  # Skip near-zero moves
        bearing_deg = math.degrees(math.atan2(dlon, dlat)) % 360
        bearings.append(bearing_deg)

    assert len(bearings) > 0, "No significant waypoint segments found"

    # For a 0° row azimuth, passes should run roughly East-West (90° or 270°),
    # because the boustrophedon sweeps perpendicular to the row direction.
    # The row-aligned planner rotates to align rows horizontally, then sweeps N-S,
    # then rotates back. With 0° azimuth, the rotation is a no-op, so passes
    # alternate between East (90°) and West (270°), with N-S transitions.
    # The N-S transitions should be roughly 0° or 180°.
    # We check that the dominant bearing is one of these four cardinal directions ±15°.
    for b in bearings:
        # Normalize to nearest cardinal: 0, 90, 180, 270
        nearest = min([0, 90, 180, 270, 360], key=lambda c: min(abs(b - c), 360 - abs(b - c)))
        diff = min(abs(b - nearest), 360 - abs(b - nearest))
        assert diff < 15, (
            f"Waypoint bearing {b:.1f}° is not within ±15° of any cardinal direction. "
            f"Expected passes roughly aligned to cardinal axes for 0° row azimuth."
        )


def test_execution_quality_computable():
    """Test that compute_execution_quality runs and returns reasonable values."""
    planner = DroneMissionPlanner()
    profile = get_profile("standard_prosumer")
    
    intent = MissionIntent(
        intent_id="test_eq",
        plot_id="test",
        mission_type=MissionType.FULL_PLOT_MAP,
        flight_mode=FlightMode.MAPPING_MODE,
        polygon_geojson=STANDARD_POLYGON,
        target_gsd_cm=2.0
    )
    
    plan = planner.plan_mission(intent)
    assert plan.is_feasible
    
    footprint_w, footprint_h = profile.calculate_footprint(plan.flight_altitude_m)
    polygon_coords = STANDARD_POLYGON["coordinates"][0]
    
    eq = compute_execution_quality(
        polygon_coords=polygon_coords,
        waypoints=plan.waypoints,
        footprint_w_m=footprint_w,
        footprint_h_m=footprint_h,
        required_overlap_pct=70.0,
        sample_density=40,
    )
    
    # Sanity bounds: coverage should be positive (planner does cover something)
    assert eq.coverage_completeness > 0.5, (
        f"Coverage {eq.coverage_completeness:.2f} is unreasonably low for a mapping mission"
    )
    # Waste should be < 1.0 (we're not flying entirely outside the polygon)
    assert eq.outside_polygon_waste < 1.0, (
        f"Waste {eq.outside_polygon_waste:.2f} implies zero footprint inside polygon"
    )
    # Overlap should be a valid fraction
    assert 0.0 <= eq.overlap_compliance <= 1.0


# ============================================================================
# V1.5 Planner Tests
# ============================================================================

L_POLYGON = {
    "type": "Polygon",
    "coordinates": [[
        [0.0, 0.0], [0.002, 0.0], [0.002, 0.0008],
        [0.001, 0.0008], [0.001, 0.0015], [0.0, 0.0015], [0.0, 0.0]
    ]]
}

TRIANGLE_POLYGON = {
    "type": "Polygon",
    "coordinates": [[
        [0.0, 0.0], [0.002, 0.0], [0.001, 0.0015], [0.0, 0.0]
    ]]
}

NARROW_POLYGON = {
    "type": "Polygon",
    "coordinates": [[
        [0.0, 0.0], [0.0003, 0.0], [0.0003, 0.0015], [0.0, 0.0015], [0.0, 0.0]
    ]]
}


class TestAdaptiveOverlap:
    """V1.5: Adaptive boustrophedon skips narrow passes."""
    
    def test_narrow_polygon_fewer_passes(self):
        from services.agribrain.drone_mission.coverage_patterns import (
            plan_boustrophedon,
            plan_adaptive_boustrophedon,
        )
        alt = 50.0
        spacing = 15.0
        
        basic = plan_boustrophedon(NARROW_POLYGON, alt, spacing)
        adaptive = plan_adaptive_boustrophedon(NARROW_POLYGON, alt, spacing)
        
        # Adaptive should have fewer or equal waypoints (skips narrow passes)
        assert len(adaptive) <= len(basic)


class TestIrregularPolygon:
    """V1.5: L-shaped and triangular polygons don't crash the planner."""
    
    def test_l_polygon_doesnt_crash(self):
        planner = DroneMissionPlanner()
        intent = MissionIntent(
            intent_id="test_L",
            plot_id="test",
            mission_type=MissionType.FULL_PLOT_MAP,
            flight_mode=FlightMode.MAPPING_MODE,
            polygon_geojson=L_POLYGON,
            target_gsd_cm=3.0,
        )
        plan = planner.plan_mission(intent)
        assert plan.is_feasible
        assert len(plan.waypoints) >= 2
    
    def test_triangle_coverage_positive(self):
        planner = DroneMissionPlanner()
        profile = get_profile("standard_prosumer")
        intent = MissionIntent(
            intent_id="test_tri",
            plot_id="test",
            mission_type=MissionType.FULL_PLOT_MAP,
            flight_mode=FlightMode.MAPPING_MODE,
            polygon_geojson=TRIANGLE_POLYGON,
            target_gsd_cm=3.0,
        )
        plan = planner.plan_mission(intent)
        assert plan.is_feasible
        
        footprint_w, footprint_h = profile.calculate_footprint(plan.flight_altitude_m)
        coords = TRIANGLE_POLYGON["coordinates"][0]
        eq = compute_execution_quality(
            polygon_coords=coords,
            waypoints=plan.waypoints,
            footprint_w_m=footprint_w,
            footprint_h_m=footprint_h,
            sample_density=40,
        )
        assert eq.coverage_completeness > 0.5


class TestPassDirectionOptimization:
    """V1.5: Pass direction optimizer picks best angle."""
    
    def test_optimizer_returns_valid_waypoints(self):
        from services.agribrain.drone_mission.coverage_patterns import optimize_pass_direction
        
        wps, best_dir = optimize_pass_direction(
            STANDARD_POLYGON, altitude_m=50.0, spacing_m=15.0,
        )
        assert len(wps) >= 2
        assert best_dir >= 0
    
    def test_optimizer_with_hint(self):
        from services.agribrain.drone_mission.coverage_patterns import optimize_pass_direction
        
        wps, best_dir = optimize_pass_direction(
            STANDARD_POLYGON, altitude_m=50.0, spacing_m=15.0,
            row_azimuth_hint_deg=45.0,
        )
        assert len(wps) >= 2

