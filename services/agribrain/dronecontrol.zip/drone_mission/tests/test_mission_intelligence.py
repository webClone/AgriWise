"""
Tests for Drone V1.5B Mission Intelligence.

Validates anomaly bridge, mission history, temporal diff, refly planner,
and hotspot summarization.
"""

from datetime import datetime, timedelta
import pytest

from services.agribrain.drone_mission.anomaly_bridge import (
    AnomalyReport, MissionSuggestion, MissionSuggestionEngine,
)
from services.agribrain.drone_mission.mission_history import MissionRecord, MissionHistory
from services.agribrain.drone_mission.temporal_diff import TemporalDiffEngine, TemporalChange
from services.agribrain.drone_mission.refly_planner import ReflyPlanner, WeakZone
from services.agribrain.drone_mission.hotspot_summarizer import HotspotSummarizer, HotspotSummary
from services.agribrain.drone_mission.command_agent import DroneCommandAgent
from services.agribrain.drone_mission.schemas import MissionType, FlightMode
from services.agribrain.layer0.observation_packet import ObservationPacket, ObservationSource, ObservationType
from services.agribrain.layer0.perception.drone_rgb.benchmark.cases import STANDARD_POLYGON


NOW = datetime(2026, 4, 24, 12, 0, 0)


def _make_report(
    anomaly_type="vegetation_drop",
    severity=0.7,
    confidence=0.8,
    plot_id="plot_1",
    ts=None,
):
    return AnomalyReport(
        source="satellite_rgb",
        plot_id=plot_id,
        anomaly_type=anomaly_type,
        severity=severity,
        confidence=confidence,
        polygon_geojson=STANDARD_POLYGON,
        timestamp=ts or NOW,
    )


# ============================================================================
# Anomaly Bridge Tests
# ============================================================================

class TestAnomalyBridge:
    """Tests for AnomalyReport identity and MissionSuggestionEngine gating."""

    def test_report_id_deterministic(self):
        r1 = _make_report()
        r2 = _make_report()
        assert r1.report_id == r2.report_id, "Same content → same report_id"

    def test_report_id_changes_with_content(self):
        r1 = _make_report(anomaly_type="vegetation_drop")
        r2 = _make_report(anomaly_type="weed_pressure_high")
        assert r1.report_id != r2.report_id

    def test_suggestion_maps_anomaly_to_mission(self):
        engine = MissionSuggestionEngine()
        report = _make_report(anomaly_type="vegetation_drop")
        suggestion = engine.evaluate(report)
        assert not suggestion.suppressed
        assert suggestion.intent.mission_type == MissionType.ROW_AUDIT

    def test_suggestion_maps_disease_to_command(self):
        engine = MissionSuggestionEngine()
        report = _make_report(anomaly_type="disease_suspected")
        suggestion = engine.evaluate(report)
        assert not suggestion.suppressed
        assert suggestion.intent.mission_type == MissionType.CONCERN_ZONE_COMMAND
        assert suggestion.intent.flight_mode == FlightMode.COMMAND_REVISIT_MODE

    def test_low_severity_suppressed(self):
        engine = MissionSuggestionEngine()
        report = _make_report(severity=0.1)
        suggestion = engine.evaluate(report)
        assert suggestion.suppressed
        assert "Severity" in suggestion.suppression_reason

    def test_low_confidence_suppressed(self):
        engine = MissionSuggestionEngine()
        report = _make_report(confidence=0.2)
        suggestion = engine.evaluate(report)
        assert suggestion.suppressed
        assert "Confidence" in suggestion.suppression_reason

    def test_recency_suppression(self):
        engine = MissionSuggestionEngine()
        report = _make_report()
        recent = {
            "plot_1:vegetation_drop:": NOW - timedelta(hours=12)
        }
        suggestion = engine.evaluate(report, recent)
        assert suggestion.suppressed
        assert "recency" in suggestion.suppression_reason.lower()

    def test_recency_allows_old_inspection(self):
        engine = MissionSuggestionEngine()
        report = _make_report()
        recent = {
            "plot_1:vegetation_drop:": NOW - timedelta(days=10)
        }
        suggestion = engine.evaluate(report, recent)
        assert not suggestion.suppressed

    def test_urgency_score_computed(self):
        engine = MissionSuggestionEngine()
        report = _make_report(severity=0.9, confidence=0.9)
        suggestion = engine.evaluate(report)
        assert suggestion.urgency_score > 0.5


# ============================================================================
# Mission History Tests
# ============================================================================

class TestMissionHistory:
    """Tests for MissionRecord storage and retrieval."""

    def test_record_and_retrieve(self):
        history = MissionHistory()
        rec = MissionRecord(
            mission_id="m1", plot_id="p1", timestamp=NOW,
            canopy_cover=0.7, weed_pressure=0.05,
            source_run_id="plan_abc", trigger_reason="user_command",
        )
        history.record(rec)
        assert history.count("p1") == 1
        assert history.get_previous("p1").mission_id == "m1"

    def test_previous_returns_most_recent(self):
        history = MissionHistory()
        history.record(MissionRecord(mission_id="m1", plot_id="p1", timestamp=NOW - timedelta(days=5)))
        history.record(MissionRecord(mission_id="m2", plot_id="p1", timestamp=NOW - timedelta(days=1)))
        assert history.get_previous("p1").mission_id == "m2"

    def test_previous_with_before_filter(self):
        history = MissionHistory()
        history.record(MissionRecord(mission_id="m1", plot_id="p1", timestamp=NOW - timedelta(days=5)))
        history.record(MissionRecord(mission_id="m2", plot_id="p1", timestamp=NOW - timedelta(days=1)))
        # Get previous before 3 days ago
        prev = history.get_previous("p1", before=NOW - timedelta(days=3))
        assert prev.mission_id == "m1"

    def test_decision_context_preserved(self):
        history = MissionHistory()
        rec = MissionRecord(
            mission_id="m1", plot_id="p1", timestamp=NOW,
            source_run_id="plan_xyz",
            planner_version="v1.5",
            qa_version="v1.5",
            trigger_reason="anomaly_vegetation_drop",
            originating_anomaly_id="abc123",
            mission_type=MissionType.ROW_AUDIT,
            flight_mode=FlightMode.MAPPING_MODE,
        )
        history.record(rec)
        got = history.get_previous("p1")
        assert got.source_run_id == "plan_xyz"
        assert got.trigger_reason == "anomaly_vegetation_drop"
        assert got.originating_anomaly_id == "abc123"

    def test_anomaly_timestamps_for_suppression(self):
        history = MissionHistory()
        history.record(MissionRecord(
            mission_id="m1", plot_id="p1", timestamp=NOW,
            trigger_reason="anomaly_vegetation_drop",
        ))
        ts_map = history.get_recent_anomaly_timestamps("p1")
        assert "p1:vegetation_drop:" in ts_map


# ============================================================================
# Temporal Diff Tests
# ============================================================================

class TestTemporalDiff:
    """Tests for TemporalDiffEngine change detection."""

    def test_stable_when_no_change(self):
        engine = TemporalDiffEngine()
        current = MissionRecord(mission_id="m2", plot_id="p1", timestamp=NOW, canopy_cover=0.7, weed_pressure=0.05)
        previous = MissionRecord(mission_id="m1", plot_id="p1", timestamp=NOW - timedelta(days=7), canopy_cover=0.7, weed_pressure=0.05)
        changes = engine.compare(current, previous)
        for c in changes:
            assert c.direction == "stable"

    def test_weed_increase_flagged_worsened(self):
        engine = TemporalDiffEngine()
        current = MissionRecord(mission_id="m2", plot_id="p1", timestamp=NOW, weed_pressure=0.25)
        previous = MissionRecord(mission_id="m1", plot_id="p1", timestamp=NOW - timedelta(days=7), weed_pressure=0.05)
        changes = engine.compare(current, previous)
        weed = next(c for c in changes if c.metric == "weed_pressure")
        assert weed.direction == "worsened"
        assert weed.significance == "severe"

    def test_canopy_recovery_flagged_improved(self):
        engine = TemporalDiffEngine()
        current = MissionRecord(mission_id="m2", plot_id="p1", timestamp=NOW, canopy_cover=0.80)
        previous = MissionRecord(mission_id="m1", plot_id="p1", timestamp=NOW - timedelta(days=7), canopy_cover=0.50)
        changes = engine.compare(current, previous)
        canopy = next(c for c in changes if c.metric == "canopy_cover")
        assert canopy.direction == "improved"
        assert canopy.significance == "severe"

    def test_tree_loss_flagged_severe(self):
        engine = TemporalDiffEngine()
        current = MissionRecord(mission_id="m2", plot_id="p1", timestamp=NOW, tree_count=14)
        previous = MissionRecord(mission_id="m1", plot_id="p1", timestamp=NOW - timedelta(days=7), tree_count=16)
        changes = engine.compare(current, previous)
        trees = next(c for c in changes if c.metric == "tree_count")
        assert trees.direction == "worsened"
        assert trees.significance == "severe"

    def test_summary_readable(self):
        engine = TemporalDiffEngine()
        current = MissionRecord(mission_id="m2", plot_id="p1", timestamp=NOW, weed_pressure=0.25)
        previous = MissionRecord(mission_id="m1", plot_id="p1", timestamp=NOW - timedelta(days=7), weed_pressure=0.05)
        changes = engine.compare(current, previous)
        text = engine.summary(changes)
        assert "SEVERE" in text
        assert "weed_pressure" in text


# ============================================================================
# Refly Planner Tests
# ============================================================================

class TestReflyPlanner:
    """Tests for weak zone detection and refly plan generation."""

    def test_identifies_low_coverage(self):
        planner = ReflyPlanner()
        zones = planner.identify_weak_zones(qa_score=0.9, coverage_completeness=0.60)
        assert len(zones) >= 1
        assert any(z.weakness_type == "low_coverage" for z in zones)

    def test_no_zones_for_full_coverage(self):
        planner = ReflyPlanner()
        zones = planner.identify_weak_zones(qa_score=0.95, coverage_completeness=0.98)
        assert len(zones) == 0

    def test_identifies_quality_degradation(self):
        planner = ReflyPlanner()
        zones = planner.identify_weak_zones(qa_score=0.3, coverage_completeness=0.95)
        assert any(z.weakness_type == "quality_degradation" for z in zones)

    def test_refly_plan_generated(self):
        planner = ReflyPlanner()
        zones = [WeakZone(zone_bbox={}, weakness_type="low_coverage", confidence=0.5, area_fraction=0.3)]
        plan = planner.plan_refly(zones, STANDARD_POLYGON, plot_id="p1")
        assert plan is not None
        assert len(plan.waypoints) >= 2
        assert plan.is_feasible

    def test_refly_not_generated_for_tiny_zones(self):
        planner = ReflyPlanner()
        zones = [WeakZone(zone_bbox={}, weakness_type="low_coverage", confidence=0.8, area_fraction=0.01)]
        plan = planner.plan_refly(zones, STANDARD_POLYGON, plot_id="p1")
        assert plan is None

    def test_gap_map_extracts_sub_zones(self):
        """Spatial gap map with one gappy quadrant → targeted WeakZone with bbox."""
        from services.agribrain.layer0.perception.drone_rgb.schemas import DroneStructuralMap
        planner = ReflyPlanner()
        
        # 20x20 grid, only top-left 10x10 has gaps
        gap_grid = [[0.0] * 20 for _ in range(20)]
        for y in range(10):
            for x in range(10):
                gap_grid[y][x] = 1.0
        
        smap = DroneStructuralMap(map_type="stand_gaps", resolution_cm=10.0, data_grid=gap_grid)
        zones = planner.identify_weak_zones(
            qa_score=0.9, coverage_completeness=0.95,
            spatial_maps=[smap], plot_polygon=STANDARD_POLYGON,
        )
        
        # Should detect at least 1 zone, not all 4 quadrants
        assert len(zones) >= 1
        assert len(zones) < 4, "Should only flag the gappy quadrant, not all"
        # The zone should have a bbox
        for z in zones:
            assert z.zone_bbox, "Zone must have a bounding box"
            assert "min_lat" in z.zone_bbox

    def test_targeted_refly_uses_sub_polygon(self):
        """When zones have bboxes, refly should target sub-region, not full plot."""
        planner = ReflyPlanner()
        
        # Create a zone in the top-left quarter of the plot
        full_bbox = planner._polygon_to_bbox(STANDARD_POLYGON)
        lat_mid = (full_bbox["min_lat"] + full_bbox["max_lat"]) / 2
        lon_mid = (full_bbox["min_lon"] + full_bbox["max_lon"]) / 2
        
        sub_bbox = {
            "min_lat": full_bbox["min_lat"],
            "max_lat": lat_mid,
            "min_lon": full_bbox["min_lon"],
            "max_lon": lon_mid,
        }
        
        zones = [WeakZone(zone_bbox=sub_bbox, weakness_type="high_gap_density", confidence=0.5, area_fraction=0.20)]
        plan = planner.plan_refly(zones, STANDARD_POLYGON, plot_id="p1")
        
        assert plan is not None
        assert plan.is_feasible
        # The refly plan should have fewer waypoints than a full-plot plan
        full_plan = planner.plan_refly(
            [WeakZone(zone_bbox=full_bbox, weakness_type="low_coverage", confidence=0.5, area_fraction=0.30)],
            STANDARD_POLYGON, plot_id="p1",
        )
        assert full_plan is not None
        assert len(plan.waypoints) <= len(full_plan.waypoints), \
            f"Targeted ({len(plan.waypoints)} wps) should be ≤ full-plot ({len(full_plan.waypoints)} wps)"


# ============================================================================
# Hotspot Summarizer Tests
# ============================================================================

def _make_packet(symptom, crop="wheat", organ="leaf", qa_score=0.8):
    """Helper to create a mock ObservationPacket for hotspot tests."""
    from services.agribrain.layer0.observation_packet import QAMetadata
    pkt = ObservationPacket(
        source=ObservationSource.FARMER_PHOTO,
        obs_type=ObservationType.IMAGE,
        payload={
            "top_symptom": symptom,
            "crop": crop,
            "organ": organ,
        },
    )
    pkt.qa = QAMetadata(scene_score=qa_score)
    return pkt


class TestHotspotSummarizer:
    """Tests for multi-frame hotspot aggregation."""

    def test_unanimous_verdict(self):
        summarizer = HotspotSummarizer()
        packets = [
            _make_packet("chlorosis"),
            _make_packet("chlorosis"),
            _make_packet("chlorosis"),
        ]
        summary = summarizer.summarize(packets, "zone_1", "m1")
        assert summary.top_symptom == "chlorosis"
        assert summary.consensus_type == "unanimous"
        assert summary.frame_count == 3

    def test_majority_verdict(self):
        summarizer = HotspotSummarizer()
        packets = [
            _make_packet("chlorosis"),
            _make_packet("chlorosis"),
            _make_packet("necrosis"),
        ]
        summary = summarizer.summarize(packets, "zone_1", "m1")
        assert summary.top_symptom == "chlorosis"
        assert summary.consensus_type == "majority"

    def test_mixed_evidence_surfaces(self):
        """Best frame shows necrosis (QA 0.9) but 2 of 4 frames say chlorosis."""
        summarizer = HotspotSummarizer()
        packets = [
            _make_packet("chlorosis", qa_score=0.5),
            _make_packet("chlorosis", qa_score=0.5),
            _make_packet("necrosis", qa_score=0.9),   # Best frame, severe symptom
            _make_packet("healthy", qa_score=0.4),
        ]
        summary = summarizer.summarize(packets, "zone_1", "m1")
        # Chlorosis has 50% vote but best frame is necrosis with high QA
        assert summary.consensus_type == "mixed_evidence"
        assert summary.top_symptom == "necrosis"  # Best frame wins in mixed

    def test_strong_majority_overrides_best_frame(self):
        """80% majority should not be overruled even if best frame disagrees."""
        summarizer = HotspotSummarizer()
        packets = [
            _make_packet("chlorosis", qa_score=0.7),
            _make_packet("chlorosis", qa_score=0.7),
            _make_packet("chlorosis", qa_score=0.7),
            _make_packet("chlorosis", qa_score=0.7),
            _make_packet("necrosis", qa_score=0.9),
        ]
        summary = summarizer.summarize(packets, "zone_1", "m1")
        # 80% vote for chlorosis → majority holds
        assert summary.top_symptom == "chlorosis"
        assert summary.consensus_type == "majority"

    def test_crop_consensus(self):
        summarizer = HotspotSummarizer()
        packets = [
            _make_packet("chlorosis", crop="wheat"),
            _make_packet("chlorosis", crop="wheat"),
            _make_packet("chlorosis", crop="barley"),
        ]
        summary = summarizer.summarize(packets, "zone_1", "m1")
        assert summary.crop_consensus == "wheat"

    def test_single_frame_passthrough(self):
        summarizer = HotspotSummarizer()
        packets = [_make_packet("necrosis")]
        summary = summarizer.summarize(packets, "zone_1", "m1")
        assert summary.top_symptom == "necrosis"
        assert summary.frame_count == 1
        assert summary.consensus_type == "unanimous"


# ============================================================================
# Command Agent Integration Tests
# ============================================================================

class TestCommandAgentV15B:
    """Tests for the integrated command agent with anomaly + refly support."""

    def test_process_anomaly_report(self):
        agent = DroneCommandAgent()
        report = _make_report()
        suggestion = agent.process_anomaly_report(report)
        assert isinstance(suggestion, MissionSuggestion)
        assert not suggestion.suppressed

    def test_process_refly_request_needed(self):
        agent = DroneCommandAgent()
        plan = agent.process_refly_request(
            qa_score=0.9, coverage_completeness=0.60,
            plot_polygon=STANDARD_POLYGON, plot_id="p1",
        )
        assert plan is not None
        assert len(plan.waypoints) >= 2

    def test_process_refly_request_not_needed(self):
        agent = DroneCommandAgent()
        plan = agent.process_refly_request(
            qa_score=0.95, coverage_completeness=0.98,
            plot_polygon=STANDARD_POLYGON, plot_id="p1",
        )
        assert plan is None
