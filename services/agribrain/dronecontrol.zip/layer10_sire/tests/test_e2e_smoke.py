"""
End-to-End Orchestrator Smoke Test
====================================

Proves the full import chain and L10 runtime contract from this archive.

Tests:
  1. Registry imports cleanly (10 layers)
  2. L1 runner imports (corrections + validator chain)
  3. L10 runtime output has: quicklooks, raster_pack, vector_pack, tile_manifest
  4. Every surface has grounding_class
  5. grounding_summary in provenance matches actual surface tags
  6. Uncertainty histograms are computed (if surfaces present)
"""
import random; random.seed(42)
from types import SimpleNamespace

ok = 0; fail = 0
def check(name, cond, detail=""):
    global ok, fail
    if cond: ok += 1
    else: fail += 1; print(f"  FAIL: {name}: {detail}")

# ====================================================================
# 1. FULL REGISTRY IMPORT
# ====================================================================
print("=== 1. FULL REGISTRY IMPORT ===")
try:
    from services.agribrain.orchestrator_v2.registry import LAYER_REGISTRY, LayerId
    check("registry_imports", True)
    check("registry_count_10", len(LAYER_REGISTRY) == 10, f"got {len(LAYER_REGISTRY)}")
    check("L1_in_registry", LayerId.L1 in LAYER_REGISTRY)
    check("L8_in_registry", LayerId.L8 in LAYER_REGISTRY)
    check("L10_in_registry", LayerId.L10 in LAYER_REGISTRY)
    check("L9_in_registry", LayerId.L9 in LAYER_REGISTRY)
    for lid, spec in LAYER_REGISTRY.items():
        print(f"  {lid.value}: {spec.name} v{spec.version}")
except Exception as e:
    check("registry_imports", False, str(e))

# ====================================================================
# 2. L1 IMPORT CHAIN (corrections + validator)
# ====================================================================
print("\n=== 2. L1 IMPORT CHAIN ===")
try:
    from services.agribrain.layer1_fusion.corrections import correction_engine
    check("corrections_import", True)
except Exception as e:
    check("corrections_import", False, str(e))

try:
    from services.agribrain.layer1_fusion.validation.validator import TrustSystem
    check("validator_import", True)
except Exception as e:
    check("validator_import", False, str(e))

try:
    from services.agribrain.layer1_fusion.runner import run_layer1_fusion
    check("l1_runner_import", True)
except Exception as e:
    check("l1_runner_import", False, str(e))

# ====================================================================
# 3. L9 RUNNER IMPORT
# ====================================================================
print("\n=== 3. L9 RUNNER IMPORT ===")
try:
    from services.agribrain.layer9_interface.runner import run_layer9
    check("l9_runner_import", True)
except Exception as e:
    check("l9_runner_import", False, str(e))

# ====================================================================
# 4. L10 RUNTIME OUTPUT CONTRACT
# ====================================================================
print("\n=== 4. L10 RUNTIME OUTPUT ===")
from services.agribrain.layer10_sire.schema import Layer10Input, GroundingClass
from services.agribrain.layer10_sire.runner import run_layer10_sire
from services.agribrain.layer1_fusion.schema import FieldTensor, FieldTensorChannels
from services.agribrain.layer1_fusion.raster_backend import GridSpec
from services.agribrain.layer2_veg_int.schema import (
    VegIntOutput, ModeledCurveOutput, CurveQuality, PhenologyOutput, SpatialMetrics,
)

H, W = 8, 8
T, C = 3, 5
data_4d = [[[[0.0]*C for _ in range(W)] for _ in range(H)] for _ in range(T)]
for t in range(T):
    for r in range(H):
        for c in range(W):
            dist = ((r-3.5)**2 + (c-3.5)**2)**0.5 / 5.0
            data_4d[t][r][c] = [max(0.1, 0.8 - dist*0.4 + random.uniform(-0.05, 0.05)),
                                0.05, -12.0, -18.0, 3.0]

ft = FieldTensor(
    plot_id='E2E_SMOKE', run_id='L1-e2e',
    grid_spec=GridSpec(crs='EPSG:4326', transform=(0,0,0,0,0,0),
                     width=8, height=8, bounds=(0,0,1,1), resolution=10.0),
    time_index=['2025-06-28','2025-06-29','2025-06-30'],
    channels=[FieldTensorChannels.NDVI, FieldTensorChannels.NDVI_UNC,
              FieldTensorChannels.VV, FieldTensorChannels.VH,
              FieldTensorChannels.PRECIPITATION],
    data=data_4d,
    zones={'zone_a': {'mask': [[r < 4 for c in range(8)] for r in range(8)], 'area_pct': 50, 'label': 'N'}},
    daily_state={'ndvi': [0.6]*30},
    provenance_log=[{'day': '2025-06-30', 'sources': {'s2': 0.5, 'weather': 0.3, 'soil': 0.2}}],
)
vi = VegIntOutput(
    run_id='L2-e2e', layer1_run_id='L1-e2e',
    curve=ModeledCurveOutput(ndvi_fit=[0.5]*30, ndvi_fit_d1=[0.01]*30,
                            quality=CurveQuality(rmse=0.02, outlier_frac=0.01, obs_coverage=0.85),
                            ndvi_fit_unc=[0.05]*30),
    phenology=PhenologyOutput(stage_by_day=['VEGETATIVE']*30, key_dates={}),
    anomalies=[], stability=SpatialMetrics(mean_spatial_var=0.12, std_spatial_var=0.05,
                                          stability_class='HETEROGENEOUS', confidence=0.8),
    zone_metrics={'zone_a': {'stability_score': 0.9}},
)

inp = Layer10Input(
    field_tensor=ft, veg_int=vi,
    decision=SimpleNamespace(run_id_l3='L3-e2e', diagnoses=[
        SimpleNamespace(problem_id='WATER_STRESS', probability=0.7, severity=0.6,
                       confidence=0.8, affected_area_pct=40.0, hotspot_zone_ids=['zone_a'], drivers_used=[])
    ], recommendations=[], execution_plan=SimpleNamespace(tasks=[]),
    quality_metrics=SimpleNamespace(degradation_mode=SimpleNamespace(value='NORMAL'), decision_reliability=0.85)),
    nutrients=SimpleNamespace(nutrient_states={'N': SimpleNamespace(probability_deficient=0.6, confidence=0.7, severity='MODERATE')},
                             run_meta=SimpleNamespace(run_id='L4-e2e'), zone_metrics={}),
    bio=SimpleNamespace(threat_states={'FUNGAL': SimpleNamespace(probability=0.3, spread_pattern=SimpleNamespace(value='PATCHY'))},
                       weather_pressure=SimpleNamespace(composite_score=0.4), run_meta=SimpleNamespace(run_id='L5-e2e')),
    planning=SimpleNamespace(options=[SimpleNamespace(suitability_percentage=75.0, crop='wheat',
        yield_dist=SimpleNamespace(p10=6.0, p50=8.5, p90=10.2), econ=SimpleNamespace(profit_p50=1500.0))],
        run_meta={'run_id': 'L7-e2e'}),
    plot_id='E2E_SMOKE', grid_height=8, grid_width=8, resolution_m=5.0,
)

out = run_layer10_sire(inp)

# --- Quicklooks ---
check("quicklooks_non_empty", len(out.quicklooks) > 0, f"got {len(out.quicklooks)}")
check("quicklooks_have_pixels",
      all("pixels" in ql for ql in out.quicklooks.values()),
      "some quicklooks missing pixels")
print(f"  Quicklooks: {len(out.quicklooks)} surfaces")

# --- Raster pack ---
check("raster_pack_non_empty", len(out.raster_pack) > 0, f"got {len(out.raster_pack)}")
check("raster_matches_surfaces", len(out.raster_pack) == len(out.surface_pack),
      f"{len(out.raster_pack)} vs {len(out.surface_pack)} surfaces")
print(f"  Raster entries: {len(out.raster_pack)}")

# --- Vector pack ---
check("vector_pack_non_empty", len(out.vector_pack) > 0, f"got {len(out.vector_pack)}")
print(f"  Vector features: {len(out.vector_pack)}")

# --- Tile manifest ---
check("tile_manifest_non_empty", len(out.tile_manifest) > 0, f"empty dict")
check("tile_manifest_run_id", out.tile_manifest.get("run_id") == out.run_id)
check("tile_manifest_layers", len(out.tile_manifest.get("available_layers", [])) > 0)
print(f"  Tile layers: {len(out.tile_manifest.get('available_layers', []))}")

# ====================================================================
# 5. GROUNDING CLASS METADATA
# ====================================================================
print("\n=== 5. GROUNDING CLASS ===")
valid_gc = {g.value for g in GroundingClass}
for s in out.surface_pack:
    check(f"gc_{s.semantic_type.value}_exists", s.grounding_class is not None,
          "grounding_class is None")
    if s.grounding_class:
        check(f"gc_{s.semantic_type.value}_valid", s.grounding_class in valid_gc,
              f"invalid: {s.grounding_class}")

# Count by class
by_class = {}
for s in out.surface_pack:
    by_class[s.grounding_class] = by_class.get(s.grounding_class, 0) + 1
for gc, count in sorted(by_class.items()):
    print(f"  {gc}: {count}")

# grounding_summary in provenance must match actual counts
gs = out.provenance.get("grounding_summary", {})
check("provenance_has_grounding_summary", bool(gs), "missing grounding_summary")
for gc_val, expected in by_class.items():
    actual = gs.get(gc_val, -1)
    check(f"gs_match_{gc_val}", actual == expected,
          f"provenance says {actual}, actual {expected}")
print(f"  Provenance grounding_summary matches: TRUE")

# ====================================================================
# 6. PIPELINE VERSION
# ====================================================================
print("\n=== 6. PIPELINE VERSION ===")
check("pipeline_v10.5", out.provenance.get("pipeline") == "SIRE_v10.5",
      f"got {out.provenance.get('pipeline')}")

# ====================================================================
# SUMMARY
# ====================================================================
print(f"\n{'='*60}")
print(f"END-TO-END SMOKE: {ok} passed, {fail} failed")
if fail == 0:
    print("ALL END-TO-END CHECKS PASSED")
else:
    print(f"FAILURES: {fail}")
    exit(1)
