import sys
from pathlib import Path

# Add project root to sys.path
sys.path.insert(0, str(Path(__file__).resolve().parent.parent.parent.parent))

from services.agribrain.layer10_sire.schema import SurfaceArtifact, SurfaceType, ZoneType
from services.agribrain.layer10_sire.zones.extractor import extract_zones

def test_backend_states():
    # Helper to run extractor
    def run_extract(values_grid):
        surface = SurfaceArtifact(
            surface_id="test",
            semantic_type=SurfaceType.NDVI_DEVIATION,
            grid_ref="10x10",
            values=values_grid,
            units="idx",
            native_resolution_m=10.0,
            render_range=(0,1),
            palette_id="viridis",
            source_layers=["L1"]
        )
        _, final_state = extract_zones([surface], 10, 10, None)
        return final_state.get("NDVI_DEVIATION")

    # 1. all-null surface -> no_data
    null_grid = [[None]*10 for _ in range(10)]
    assert run_extract(null_grid) == "no_data", f"Failed no_data. Got {run_extract(null_grid)}"

    # 2. uniform bad surface -> field_wide (threshold -0.05 approx for NDVI_DEVIATION adaptive if std is small?)
    # Since NDVI_DEVIATION is adaptive: max(-1.2*std, -0.08). 
    # If all values are exactly -0.1, std is 0. threshold = max(0, -0.08) = -0.08. 
    # All values < -0.08 -> field_wide!
    bad_grid = [[-0.1]*10 for _ in range(10)]
    assert run_extract(bad_grid) == "field_wide", f"Failed field_wide. Got {run_extract(bad_grid)}"
    
    # 3. localized cluster -> localized
    loc_grid = [[0.0]*10 for _ in range(10)]
    loc_grid[4][4] = -0.2
    loc_grid[4][5] = -0.2
    loc_grid[5][4] = -0.2
    loc_grid[5][5] = -0.2
    # std is > 0. threshold is roughly -0.08 or so. The 4 cells < threshold.
    assert run_extract(loc_grid) == "localized", f"Failed localized. Got {run_extract(loc_grid)}"

    # 4. low valid fraction -> low_confidence or none/no_data depending on valid cells
    # If there are only 3 valid cells out of 100, and they are all bad. The min zone size is 4.
    # Wait, if fraction of valid cells < 0.05, maybe it fails earlier?
    # If there's 1 valid cell, components won't form because min zone size is 4. 
    # But wait, 99 None, 1 valid (-0.2). valid_cells = 1. total_cells_above = 0.
    # fraction_above = 0. state = "none". 
    # Let's do a uniform good field -> "none".
    good_grid = [[0.1]*10 for _ in range(10)]
    assert run_extract(good_grid) == "none", f"Failed none. Got {run_extract(good_grid)}"
    
    print("ALL TESTS PASSED")

if __name__ == "__main__":
    test_backend_states()
