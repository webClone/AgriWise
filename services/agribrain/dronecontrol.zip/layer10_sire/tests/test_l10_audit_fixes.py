"""Verify all audit fixes are correctly wired."""
import random; random.seed(42)
from types import SimpleNamespace
from services.agribrain.layer10_sire.schema import Layer10Input, GroundingClass
from services.agribrain.layer10_sire.runner import run_layer10_sire
from services.agribrain.layer1_fusion.schema import FieldTensor, FieldTensorChannels
from services.agribrain.layer1_fusion.raster_backend import GridSpec
from services.agribrain.layer2_veg_int.schema import (
    VegIntOutput, ModeledCurveOutput, CurveQuality, PhenologyOutput, SpatialMetrics,
)

H, W = 8, 8
T, C = 3, 5
data_4d = [[[[0.0]*C for _ in range(W)] for _ in range(H)] for _ in range(T)]
for t in range(T):
    for r in range(H):
        for c in range(W):
            dist = ((r-3.5)**2 + (c-3.5)**2)**0.5 / 5.0
            ndvi = max(0.1, 0.8 - dist * 0.4 + random.uniform(-0.05, 0.05))
            data_4d[t][r][c] = [ndvi, 0.05, -12.0, -18.0, 3.0]

ft = FieldTensor(
    plot_id='AUDIT_FIX', run_id='L1-audit',
    grid_spec=GridSpec(crs='EPSG:4326', transform=(0,0,0,0,0,0),
                     width=8, height=8, bounds=(0,0,1,1), resolution=10.0),
    time_index=['2025-06-28','2025-06-29','2025-06-30'],
    channels=[FieldTensorChannels.NDVI, FieldTensorChannels.NDVI_UNC,
              FieldTensorChannels.VV, FieldTensorChannels.VH,
              FieldTensorChannels.PRECIPITATION],
    data=data_4d,
    zones={'zone_a': {'mask': [[r < 4 for c in range(8)] for r in range(8)], 'area_pct': 50, 'label': 'N'}},
    daily_state={'ndvi': [0.6]*30},
    provenance_log=[{'day': '2025-06-30', 'sources': {'s2': 0.5, 'weather': 0.3, 'soil': 0.2}}],
)
vi = VegIntOutput(
    run_id='L2-audit', layer1_run_id='L1-audit',
    curve=ModeledCurveOutput(ndvi_fit=[0.5]*30, ndvi_fit_d1=[0.01]*30,
                            quality=CurveQuality(rmse=0.02, outlier_frac=0.01, obs_coverage=0.85),
                            ndvi_fit_unc=[0.05]*30),
    phenology=PhenologyOutput(stage_by_day=['VEGETATIVE']*30, key_dates={}),
    anomalies=[], stability=SpatialMetrics(mean_spatial_var=0.12, std_spatial_var=0.05,
                                          stability_class='HETEROGENEOUS', confidence=0.8),
    zone_metrics={'zone_a': {'stability_score': 0.9}},
)

inp = Layer10Input(
    field_tensor=ft, veg_int=vi,
    decision=SimpleNamespace(run_id_l3='L3-audit', diagnoses=[
        SimpleNamespace(problem_id='WATER_STRESS', probability=0.7, severity=0.6,
                       confidence=0.8, affected_area_pct=40.0, hotspot_zone_ids=['zone_a'], drivers_used=[])
    ], recommendations=[], execution_plan=SimpleNamespace(tasks=[]),
    quality_metrics=SimpleNamespace(degradation_mode=SimpleNamespace(value='NORMAL'), decision_reliability=0.85)),
    nutrients=SimpleNamespace(nutrient_states={'N': SimpleNamespace(probability_deficient=0.6, confidence=0.7, severity='MODERATE')},
                             run_meta=SimpleNamespace(run_id='L4-audit'), zone_metrics={}),
    bio=SimpleNamespace(threat_states={'FUNGAL': SimpleNamespace(probability=0.3, spread_pattern=SimpleNamespace(value='PATCHY'))},
                       weather_pressure=SimpleNamespace(composite_score=0.4), run_meta=SimpleNamespace(run_id='L5-audit')),
    planning=SimpleNamespace(options=[SimpleNamespace(suitability_percentage=75.0, crop='wheat',
        yield_dist=SimpleNamespace(p10=6.0, p50=8.5, p90=10.2), econ=SimpleNamespace(profit_p50=1500.0))],
        run_meta={'run_id': 'L7-audit'}),
    plot_id='AUDIT', grid_height=8, grid_width=8, resolution_m=5.0,
)

out = run_layer10_sire(inp)
ok = 0; fail = 0

def check(name, cond, detail=""):
    global ok, fail
    if cond: ok += 1
    else: fail += 1; print(f"  FAIL: {name}: {detail}")

# 1. Grounding class tags
print("=== GROUNDING CLASS TAGS ===")
for s in out.surface_pack:
    gc = s.grounding_class
    check(f"grounding_{s.semantic_type.value}", gc is not None, "grounding_class is None")
    if gc:
        check(f"grounding_valid_{s.semantic_type.value}",
              gc in [g.value for g in GroundingClass],
              f"invalid: {gc}")

# Count by class
by_class = {}
for s in out.surface_pack:
    by_class[s.grounding_class] = by_class.get(s.grounding_class, 0) + 1
for gc, count in sorted(by_class.items()):
    print(f"  {gc}: {count} surfaces")

# Provenance must contain grounding_summary
check("provenance_grounding", "grounding_summary" in out.provenance, "no grounding_summary")
print(f"  Provenance grounding_summary: {out.provenance.get('grounding_summary', {})}")

# 2. Export packs
print("\n=== EXPORT PACKS ===")
check("raster_pack_exists", len(out.raster_pack) > 0, f"empty, got {len(out.raster_pack)}")
check("raster_pack_count", len(out.raster_pack) == len(out.surface_pack),
      f"{len(out.raster_pack)} vs {len(out.surface_pack)}")
check("vector_pack_exists", len(out.vector_pack) > 0, f"empty")
check("tile_manifest_exists", len(out.tile_manifest) > 0, f"empty")
check("tile_run_id", out.tile_manifest.get("run_id") == out.run_id)
print(f"  Raster entries: {len(out.raster_pack)}")
print(f"  Vector features: {len(out.vector_pack)}")
print(f"  Tile manifest layers: {len(out.tile_manifest.get('available_layers', []))}")

# 3. Quicklooks
print("\n=== QUICKLOOKS ===")
check("quicklooks_exist", len(out.quicklooks) > 0)
print(f"  Quicklook keys: {list(out.quicklooks.keys())[:6]}...")
for k, ql in list(out.quicklooks.items())[:2]:
    check(f"ql_{k}_has_pixels", "pixels" in ql)
    check(f"ql_{k}_has_size", "width" in ql and "height" in ql)

# 4. Pipeline version
print("\n=== PIPELINE VERSION ===")
check("pipeline_v5", out.provenance.get("pipeline") == "SIRE_v10.5")

# 5. Registry import
print("\n=== REGISTRY IMPORT ===")
from services.agribrain.orchestrator_v2.registry import LAYER_REGISTRY, LayerId
check("registry_count", len(LAYER_REGISTRY) == 10, f"got {len(LAYER_REGISTRY)}")
check("L10_in_registry", LayerId.L10 in LAYER_REGISTRY)
check("L9_in_registry", LayerId.L9 in LAYER_REGISTRY)
check("L8_in_registry", LayerId.L8 in LAYER_REGISTRY)

# Summary
print(f"\n{'='*50}")
print(f"AUDIT FIX VERIFICATION: {ok} passed, {fail} failed")
if fail == 0:
    print("ALL AUDIT FIXES VERIFIED")
else:
    exit(1)
