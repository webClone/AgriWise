"""
Layer 10 SIRE — Hardened Contract + Regression Test Suite
==========================================================

Tests:
  1. Contract tests          - Schema invariants
  2. Grid alignment tests    - All surfaces match grid
  3. Detail conservation     - No all-None surfaces
  4. Zone topology           - Non-overlapping within family
  5. Histogram consistency   - Bin counts sum to valid pixels
  6. Deterministic ID        - Same input → same run_id
  7. Degradation modes       - Missing inputs → correct mode
  8. Product export          - Raster/vector/tile export
  9. Imagery engine          - Style packs + enhancement
  10. Structure detection    - Row/crown/canopy detection
"""
import random
random.seed(42)
from types import SimpleNamespace

from services.agribrain.layer10_sire.schema import (
    Layer10Input, SurfaceType, ZoneFamily, SIREDegradation,
)
from services.agribrain.layer10_sire.runner import run_layer10_sire
from services.agribrain.layer10_sire.products.export import (
    export_raster_pack, export_vector_pack, export_tile_manifest, export_full_product,
)
from services.agribrain.layer10_sire.imagery.style_packs import list_style_packs, get_style_pack, StylePackId
from services.agribrain.layer10_sire.imagery.enhancement import enhance_surface
from services.agribrain.layer10_sire.imagery.quicklooks import generate_quicklook
from services.agribrain.layer10_sire.histograms.delta_hist import compute_delta_histograms
from services.agribrain.layer1_fusion.schema import FieldTensor, FieldTensorChannels
from services.agribrain.layer1_fusion.raster_backend import GridSpec
from services.agribrain.layer2_veg_int.schema import (
    VegIntOutput, ModeledCurveOutput, CurveQuality, PhenologyOutput, SpatialMetrics,
)

passed = 0
failed = 0


def check(name, condition, detail=""):
    global passed, failed
    if condition:
        passed += 1
    else:
        failed += 1
        print(f"  FAIL: {name} — {detail}")


def build_full_input():
    """Build a comprehensive Layer10Input."""
    T, H, W, C = 3, 8, 8, 5
    data_4d = [[[[0.0]*C for _ in range(W)] for _ in range(H)] for _ in range(T)]
    for t in range(T):
        for r in range(H):
            for c in range(W):
                dist = ((r-3.5)**2 + (c-3.5)**2)**0.5 / 5.0
                ndvi = max(0.1, 0.8 - dist * 0.4 + random.uniform(-0.05, 0.05))
                data_4d[t][r][c] = [ndvi, 0.05, -12.0, -18.0, 3.0]

    ft = FieldTensor(
        plot_id='GOLDEN_TEST', run_id='L1-golden',
        grid_spec=GridSpec(crs='EPSG:4326', transform=(0,0,0,0,0,0),
                         width=8, height=8, bounds=(0,0,1,1), resolution=10.0),
        time_index=['2025-06-28','2025-06-29','2025-06-30'],
        channels=[FieldTensorChannels.NDVI, FieldTensorChannels.NDVI_UNC,
                  FieldTensorChannels.VV, FieldTensorChannels.VH,
                  FieldTensorChannels.PRECIPITATION],
        data=data_4d,
        zones={
            'zone_a': {'mask': [[r < 4 for c in range(8)] for r in range(8)],
                       'area_pct': 50, 'label': 'North'},
            'zone_b': {'mask': [[r >= 4 for c in range(8)] for r in range(8)],
                       'area_pct': 50, 'label': 'South'},
        },
        daily_state={'ndvi': [0.6]*30, 'precipitation': [5.0]*20 + [0.0]*10},
        provenance_log=[{'day': '2025-06-30', 'sources': {'s2': 0.5, 's1': 0.2, 'weather': 0.2, 'soil': 0.1}}],
    )

    vi = VegIntOutput(
        run_id='L2-golden', layer1_run_id='L1-golden',
        curve=ModeledCurveOutput(ndvi_fit=[0.5]*30, ndvi_fit_d1=[0.01]*30,
                                quality=CurveQuality(rmse=0.02, outlier_frac=0.01, obs_coverage=0.85),
                                ndvi_fit_unc=[0.05]*30),
        phenology=PhenologyOutput(stage_by_day=['VEGETATIVE']*30, key_dates={}),
        anomalies=[],
        stability=SpatialMetrics(mean_spatial_var=0.12, std_spatial_var=0.05,
                                stability_class='HETEROGENEOUS', confidence=0.8),
        zone_metrics={'zone_a': {'stability_score': 0.9}, 'zone_b': {'stability_score': 0.3}},
    )

    l3 = SimpleNamespace(
        run_id_l3='L3-golden',
        diagnoses=[SimpleNamespace(
            problem_id='WATER_STRESS', probability=0.7, severity=0.6, confidence=0.8,
            affected_area_pct=40.0, hotspot_zone_ids=['zone_b'], drivers_used=[],
        )],
        recommendations=[], execution_plan=SimpleNamespace(tasks=[]),
        quality_metrics=SimpleNamespace(degradation_mode=SimpleNamespace(value='NORMAL'), decision_reliability=0.85),
    )
    l4 = SimpleNamespace(
        nutrient_states={'N': SimpleNamespace(probability_deficient=0.6, confidence=0.7, severity='MODERATE')},
        run_meta=SimpleNamespace(run_id='L4-golden'), zone_metrics={},
    )
    l5 = SimpleNamespace(
        threat_states={'FUNGAL': SimpleNamespace(probability=0.3, spread_pattern=SimpleNamespace(value='PATCHY'))},
        weather_pressure=SimpleNamespace(composite_score=0.4),
        run_meta=SimpleNamespace(run_id='L5-golden'),
    )
    l7 = SimpleNamespace(
        options=[SimpleNamespace(
            suitability_percentage=75.0, crop='wheat',
            yield_dist=SimpleNamespace(p10=6.0, p50=8.5, p90=10.2),
            econ=SimpleNamespace(profit_p50=1500.0),
        )],
        run_meta={'run_id': 'L7-golden'},
    )
    l8 = SimpleNamespace(
        actions=[SimpleNamespace(
            action_type=SimpleNamespace(value='IRRIGATE'), action_id='A1',
            priority_score=0.8, is_allowed=True, zone_targets=['zone_b'],
            confidence=SimpleNamespace(value='HIGH'),
        )],
        zone_plan=[], run_id='L8-golden', outcome_forecast=None, quality=None,
    )

    return Layer10Input(
        field_tensor=ft, veg_int=vi,
        decision=l3, nutrients=l4, bio=l5, planning=l7, prescriptive=l8,
        plot_id='GOLDEN_TEST', grid_height=8, grid_width=8, resolution_m=5.0,
    )


print("LAYER 10 HARDENED TESTS")
print("=" * 50)

inp = build_full_input()
out = run_layer10_sire(inp)
H, W = 8, 8

# --- 1. Contract Tests ---
print("\n1. Contract Tests")
check("run_id exists", len(out.run_id) > 0)
check("run_id prefix", out.run_id.startswith("L10-"))
check("timestamp exists", len(out.timestamp) > 0)
check("surfaces non-empty", len(out.surface_pack) >= 10, f"got {len(out.surface_pack)}")
check("zones non-empty", len(out.zone_pack) >= 1)
check("histograms non-empty", len(out.histogram_bundle.field_histograms) >= 1)
check("manifest modes non-empty", len(out.render_manifest.available_modes) >= 1)

# --- 2. Grid Alignment ---
print("\n2. Grid Alignment Tests")
for s in out.surface_pack:
    check(f"grid_rows_{s.semantic_type.value}", len(s.values) == H,
          f"expected {H} rows, got {len(s.values)}")
    for ri, row in enumerate(s.values):
        if len(row) != W:
            check(f"grid_cols_{s.semantic_type.value}_r{ri}", False,
                  f"expected {W} cols, got {len(row)}")
            break
    else:
        check(f"grid_cols_{s.semantic_type.value}", True)
check("quality grid_ok", out.quality_report.grid_alignment_ok)

# --- 3. Detail Conservation ---
print("\n3. Detail Conservation Tests")
for s in out.surface_pack:
    has_val = any(s.values[r][c] is not None for r in range(H) for c in range(W))
    check(f"detail_{s.semantic_type.value}", has_val, "all None values")
check("quality detail_ok", out.quality_report.detail_conservation_ok)

# --- 4. Zone Topology ---
print("\n4. Zone Topology Tests")
families = {}
for z in out.zone_pack:
    fam = z.zone_family.value
    families.setdefault(fam, []).append(z)

for fam, zones in families.items():
    # Non-overlapping within family
    all_cells = []
    for z in zones:
        all_cells.extend(z.cell_indices)
    unique = set(all_cells)
    check(f"non_overlap_{fam}", len(unique) == len(all_cells),
          f"{len(all_cells) - len(unique)} overlapping cells")

for z in out.zone_pack:
    check(f"zone_cells_{z.zone_id}", len(z.cell_indices) > 0, "empty zone")
    check(f"zone_confidence_{z.zone_id}", 0.0 <= z.confidence <= 1.0,
          f"confidence={z.confidence}")
    check(f"zone_severity_{z.zone_id}", 0.0 <= z.severity <= 1.0,
          f"severity={z.severity}")

# --- 5. Histogram Consistency ---
print("\n5. Histogram Consistency Tests")
for h in out.histogram_bundle.field_histograms:
    total = sum(h.bin_counts)
    check(f"hist_sum_{h.surface_type.value}", total == h.valid_pixels,
          f"sum={total} vs valid={h.valid_pixels}")
    check(f"hist_valid_{h.surface_type.value}", h.valid_pixels > 0, "no valid pixels")

# --- 6. Deterministic ID ---
print("\n6. Deterministic Tests")
random.seed(42)
inp2 = build_full_input()
out2 = run_layer10_sire(inp2)
check("deterministic_id", out.run_id == out2.run_id,
      f"{out.run_id} vs {out2.run_id}")

# --- 7. Degradation Modes ---
print("\n7. Degradation Mode Tests")
check("normal_mode", out.quality_report.degradation_mode == SIREDegradation.NORMAL)

# Test L1-only mode
minimal = Layer10Input(
    field_tensor=inp.field_tensor, veg_int=inp.veg_int,
    plot_id='MINIMAL', grid_height=8, grid_width=8, resolution_m=10.0,
)
out_min = run_layer10_sire(minimal)
check("l1_only_mode", out_min.quality_report.degradation_mode == SIREDegradation.L1_ONLY)
check("l1_only_surfaces", len(out_min.surface_pack) >= 4, f"got {len(out_min.surface_pack)}")

# --- 8. Product Export ---
print("\n8. Product Export Tests")
rasters = export_raster_pack(out)
check("raster_count", len(rasters) == len(out.surface_pack))
check("raster_stats", all(r.stats.get("valid_pixels", 0) > 0 for r in rasters))

vectors = export_vector_pack(out)
check("vector_zones", any(v.family == "AGRONOMIC" for v in vectors))

tile = export_tile_manifest(out, H, W, inp.resolution_m)
check("tile_run_id", tile.run_id == out.run_id)
check("tile_layers", len(tile.available_layers) >= 10)

full = export_full_product(out, H, W, inp.resolution_m)
check("full_product_keys", "raster_pack" in full and "vector_pack" in full and "tile_manifest" in full)

# --- 9. Imagery Engine ---
print("\n9. Imagery Engine Tests")
packs = list_style_packs()
check("style_packs_count", len(packs) == 6)

for sid in StylePackId:
    sp = get_style_pack(sid)
    check(f"style_{sid.value}", sp is not None)

ndvi_surface = next(s for s in out.surface_pack if s.semantic_type == SurfaceType.NDVI_CLEAN)
enhanced = enhance_surface(ndvi_surface, H, W, contrast=1.5, clahe_clip=2.0)
check("enhancement_shape", len(enhanced) == H and len(enhanced[0]) == W)
check("enhancement_range", all(0.0 <= enhanced[r][c] <= 1.0 for r in range(H) for c in range(W)))

ql = generate_quicklook(ndvi_surface, H, W, target_size=4)
check("quicklook_size", ql["width"] <= 4 and ql["height"] <= 4)

# --- 10. Value Range Checks ---
print("\n10. Value Range Checks")
for s in out.surface_pack:
    lo, hi = s.render_range
    vals = [s.values[r][c] for r in range(H) for c in range(W) if s.values[r][c] is not None]
    if vals:
        mn, mx = min(vals), max(vals)
        in_range = mn >= lo - 0.01 and mx <= hi + abs(hi) * 0.5 + 10.0  # Generous tolerance
        check(f"range_{s.semantic_type.value}", in_range,
              f"[{mn:.3f},{mx:.3f}] vs render[{lo},{hi}]")

# --- Summary ---
print("\n" + "=" * 50)
print(f"LAYER 10 HARDENED: {passed} passed, {failed} failed")
if failed == 0:
    print("ALL LAYER 10 HARDENED TESTS PASSED")
else:
    print(f"FAILURES: {failed}")
    exit(1)
