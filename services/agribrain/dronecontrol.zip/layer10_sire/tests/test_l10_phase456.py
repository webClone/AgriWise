"""Phase 4-6 unit tests"""

# Imports
from services.agribrain.layer10_sire.imagery.style_packs import list_style_packs, get_style_pack, StylePackId
from services.agribrain.layer10_sire.imagery.enhancement import enhance_surface
from services.agribrain.layer10_sire.imagery.quicklooks import generate_quicklook
from services.agribrain.layer10_sire.histograms.delta_hist import compute_delta_histograms
from services.agribrain.layer10_sire.histograms.uncertainty_hist import compute_uncertainty_histograms
from services.agribrain.layer10_sire.histograms.compare import compare_zones, compare_surfaces
from services.agribrain.layer10_sire.structure.row_detection import detect_rows
from services.agribrain.layer10_sire.structure.crown_detection import detect_crowns
from services.agribrain.layer10_sire.structure.stand_density import compute_stand_density
from services.agribrain.layer10_sire.structure.microdetail_fusion import (
    redistribute_to_objects, verify_conservation,
)
from services.agribrain.layer10_sire.schema import (
    SurfaceArtifact, SurfaceType, PaletteId, ZoneArtifact, ZoneFamily, ZoneType,
)

print("All Phase 4-6 modules import OK")

# Style packs
packs = list_style_packs()
assert len(packs) == 6, f"Expected 6 style packs, got {len(packs)}"
print(f"Style packs: {len(packs)}")
for p in packs:
    print(f"  {p['id']}: {p['name']}")

sp = get_style_pack(StylePackId.AGRO_POP)
assert sp.contrast == 1.3
assert sp.saturation == 1.5
assert sp.clahe_clip == 2.0
print(f"AGRO_POP: contrast={sp.contrast} sat={sp.saturation} clahe={sp.clahe_clip}")

# Enhancement pipeline
test_surface = SurfaceArtifact(
    surface_id="TEST", semantic_type=SurfaceType.NDVI_CLEAN,
    grid_ref="4x4",
    values=[[0.2, 0.4, 0.6, 0.8],
            [0.3, 0.5, 0.7, 0.9],
            [0.1, 0.3, 0.5, 0.7],
            [0.4, 0.6, 0.8, 1.0]],
    units="index", native_resolution_m=10.0,
    render_range=(0.0, 1.0), palette_id=PaletteId.VIGOR_GREEN,
    source_layers=["L1"],
)
enhanced = enhance_surface(test_surface, 4, 4, contrast=1.5, clahe_clip=2.0)
assert len(enhanced) == 4 and len(enhanced[0]) == 4
print(f"Enhancement: {enhanced[0][0]:.3f}...{enhanced[3][3]:.3f}")

# Quicklook
ql = generate_quicklook(test_surface, 4, 4, target_size=4)
assert ql["width"] == 4 and ql["height"] == 4
assert "r" in ql["pixels"][0][0]
print(f"Quicklook: {ql['width']}x{ql['height']}")

# Delta histogram
prev = [[0.3, 0.4, 0.5, 0.6], [0.3, 0.4, 0.5, 0.6],
        [0.2, 0.3, 0.4, 0.5], [0.3, 0.5, 0.7, 0.9]]
curr = test_surface.values
dh = compute_delta_histograms(curr, prev, 4, 4, "NDVI_CLEAN")
assert dh["stats"]["n_pixels"] == 16
print(f"Delta histogram: mean={dh['stats']['mean']:.4f} positive={dh['stats']['positive_pct']}%")

# Compare zones
zone_a = ZoneArtifact(
    zone_id="ZA", zone_type=ZoneType.WATER_STRESS, zone_family=ZoneFamily.AGRONOMIC,
    bbox=(0, 0, 1, 1),
    cell_indices=[(0, 0), (0, 1), (1, 0), (1, 1)],
    area_m2=400.0, area_pct=0.25,
    severity=0.5, confidence=0.8, top_drivers=["NDVI", "RAIN"],
)
zone_b = ZoneArtifact(
    zone_id="ZB", zone_type=ZoneType.LOW_VIGOR, zone_family=ZoneFamily.AGRONOMIC,
    bbox=(2, 2, 3, 3),
    cell_indices=[(2, 2), (2, 3), (3, 2), (3, 3)],
    area_m2=400.0, area_pct=0.25,
    severity=0.3, confidence=0.7, top_drivers=["NDVI"],
)
cmp = compare_zones(test_surface, zone_a, zone_b, bins=5)
print(f"Zone compare: mean_diff={cmp['comparison']['mean_difference']:.4f} "
      f"effect={cmp['comparison']['effect_size']:.3f} "
      f"overlap={cmp['comparison']['overlap_pct']:.1f}%")

# Conservation verification
assert verify_conservation(test_surface, [zone_a, zone_b], 4, 4, tolerance=0.5)
print("Detail conservation: VERIFIED")

print("\nPhase 4-6 ALL VERIFIED")
