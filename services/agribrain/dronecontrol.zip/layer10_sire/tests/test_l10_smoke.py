"""
Layer 10 SIRE — Comprehensive Smoke Test
"""
import time
import random
random.seed(42)

from types import SimpleNamespace
from services.agribrain.layer10_sire.schema import Layer10Input
from services.agribrain.layer10_sire.runner import run_layer10_sire
from services.agribrain.layer10_sire.adapters.l1_adapter import adapt_l1
from services.agribrain.layer1_fusion.schema import FieldTensor, FieldTensorChannels
from services.agribrain.layer1_fusion.raster_backend import GridSpec
from services.agribrain.layer2_veg_int.schema import (
    VegIntOutput, ModeledCurveOutput, CurveQuality, PhenologyOutput, SpatialMetrics
)


def test_l1_adapter():
    """Test L1 adapter alone."""
    ft = FieldTensor(
        plot_id='T', run_id='L1-test',
        grid_spec=GridSpec(crs='EPSG:4326', transform=(0,0,0,0,0,0),
                         width=8, height=8, bounds=(0,0,1,1), resolution=10.0),
        time_index=['2025-06-30'],
        channels=[FieldTensorChannels.NDVI, FieldTensorChannels.NDVI_UNC],
        data=[[[[0.6, 0.05] for _ in range(8)] for _ in range(8)]],
        zones={
            'zone_a': {
                'mask': [[r < 4 for c in range(8)] for r in range(8)],
                'area_pct': 50, 'label': 'N'
            },
        },
        daily_state={'ndvi': [0.6]*5},
        provenance_log=[{'sources': {'s2': 0.5, 'weather': 0.5}}],
    )

    t0 = time.time()
    result = adapt_l1(ft, 8, 8)
    elapsed = time.time() - t0
    print(f"L1 adapter: {elapsed:.3f}s")
    print(f"  Rasters: {list(result.raster_maps.keys())}")
    print(f"  Zones: {list(result.zone_masks.keys())}")
    ndvi_row = result.raster_maps.get('ndvi', [[]])[0][:4]
    print(f"  NDVI row[0][:4]: {ndvi_row}")
    assert len(result.raster_maps) > 0, "No rasters extracted"
    print("  L1 ADAPTER OK")
    return ft


def test_full_pipeline():
    """Full pipeline test with spatial 4D data."""
    # Build 4D tensor with spatial variation
    T, H, W, C = 3, 8, 8, 5
    data_4d = [[[[0.0]*C for _ in range(W)] for _ in range(H)] for _ in range(T)]
    for t in range(T):
        for r in range(H):
            for c in range(W):
                dist = ((r-3.5)**2 + (c-3.5)**2)**0.5 / 5.0
                ndvi = max(0.1, 0.8 - dist * 0.4 + random.uniform(-0.05, 0.05))
                data_4d[t][r][c] = [ndvi, 0.05, -12.0, -18.0, 3.0]

    ft = FieldTensor(
        plot_id='SPATIAL_TEST', run_id='L1-abc123',
        grid_spec=GridSpec(crs='EPSG:4326', transform=(0,0,0,0,0,0),
                         width=8, height=8, bounds=(0,0,1,1), resolution=10.0),
        time_index=['2025-06-28','2025-06-29','2025-06-30'],
        channels=[
            FieldTensorChannels.NDVI, FieldTensorChannels.NDVI_UNC,
            FieldTensorChannels.VV, FieldTensorChannels.VH,
            FieldTensorChannels.PRECIPITATION,
        ],
        data=data_4d,
        zones={
            'zone_a': {
                'mask': [[r < 4 for c in range(8)] for r in range(8)],
                'area_pct': 50, 'label': 'North',
            },
            'zone_b': {
                'mask': [[r >= 4 for c in range(8)] for r in range(8)],
                'area_pct': 50, 'label': 'South',
            },
        },
        daily_state={'ndvi': [0.6]*30, 'precipitation': [5.0]*20 + [0.0]*10},
        provenance_log=[{
            'day': '2025-06-30',
            'sources': {'s2': 0.5, 's1': 0.2, 'weather': 0.2, 'soil': 0.1},
        }],
    )

    vi = VegIntOutput(
        run_id='L2-def456', layer1_run_id='L1-abc123',
        curve=ModeledCurveOutput(
            ndvi_fit=[0.5]*30, ndvi_fit_d1=[0.01]*30,
            quality=CurveQuality(rmse=0.02, outlier_frac=0.01, obs_coverage=0.85),
            ndvi_fit_unc=[0.05]*30,
        ),
        phenology=PhenologyOutput(stage_by_day=['VEGETATIVE']*30, key_dates={}),
        anomalies=[],
        stability=SpatialMetrics(
            mean_spatial_var=0.12, std_spatial_var=0.05,
            stability_class='HETEROGENEOUS', confidence=0.8,
        ),
        zone_metrics={
            'zone_a': {'stability_score': 0.9},
            'zone_b': {'stability_score': 0.3},
        },
    )

    l3 = SimpleNamespace(
        run_id_l3='L3-ghi789',
        diagnoses=[SimpleNamespace(
            problem_id='WATER_STRESS', probability=0.7, severity=0.6,
            confidence=0.8, affected_area_pct=40.0,
            hotspot_zone_ids=['zone_b'], drivers_used=[],
        )],
        recommendations=[],
        execution_plan=SimpleNamespace(tasks=[]),
        quality_metrics=SimpleNamespace(
            degradation_mode=SimpleNamespace(value='NORMAL'),
            decision_reliability=0.85,
        ),
    )

    l4 = SimpleNamespace(
        nutrient_states={
            'N': SimpleNamespace(probability_deficient=0.6, confidence=0.7, severity='MODERATE')
        },
        run_meta=SimpleNamespace(run_id='L4-001'),
        zone_metrics={},
    )

    l5 = SimpleNamespace(
        threat_states={
            'FUNGAL': SimpleNamespace(
                probability=0.3,
                spread_pattern=SimpleNamespace(value='PATCHY'),
            )
        },
        weather_pressure=SimpleNamespace(composite_score=0.4),
        run_meta=SimpleNamespace(run_id='L5-001'),
    )

    l7 = SimpleNamespace(
        options=[SimpleNamespace(
            suitability_percentage=75.0, crop='wheat',
            yield_dist=SimpleNamespace(p10=6.0, p50=8.5, p90=10.2),
            econ=SimpleNamespace(profit_p50=1500.0),
        )],
        run_meta={'run_id': ''},
    )

    l8 = SimpleNamespace(
        actions=[SimpleNamespace(
            action_type=SimpleNamespace(value='IRRIGATE'),
            action_id='A1', priority_score=0.8, is_allowed=True,
            zone_targets=['zone_b'],
            confidence=SimpleNamespace(value='HIGH'),
        )],
        zone_plan=[], run_id='L8-001',
        outcome_forecast=None, quality=None,
    )

    inp = Layer10Input(
        field_tensor=ft, veg_int=vi,
        decision=l3, nutrients=l4, bio=l5,
        planning=l7, prescriptive=l8,
        plot_id='SPATIAL_TEST', grid_height=8, grid_width=8,
        resolution_m=5.0,
    )

    t0 = time.time()
    out = run_layer10_sire(inp)
    elapsed = time.time() - t0
    print(f"\nPipeline: {elapsed:.3f}s")
    print(f"Run: {out.run_id} (deterministic)")
    print(f"Grid: {out.provenance.get('grid')}")
    print(f"Strategy: {out.provenance.get('spatial_strategy')}")
    print(f"Surfaces: {len(out.surface_pack)}")

    spatial_count = 0
    uniform_count = 0
    for s in out.surface_pack:
        vals = []
        for row in s.values:
            for v in row:
                if v is not None:
                    vals.append(v)
        if vals:
            mn, mx = min(vals), max(vals)
            is_uniform = (mx - mn) < 0.001
            tag = "UNIFORM" if is_uniform else "SPATIAL"
            if not is_uniform:
                spatial_count += 1
            else:
                uniform_count += 1
            print(f"  {s.semantic_type.value}: [{mn:.4f},{mx:.4f}] {tag}")

    print(f"\nZones: {len(out.zone_pack)}")
    for z in out.zone_pack:
        print(f"  {z.zone_type.value}: {len(z.cell_indices)} cells, severity={z.severity:.3f}")

    print(f"\nMicro-objects: {len(out.micro_objects)}")
    for o in out.micro_objects:
        print(f"  {o.object_type.value}: {len(o.cell_indices)} cells, score={o.score:.3f}")

    print(f"\nHistograms: {len(out.histogram_bundle.field_histograms)} field, "
          f"{len(out.histogram_bundle.zone_histograms)} zone")
    print(f"Modes enabled: {len([m for m in out.render_manifest.available_modes if m.enabled])}")
    print(f"Warnings: {len(out.quality_report.warnings)}")

    # Deterministic check
    out2 = run_layer10_sire(inp)
    assert out.run_id == out2.run_id, f"NOT DETERMINISTIC: {out.run_id} vs {out2.run_id}"
    print(f"\nDeterministic ID: VERIFIED")

    print(f"\nSPATIAL vs UNIFORM: {spatial_count} spatial / {uniform_count} uniform")
    assert spatial_count >= 8, f"Only {spatial_count} spatial surfaces, expected >= 8"
    print("SPATIAL V2 SMOKE TEST PASSED")


if __name__ == '__main__':
    test_l1_adapter()
    test_full_pipeline()
