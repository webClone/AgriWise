import sys
import os

# Add project root to path
ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), "../../../"))
sys.path.insert(0, ROOT)


def test_layer1_weather_tensor():
    print("🧪 Test: Layer1 rainfall reaches FieldTensor...")

    from services.agribrain.layer1_fusion.data_fusion import fusion_engine

    start = "2023-01-01"
    end = "2023-01-10"

    out = fusion_engine.fuse_data(
        plot_id="TEST-PLOT-RAIN-001",
        lat=36.0,
        lng=3.0,
        start_date=start,
        end_date=end
    )
    print("Evidence items:", len(out.evidence_summary))
    print("Weather evidence count:", sum(1 for e in out.evidence_summary if str(e.get("id","")).startswith("wx_"))) 

    tensor = out.tensor
        # ---- Extract rain series safely ----
    ts = out.tensor.plot_timeseries
    assert isinstance(ts, list) and len(ts) > 0, "plot_timeseries empty"

    rain_series = [(row or {}).get("rain", 0.0) for row in ts]

    print("Rain series:", rain_series)

    # Must exist
    assert len(rain_series) > 0, "rain_series empty"
    # Must not be all zeros
    assert any((v or 0) > 0 for v in rain_series), "rain is all zeros"

    print("✅ PASS: Rain exists in Layer 1 timeseries.")



if __name__ == "__main__":
    test_layer1_weather_tensor()
