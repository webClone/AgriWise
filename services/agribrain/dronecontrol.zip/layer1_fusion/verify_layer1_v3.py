"""
Verification Script for AgriBrain Layer 1 (Refactored v3)
Tests FieldTensor Metadata, Confidence Channels, Split Corrections, and Auto-K Zoning.
"""

import sys
import os
import pandas as pd
import numpy as np

# Add services directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

def test_layer1_v3():
    print("🧪 Starting Layer 1 Verification (Scientific Spec v3)...")
    results = {}
    
    # 1. Test FieldTensor Metadata & Structure
    from layer1_fusion.data_fusion import fusion_engine, FieldTensor
    try:
        print("✅ Testing Fusion Engine (Tensor w/ Metadata)...")
        tensor = fusion_engine.fuse_data(
            plot_id="TEST-PLOT-001", 
            lat=36.0, lng=3.0, 
            start_date="2023-01-01", 
            end_date="2023-01-05", 
            width_px=3, height_px=3
        )
        
        has_meta = "plot_id" in tensor.metadata and "units" in tensor.metadata
        has_conf = hasattr(tensor, 'confidence') and tensor.confidence.shape == tensor.data.shape
        
        if has_meta and has_conf:
            results['tensor_schema'] = f"SUCCESS (PlotID={tensor.metadata['plot_id']}, ConfShape={tensor.confidence.shape})"
        else:
            results['tensor_schema'] = "FAILED (Missing Metadata or Confidence)"
            
    except Exception as e:
        results['tensor_schema'] = f"ERROR: {e}"

    # 2. Test Split Corrections
    from layer1_fusion.corrections import correction_engine
    try:
        print("✅ Testing Correction Pipeline (RealTime + Retrospective)...")
        
        # Apply pipeline
        corrected_tensor = correction_engine.run_full_correction(tensor, feature="ndvi")
        
        # Check if metadata logged
        logged = "smoothing_applied" in corrected_tensor.metadata
        if logged:
            results['correction_split'] = f"SUCCESS ({corrected_tensor.metadata['smoothing_applied']})"
        else:
            results['correction_split'] = "FAILED (Metadata not updated)"
            
    except Exception as e:
        results['correction_split'] = f"ERROR: {e}"

    # 3. Test Advanced Zoning
    from layer1_fusion.segmentation import segmentation_engine
    try:
        print("✅ Testing Auto-K Zoning (BIC/AIC/Silhouette)...")
        
        # 20 points, clear 2 clusters
        c1 = [{'mean_ndvi': 0.2, 'std_ndvi': 0.1} for _ in range(10)]
        c2 = [{'mean_ndvi': 0.8, 'std_ndvi': 0.1} for _ in range(10)]
        pixels = c1 + c2
        
        zones = segmentation_engine.segment_field(pixels, method='gmm', auto_k=True)
        distinct_zones = set(z['zone_id'] for z in zones)
        
        if len(distinct_zones) >= 2:
            results['auto_zoning'] = f"SUCCESS (Found {len(distinct_zones)} zones)"
        else:
            results['auto_zoning'] = f"WARNING (Found {len(distinct_zones)} zones - Expected >=2)"
            
    except Exception as e:
        results['auto_zoning'] = f"ERROR: {e}"

    print("\n--- Final Scientific Summary ---")
    for k, v in results.items():
        print(f"{k.upper()}: {v}")

    return results

if __name__ == "__main__":
    test_layer1_v3()
