"""
Verification Script for AgriBrain Layer 1 (Refactored)
Tests the presence of FieldTensor, Kalman Filters, GMM, and CNN stubs.
"""

import sys
import os
import pandas as pd
import numpy as np

# Add services directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

def test_layer1_advanced():
    print("🧪 Starting Layer 1 Verification (Advanced Specs)...")
    results = {}
    
    # 1. Test Fusion Engine & FieldTensor
    try:
        from layer1_fusion.data_fusion import fusion_engine, FieldTensor
        print("✅ Import: Data Fusion Engine & FieldTensor")
        
        # Mock Run
        tensor = fusion_engine.fuse_data(36.0, 3.0, "2023-01-01", "2023-01-05", width_px=5, height_px=5)
        
        if isinstance(tensor, FieldTensor) and tensor.data.ndim == 4:
            results['fusion_4d_tensor'] = f"SUCCESS (Shape: {tensor.data.shape})"
        else:
            results['fusion_4d_tensor'] = "FAILED (Not 4D FieldTensor)"
            
    except Exception as e:
        print(f"❌ Error: Fusion - {e}")
        results['fusion_4d_tensor'] = f"ERROR: {e}"

    # 2. Test Correction Engine (Kalman Filter)
    try:
        from layer1_fusion.corrections import correction_engine
        print("✅ Import: Correction Engine (Kalman)")
        
        # Reuse tensor from step 1 or create mock
        if 'tensor' not in locals():
             data = np.random.rand(5, 2, 2, 1) # simple mock
             dates = [1,2,3,4,5]
             features = ["ndvi"]
             bbox = {}
             tensor = FieldTensor(data, dates, features, bbox)
        
        # Run cleanup
        cleaned_tensor = correction_engine.process_field_tensor(tensor)
        results['kalman_filter'] = "SUCCESS (Ran without error)"
        
    except Exception as e:
        print(f"❌ Error: Correction - {e}")
        results['kalman_filter'] = f"ERROR: {e}"

    # 3. Test RGB Approximator (CNN Stub)
    try:
        from layer1_fusion.rgb_approximator import rgb_engine
        print("✅ Import: RGB Approximator")
        
        if hasattr(rgb_engine, 'load_cnn_model'):
            results['rgb_cnn_stub'] = "SUCCESS"
        else:
             results['rgb_cnn_stub'] = "FAILED (Missing load_cnn_model)"

    except Exception as e:
        print(f"❌ Error: RGB - {e}")
        results['rgb_cnn_stub'] = f"ERROR: {e}"

    # 4. Test Segmentation (GMM)
    try:
        from layer1_fusion.segmentation import segmentation_engine
        print("✅ Import: Segmentation Engine (GMM)")
        
        pixels = [
            {'lat': 10, 'lng': 10, 'mean_ndvi': 0.1, 'std_ndvi': 0.1},
            {'lat': 10, 'lng': 11, 'mean_ndvi': 0.9, 'std_ndvi': 0.05},
            {'lat': 10, 'lng': 12, 'mean_ndvi': 0.5, 'std_ndvi': 0.1}
        ]
        zones = segmentation_engine.segment_field(pixels, method='gmm')
        if zones[0].get('method') == 'gmm':
             results['gmm_clustering'] = "SUCCESS"
        else:
             results['gmm_clustering'] = "FAILED (Method tag missing)"
            
    except Exception as e:
        print(f"❌ Error: Segmentation - {e}")
        results['gmm_clustering'] = f"ERROR: {e}"

    print("\n--- Summary ---")
    for k, v in results.items():
        print(f"{k.upper()}: {v}")

    return results

if __name__ == "__main__":
    test_layer1_advanced()
