"""
Verification Script for AgriBrain Layer 1 (Data Fusion)
Tests the instantiation and basic execution of Layer 1 engines.
"""

import sys
import os
import pandas as pd
import numpy as np
from datetime import datetime

# Add services directory to path
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../../")))

def test_layer1():
    print("🧪 Starting Layer 1 Verification...")
    results = {}
    
    # 1. Test Fusion Engine
    try:
        from layer1_fusion.data_fusion import fusion_engine
        print("✅ Import: Multi-Source Data Fusion Engine")
        
        # Mock run (fetching might fail without credentials, but class should exist)
        # We test the method signature existence
        if hasattr(fusion_engine, 'fuse_data'):
            results['fusion'] = "SUCCESS"
        else:
            results['fusion'] = "FAILED (Method missing)"
            
    except ImportError as e:
        print(f"❌ Import Failed: Data Fusion Engine - {e}")
        results['fusion'] = f"IMPORT_ERROR: {e}"
    except Exception as e:
        print(f"❌ Error: Data Fusion Engine - {e}")
        results['fusion'] = f"ERROR: {e}"

    # 2. Test Correction Engine
    try:
        from layer1_fusion.corrections import correction_engine
        print("✅ Import: Cloud & Noise Correction Engine")
        
        # Test basic interpolation
        df = pd.DataFrame({
            'date': pd.date_range(start='2023-01-01', periods=5),
            'ndvi': [0.5, np.nan, 0.6, 0.2, 0.7] # 0.2 is sudden drop
        }).set_index('date')
        
        cleaned = correction_engine.process_timeseries(df, 'ndvi')
        if cleaned['ndvi'].isnull().sum() == 0:
            results['correction'] = "SUCCESS"
        else:
            results['correction'] = "FAILED (NaNs remain)"
            
    except ImportError as e:
        print(f"❌ Import Failed: Correction Engine - {e}")
        results['correction'] = f"IMPORT_ERROR: {e}"
    except Exception as e:
        print(f"❌ Error: Correction Engine - {e}")
        results['correction'] = f"ERROR: {e}"

    # 3. Test RGB Approximator
    try:
        from layer1_fusion.rgb_approximator import rgb_engine
        print("✅ Import: RGB Approximator")
        
        res = rgb_engine.estimate_health_from_rgb({'r': 100, 'g': 150, 'b': 50})
        if 'estimated_ndvi' in res:
            results['rgb'] = "SUCCESS"
        else:
            results['rgb'] = "FAILED"
            
    except ImportError as e:
        print(f"❌ Import Failed: RGB Approximator - {e}")
        results['rgb'] = f"IMPORT_ERROR: {e}"
    except Exception as e:
        print(f"❌ Error: RGB Approximator - {e}")
        results['rgb'] = f"ERROR: {e}"

    # 4. Test Segmentation
    try:
        from layer1_fusion.segmentation import segmentation_engine
        print("✅ Import: Zonal Segmentation Engine")
        
        # Mock pixels
        pixels = [
            {'lat': 10, 'lng': 10, 'mean_ndvi': 0.2, 'std_ndvi': 0.1},
            {'lat': 10, 'lng': 11, 'mean_ndvi': 0.8, 'std_ndvi': 0.05},
            {'lat': 10, 'lng': 12, 'mean_ndvi': 0.5, 'std_ndvi': 0.1}
        ]
        zones = segmentation_engine.segment_field(pixels)
        if len(zones) == 3 and 'zone_id' in zones[0]:
            results['segmentation'] = "SUCCESS"
        else:
            results['segmentation'] = "FAILED"
            
    except ImportError as e:
        print(f"❌ Import Failed: Segmentation Engine - {e}")
        results['segmentation'] = f"IMPORT_ERROR: {e}"
    except Exception as e:
        print(f"❌ Error: Segmentation Engine - {e}")
        results['segmentation'] = f"ERROR: {e}"

    print("\n--- Summary ---")
    for k, v in results.items():
        print(f"{k.upper()}: {v}")

    return results

if __name__ == "__main__":
    test_layer1()
