"""
Multi-Source Earth Observation Module
Integrates multiple free satellite and climate data sources:
- Sentinel-2 L2A: NDVI, EVI, NDWI, NDMI
- Sentinel-1 SAR: Soil moisture proxy
- Landsat-8/9: Thermal (Land Surface Temperature)
- ERA5: Historical climate data
- MODIS FIRMS: Fire risk
"""

import os
import requests
import time
from datetime import datetime, timedelta, timezone
from typing import Dict, List, Optional, Any
# --- Load environment variables (Next.js .env.local + .env) ---
try:
    from dotenv import load_dotenv
    load_dotenv(override=True)              # .env
    load_dotenv(".env.local", override=True)  # Next.js env file
except Exception:
    pass

# ============================================================================
# Configuration
# ============================================================================

SENTINEL_AUTH_URL = "https://identity.dataspace.copernicus.eu/auth/realms/CDSE/protocol/openid-connect/token"
SENTINEL_HUB_URL = "https://sh.dataspace.copernicus.eu"
SENTINEL_STATS_URL = "https://sh.dataspace.copernicus.eu/api/v1/statistics"
SENTINEL_PROCESS_URL = "https://sh.dataspace.copernicus.eu/api/v1/process"
OPEN_METEO_ARCHIVE_URL = "https://archive-api.open-meteo.com/v1/archive"
OPEN_METEO_CURRENT_URL = "https://api.open-meteo.com/v1/forecast"

# Global Token Cache
token_cache = {
    "access_token": None,
    "expires_at": 0
}

# Fast-fail guard: once auth fails, skip re-attempts in this process
_auth_failed = False
_auth_fail_reason = ""


# ============================================================================
# Authentication
# ============================================================================

def get_access_token():
    """
    Retrieves OAuth2 token from Copernicus Dataspace Ecosystem.
    Fast-fail: if auth has failed once this session, returns None immediately.
    """
    global token_cache, _auth_failed, _auth_fail_reason

    # Fast-fail guard: don't retry broken auth in the same process
    if _auth_failed:
        raise ConnectionError(f"Copernicus auth previously failed: {_auth_fail_reason}")

    if token_cache["access_token"] and time.time() < token_cache["expires_at"]:
        return token_cache["access_token"]

    client_id = os.getenv("SENTINEL_HUB_CLIENT_ID")
    client_secret = os.getenv("SENTINEL_HUB_CLIENT_SECRET")

    import traceback
    
    if not client_id or not client_secret:
        _auth_failed = True
        _auth_fail_reason = "Missing credentials"
        print(f"DEBUG: CLIENT_ID present: {bool(client_id)}")
        print(f"DEBUG: CLIENT_SECRET present: {bool(client_secret)}")
        raise ValueError("Missing SENTINEL_HUB_CLIENT_ID or SENTINEL_HUB_CLIENT_SECRET in environment")

    payload = {
        "grant_type": "client_credentials",
        "client_id": client_id,
        "client_secret": client_secret
    }
    
    # Fast-fail strategy: 1 retry, 8s timeout (not 30s x 3 retries)
    from requests.adapters import HTTPAdapter
    from urllib3.util.retry import Retry
    
    session = requests.Session()
    retry = Retry(
        total=1,
        backoff_factor=0.5,
        status_forcelist=[500, 502, 503, 504],
        allowed_methods=["POST"]
    )
    adapter = HTTPAdapter(max_retries=retry)
    session.mount("https://", adapter)
    
    try:
        response = session.post(SENTINEL_AUTH_URL, data=payload, timeout=8)
        
        if response.status_code != 200:
            print(f"Sentinel Auth Error ({response.status_code}): {response.text}")
            _auth_failed = True
            _auth_fail_reason = f"HTTP {response.status_code}"
            raise Exception(f"Sentinel Auth Failed: {response.text}")

        data_resp = response.json()
        token_cache["access_token"] = data_resp["access_token"]
        # Expire 60 seconds early to be safe
        token_cache["expires_at"] = time.time() + data_resp["expires_in"] - 60
        return token_cache["access_token"]
        
    except Exception as e:
        _auth_failed = True
        _auth_fail_reason = str(e)
        print(f"⚠️ Sentinel Auth Failed (fast-fail enabled for this session): {e}")
        raise


# ============================================================================
# RASTER EO ACQUISITION — Process API (Patch 1: Spatial Surfaces)
# Returns real pixel grids for zone engines. Stats API = plot summaries only.
# ============================================================================

def _build_process_bounds(polygon_coords: Optional[Any], lat: float, lng: float, buffer: float = 0.003):
    """Build bounds dict for the Process API — polygon preferred, bbox fallback."""
    coords = None
    if isinstance(polygon_coords, dict):
        if "coordinates" in polygon_coords:
            # Handle standard GeoJSON dict
            if polygon_coords["type"] == "Polygon":
                coords = polygon_coords["coordinates"][0]  # Take outer ring
            elif polygon_coords["type"] == "MultiPolygon":
                coords = polygon_coords["coordinates"][0][0]
    elif isinstance(polygon_coords, list):
        if len(polygon_coords) > 0 and isinstance(polygon_coords[0], list):
            # Nested list [[lng, lat], ...]
            coords = polygon_coords[0] if isinstance(polygon_coords[0][0], list) else polygon_coords
            
    if coords and len(coords) >= 3:
        return {
            "geometry": {"type": "Polygon", "coordinates": [coords]},
            "properties": {"crs": "http://www.opengis.net/def/crs/EPSG/0/4326"},
        }
        
    return {
        "bbox": [lng - buffer, lat - buffer, lng + buffer, lat + buffer],
        "properties": {"crs": "http://www.opengis.net/def/crs/EPSG/0/4326"},
    }


def _compute_raster_dimensions(polygon_coords: Optional[Any], lat: float, lng: float,
                                target_resolution_m: float = 10.0, max_dim: int = 64) -> tuple:
    """Compute pixel width/height for a polygon bbox at a target GSD."""
    import math
    coords = None
    if isinstance(polygon_coords, dict):
        if "coordinates" in polygon_coords:
            if polygon_coords["type"] == "Polygon":
                coords = polygon_coords["coordinates"][0]
            elif polygon_coords["type"] == "MultiPolygon":
                coords = polygon_coords["coordinates"][0][0]
    elif isinstance(polygon_coords, list):
        if len(polygon_coords) > 0 and isinstance(polygon_coords[0], list):
            coords = polygon_coords[0] if isinstance(polygon_coords[0][0], list) else polygon_coords
            
    if coords and len(coords) >= 3:
        xs = [c[0] for c in coords]
        ys = [c[1] for c in coords]
        d_lng = max(xs) - min(xs)
        d_lat = max(ys) - min(ys)
    else:
        d_lng = 0.006
        d_lat = 0.006
    m_per_deg_lat = 111320
    m_per_deg_lng = 111320 * math.cos(math.radians(lat))
    w = max(4, min(max_dim, int((d_lng * m_per_deg_lng) / target_resolution_m)))
    h = max(4, min(max_dim, int((d_lat * m_per_deg_lat) / target_resolution_m)))
    return w, h


def _parse_raster_tar(content: bytes, w: int, h: int, index_name: str,
                       start_date: str, end_date: str) -> Optional[Dict]:
    """Parse multipart tar from Sentinel Hub Process API into a grid dict.
    Securely reads TIFFs using tifffile to support LZW/Deflate compression.
    """
    try:
        import io, tarfile
        try:
            import tifffile
        except ImportError:
            print("⚠️ [Raster] 'tifffile' not installed. Please pip install tifffile.")
            return None
            
        tar = tarfile.open(fileobj=io.BytesIO(content))
        members = tar.getmembers()
        
        sub_grids = {}
        valid_mask = [[0] * w for _ in range(h)]
        pixel_count = w * h

        for m in members:
            if m.size > 0 and (m.name.endswith('.tiff') or m.name.endswith('.tif')):
                name_parts = m.name.split('.')
                band_id = name_parts[0].lower() if name_parts else "values"
                
                f = tar.extractfile(m)
                if f:
                    raw = f.read()
                    with tifffile.TiffFile(io.BytesIO(raw)) as tif:
                        pixels = tif.asarray()
                        # Ensure shape matches w, h
                        ph, pw = pixels.shape
                        
                        band_grid = [[None] * w for _ in range(h)]
                        for r in range(min(h, ph)):
                            for c in range(min(w, pw)):
                                v = float(pixels[r][c])
                                if band_id == "valid":
                                    if v > 0:
                                        valid_mask[r][c] = 1
                                else:
                                    if v > -9000:
                                        band_grid[r][c] = round(v, 6)
                        
                        if band_id != "valid":
                            sub_grids[band_id] = band_grid
        tar.close()
        
        valid_count = sum(sum(row) for row in valid_mask)
        coverage = valid_count / (w * h) if w * h > 0 else 0
        
        primary_grid = [[None] * w for _ in range(h)]
        for k, g in sub_grids.items():
            primary_grid = g
            break
            
        result = {
            "width": w, "height": h, "values": primary_grid, "valid_mask": valid_mask,
            "valid_pixel_count": valid_count, "coverage_ratio": round(coverage, 3),
            "source": "sentinel-2-l2a" if "SAR" not in index_name else "sentinel-1-grd",
            "index": index_name, "window": {"start": start_date, "end": end_date},
        }
        for k, g in sub_grids.items():
            result[k] = g
            
        return result
    except Exception as e:
        print(f"⚠️ [Raster] TAR parse error for {index_name}: {e}")
        return {
            "width": w, "height": h,
            "values": [[None] * w for _ in range(h)],
            "valid_mask": [[0] * w for _ in range(h)],
            "valid_pixel_count": 0, "coverage_ratio": 0.0,
            "source": "parse_failed", "index": index_name,
            "window": {"start": start_date, "end": end_date},
        }


def fetch_ndvi_raster_composite(lat: float, lng: float, start_date: str, end_date: str,
                                 polygon_coords: Optional[list] = None,
                                 target_resolution_m: float = 10.0) -> Optional[Dict]:
    """Fetch NDVI median composite raster via Process API."""
    try:
        token = get_access_token()
        bounds = _build_process_bounds(polygon_coords, lat, lng)
        w, h = _compute_raster_dimensions(polygon_coords, lat, lng, target_resolution_m)
        evalscript = """
        //VERSION=3
        function setup() {
            return {
                input: [{bands: ["B04","B08","dataMask"], timeRange: "full"}],
                output: [{id:"ndvi",bands:1,sampleType:"FLOAT32"},{id:"valid",bands:1,sampleType:"UINT8"}],
                mosaicking: "ORBIT"
            };
        }
        function evaluatePixel(samples) {
            var vals=[];
            for(var i=0;i<samples.length;i++){
                if(samples[i].dataMask==1&&samples[i].B08+samples[i].B04>0)
                    vals.push((samples[i].B08-samples[i].B04)/(samples[i].B08+samples[i].B04));
            }
            if(vals.length==0) return {ndvi:[-9999],valid:[0]};
            vals.sort(function(a,b){return a-b;});
            return {ndvi:[vals[Math.floor(vals.length/2)]],valid:[1]};
        }"""
        payload = {
            "input":{"bounds":bounds,"data":[{"type":"sentinel-2-l2a","dataFilter":{"mosaickingOrder":"leastCC"},
                     "timeRange":{"from":start_date+"T00:00:00Z","to":end_date+"T23:59:59Z"}}]},
            "output":{"width":w,"height":h,"responses":[{"identifier":"ndvi","format":{"type":"image/tiff"}},
                      {"identifier":"valid","format":{"type":"image/tiff"}}]},
            "evalscript":evalscript,
        }
        headers = {"Authorization":f"Bearer {token}","Content-Type":"application/json","Accept":"application/tar"}
        resp = requests.post(SENTINEL_PROCESS_URL, json=payload, headers=headers, timeout=30)
        if resp.status_code != 200:
            print(f"⚠️ [Raster] NDVI composite: {resp.status_code}")
            return None
        return _parse_raster_tar(resp.content, w, h, "NDVI", start_date, end_date)
    except Exception as e:
        print(f"⚠️ [Raster] NDVI error: {e}")
        return None


def fetch_ndmi_raster_composite(lat: float, lng: float, start_date: str, end_date: str,
                                 polygon_coords: Optional[list] = None,
                                 target_resolution_m: float = 10.0) -> Optional[Dict]:
    """Fetch NDMI (moisture) median composite raster. B08 vs B11."""
    try:
        token = get_access_token()
        bounds = _build_process_bounds(polygon_coords, lat, lng)
        w, h = _compute_raster_dimensions(polygon_coords, lat, lng, target_resolution_m)
        evalscript = """
        //VERSION=3
        function setup(){return{input:[{bands:["B08","B11","dataMask"],timeRange:"full"}],
          output:[{id:"ndmi",bands:1,sampleType:"FLOAT32"},{id:"valid",bands:1,sampleType:"UINT8"}],mosaicking:"ORBIT"};}
        function evaluatePixel(samples){var v=[];for(var i=0;i<samples.length;i++){
          if(samples[i].dataMask==1&&samples[i].B08+samples[i].B11>0)
            v.push((samples[i].B08-samples[i].B11)/(samples[i].B08+samples[i].B11));}
          if(v.length==0)return{ndmi:[-9999],valid:[0]};v.sort(function(a,b){return a-b;});
          return{ndmi:[v[Math.floor(v.length/2)]],valid:[1]};}"""
        payload = {
            "input":{"bounds":bounds,"data":[{"type":"sentinel-2-l2a","dataFilter":{"mosaickingOrder":"leastCC"},
                     "timeRange":{"from":start_date+"T00:00:00Z","to":end_date+"T23:59:59Z"}}]},
            "output":{"width":w,"height":h,"responses":[{"identifier":"ndmi","format":{"type":"image/tiff"}},
                      {"identifier":"valid","format":{"type":"image/tiff"}}]},
            "evalscript":evalscript,
        }
        headers = {"Authorization":f"Bearer {token}","Content-Type":"application/json","Accept":"application/tar"}
        resp = requests.post(SENTINEL_PROCESS_URL, json=payload, headers=headers, timeout=30)
        if resp.status_code != 200: return None
        return _parse_raster_tar(resp.content, w, h, "NDMI", start_date, end_date)
    except Exception as e:
        print(f"⚠️ [Raster] NDMI error: {e}")
        return None


def fetch_sar_raster_composite(lat: float, lng: float, start_date: str, end_date: str,
                                polygon_coords: Optional[list] = None,
                                target_resolution_m: float = 10.0) -> Optional[Dict]:
    """Fetch VV/VH mean composite rasters from Sentinel-1 GRD."""
    try:
        token = get_access_token()
        bounds = _build_process_bounds(polygon_coords, lat, lng)
        w, h = _compute_raster_dimensions(polygon_coords, lat, lng, target_resolution_m)
        evalscript = """
        //VERSION=3
        function setup(){return{input:[{bands:["VV","VH","dataMask"],timeRange:"full"}],
          output:[{id:"vv",bands:1,sampleType:"FLOAT32"},{id:"vh",bands:1,sampleType:"FLOAT32"},
                  {id:"valid",bands:1,sampleType:"UINT8"}],mosaicking:"ORBIT"};}
        function evaluatePixel(samples){var vs=0,hs=0,n=0;
          for(var i=0;i<samples.length;i++){if(samples[i].dataMask==1&&samples[i].VV>0&&samples[i].VH>0){
            vs+=10*Math.log10(samples[i].VV);hs+=10*Math.log10(samples[i].VH);n++;}}
          if(n==0)return{vv:[-9999],vh:[-9999],valid:[0]};
          return{vv:[vs/n],vh:[hs/n],valid:[1]};}"""
        payload = {
            "input":{"bounds":bounds,"data":[{"type":"sentinel-1-grd","dataFilter":{"mosaickingOrder":"mostRecent"},
                     "timeRange":{"from":start_date+"T00:00:00Z","to":end_date+"T23:59:59Z"}}]},
            "output":{"width":w,"height":h,"responses":[{"identifier":"vv","format":{"type":"image/tiff"}},
                      {"identifier":"vh","format":{"type":"image/tiff"}},
                      {"identifier":"valid","format":{"type":"image/tiff"}}]},
            "evalscript":evalscript,
        }
        headers = {"Authorization":f"Bearer {token}","Content-Type":"application/json","Accept":"application/tar"}
        resp = requests.post(SENTINEL_PROCESS_URL, json=payload, headers=headers, timeout=30)
        if resp.status_code != 200: return None
        return _parse_raster_tar(resp.content, w, h, "SAR_VV_VH", start_date, end_date)
    except Exception as e:
        print(f"⚠️ [Raster] SAR error: {e}")
        return None


def fetch_quality_mask(lat: float, lng: float, start_date: str, end_date: str,
                        polygon_coords: Optional[list] = None,
                        target_resolution_m: float = 10.0) -> Optional[Dict]:
    """Fetch scene classification quality mask from S2 SCL band."""
    try:
        token = get_access_token()
        bounds = _build_process_bounds(polygon_coords, lat, lng)
        w, h = _compute_raster_dimensions(polygon_coords, lat, lng, target_resolution_m)
        evalscript = """
        //VERSION=3
        function setup(){return{input:[{bands:["SCL","dataMask"],timeRange:"full"}],
          output:[{id:"quality",bands:1,sampleType:"FLOAT32"},{id:"valid",bands:1,sampleType:"UINT8"}],
          mosaicking:"ORBIT"};}
        function evaluatePixel(samples){var c=0,t=0;for(var i=0;i<samples.length;i++){
          if(samples[i].dataMask==1){t++;var s=samples[i].SCL;if(s==4||s==5||s==6)c++;}}
          if(t==0)return{quality:[0],valid:[0]};return{quality:[c/t],valid:[1]};}"""
        payload = {
            "input":{"bounds":bounds,"data":[{"type":"sentinel-2-l2a","dataFilter":{"mosaickingOrder":"leastCC"},
                     "timeRange":{"from":start_date+"T00:00:00Z","to":end_date+"T23:59:59Z"}}]},
            "output":{"width":w,"height":h,"responses":[{"identifier":"quality","format":{"type":"image/tiff"}},
                      {"identifier":"valid","format":{"type":"image/tiff"}}]},
            "evalscript":evalscript,
        }
        headers = {"Authorization":f"Bearer {token}","Content-Type":"application/json","Accept":"application/tar"}
        resp = requests.post(SENTINEL_PROCESS_URL, json=payload, headers=headers, timeout=30)
        if resp.status_code != 200: return None
        return _parse_raster_tar(resp.content, w, h, "QUALITY_MASK", start_date, end_date)
    except Exception as e:
        print(f"⚠️ [Raster] Quality mask error: {e}")
        return None


# ============================================================================
# Sentinel-2 L2A - Optical Indices (Stats Path — plot summaries)
# ============================================================================

def fetch_ndvi_timeseries(lat: float, lng: float, days: int = 180, polygon_coords: Optional[list] = None) -> Dict:
    """
    Fetches full history of NDVI statistics for the given period.
    Returns: { "data": [ { "date": "YYYY-MM-DD", "ndvi": float, ... }, ... ] }
    """
    try:
        token = get_access_token()
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        start_str = start_date.strftime("%Y-%m-%dT00:00:00Z")
        end_str = end_date.strftime("%Y-%m-%dT23:59:59Z")

        bounds = _build_process_bounds(polygon_coords, lat, lng)

        evalscript = """
        //VERSION=3
        function setup() {
            return {
                input: ["B04", "B08", "dataMask"],
                output: [
                    { id: "default", bands: 1, sampleType: "FLOAT32" },
                    { id: "dataMask", bands: 1, sampleType: "UINT8" }
                ]
            };
        }
        function evaluatePixel(sample) {
            let ndvi = (sample.B08 - sample.B04) / (sample.B08 + sample.B04);
            return {
                default: [ndvi],
                dataMask: [sample.dataMask]
            };
        }
        """

        payload = {
            "input": {
                "bounds": bounds,
                "data": [{
                    "type": "sentinel-2-l2a",
                    "timeRange": { "from": start_str, "to": end_str }
                }]
            },
            "aggregation": {
                "timeRange": { "from": start_str, "to": end_str },
                "aggregationInterval": { "of": "P1D" },
                "evalscript": evalscript,
                "resolution": 10
            }
        }

        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }

        response = requests.post(SENTINEL_STATS_URL, json=payload, headers=headers)
        
        if response.status_code != 200:
            print(f"Sentinel API Error: {response.text}")
            return {"data": []}

        result = response.json()
        data = result.get("data", [])
        
        valid_observations = []
        for item in data:
            outputs = item.get("outputs", {}).get("default", {}).get("bands", [])
            data_mask = item.get("outputs", {}).get("dataMask", {}).get("bands", [])
            
            if data_mask and data_mask[0].get("stats", {}).get("min") == 1:
                 stats = outputs[0].get("stats", {})
                 mean_ndvi = stats.get("mean")
                 if mean_ndvi is not None:
                     valid_observations.append({
                         "date": item["interval"]["from"].split("T")[0],
                         "ndvi": mean_ndvi
                     })
        
        return {"data": valid_observations}

    except Exception as e:
        print(f"Sentinel Fetch Error: {e}")
        return {"data": []}

def fetch_ndvi_stats(lat: float, lng: float) -> Optional[Dict]:
    """
    Legacy wrapper: Fetches NDVI statistics for the last 6 months.
    Returns the LATEST observation to maintain backward compatibility.
    """
    result = fetch_ndvi_timeseries(lat, lng, days=180)
    data = result.get("data", [])
    if data:
        return data[-1]
    return None


def fetch_vegetation_indices(lat: float, lng: float) -> Optional[Dict]:
    """
    Fetches multiple vegetation indices from Sentinel-2:
    - NDVI: Vegetation health
    - EVI: Enhanced vegetation (better for dense canopy)
    - NDWI: Water content in vegetation
    - NDMI: Moisture stress
    """
    try:
        token = get_access_token()
        end_date = datetime.now()
        start_date = end_date - timedelta(days=30)
        
        start_str = start_date.strftime("%Y-%m-%dT00:00:00Z")
        end_str = end_date.strftime("%Y-%m-%dT23:59:59Z")

        delta = 0.001
        bbox = [lng - delta, lat - delta, lng + delta, lat + delta]

        # Multi-index evalscript
        evalscript = """
        //VERSION=3
        function setup() {
            return {
                input: ["B02", "B03", "B04", "B08", "B11", "B12", "dataMask"],
                output: [
                    { id: "ndvi", bands: 1, sampleType: "FLOAT32" },
                    { id: "evi", bands: 1, sampleType: "FLOAT32" },
                    { id: "ndwi", bands: 1, sampleType: "FLOAT32" },
                    { id: "ndmi", bands: 1, sampleType: "FLOAT32" },
                    { id: "dataMask", bands: 1, sampleType: "UINT8" }
                ]
            };
        }
        function evaluatePixel(s) {
            // NDVI: (NIR - RED) / (NIR + RED)
            let ndvi = (s.B08 - s.B04) / (s.B08 + s.B04);
            
            // EVI: 2.5 * (NIR - RED) / (NIR + 6*RED - 7.5*BLUE + 1)
            let evi = 2.5 * (s.B08 - s.B04) / (s.B08 + 6*s.B04 - 7.5*s.B02 + 1);
            
            // NDWI: (GREEN - NIR) / (GREEN + NIR) - Water content
            let ndwi = (s.B03 - s.B08) / (s.B03 + s.B08);
            
            // NDMI: (NIR - SWIR1) / (NIR + SWIR1) - Moisture index
            let ndmi = (s.B08 - s.B11) / (s.B08 + s.B11);
            
            return {
                ndvi: [ndvi],
                evi: [evi],
                ndwi: [ndwi],
                ndmi: [ndmi],
                dataMask: [s.dataMask]
            };
        }
        """

        payload = {
            "input": {
                "bounds": {
                    "bbox": bbox,
                    "properties": { "crs": "http://www.opengis.net/def/crs/EPSG/0/4326" }
                },
                "data": [{
                    "type": "sentinel-2-l2a",
                    "timeRange": { "from": start_str, "to": end_str },
                    "dataFilter": { "maxCloudCoverage": 30 }
                }]
            },
            "aggregation": {
                "timeRange": { "from": start_str, "to": end_str },
                "aggregationInterval": { "of": "P30D" },
                "evalscript": evalscript,
                "resolution": 10
            }
        }

        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }

        response = requests.post(SENTINEL_STATS_URL, json=payload, headers=headers)
        
        if response.status_code != 200:
            print(f"Indices API Error: {response.text}")
            return None

        result = response.json()
        data = result.get("data", [])
        
        if not data:
            return None

        # Extract mean values
        item = data[-1]  # Latest aggregation
        outputs = item.get("outputs", {})
        
        return {
            "date": item["interval"]["from"].split("T")[0],
            "ndvi": outputs.get("ndvi", {}).get("bands", [{}])[0].get("stats", {}).get("mean"),
            "evi": outputs.get("evi", {}).get("bands", [{}])[0].get("stats", {}).get("mean"),
            "ndwi": outputs.get("ndwi", {}).get("bands", [{}])[0].get("stats", {}).get("mean"),
            "ndmi": outputs.get("ndmi", {}).get("bands", [{}])[0].get("stats", {}).get("mean"),
            "source": "sentinel-2-l2a"
        }

    except Exception as e:
        print(f"Vegetation indices fetch error: {e}")
        return None


# ============================================================================
# Sentinel-1 SAR - Soil Moisture Proxy
# ============================================================================

def fetch_soil_moisture_proxy(lat: float, lng: float) -> Optional[Dict]:
    """
    Fetches Sentinel-1 SAR backscatter as a soil moisture proxy.
    VV/VH polarization ratio correlates with soil moisture.
    Higher ratio = drier soil, Lower ratio = wetter soil
    """
    try:
        token = get_access_token()
        end_date = datetime.now()
        start_date = end_date - timedelta(days=90)  # 90 days for better data availability
        
        start_str = start_date.strftime("%Y-%m-%dT00:00:00Z")
        end_str = end_date.strftime("%Y-%m-%dT23:59:59Z")

        delta = 0.002
        bbox = [lng - delta, lat - delta, lng + delta, lat + delta]

        evalscript = """
        //VERSION=3
        function setup() {
            return {
                input: ["VV", "VH", "dataMask"],
                output: [
                    { id: "vv", bands: 1, sampleType: "FLOAT32" },
                    { id: "vh", bands: 1, sampleType: "FLOAT32" },
                    { id: "ratio", bands: 1, sampleType: "FLOAT32" },
                    { id: "dataMask", bands: 1, sampleType: "UINT8" }
                ]
            };
        }
        function evaluatePixel(s) {
            let mask = s.dataMask;
            // Guard against missing/invalid bands
            if (!s.VV || !s.VH || s.VH <= 0) mask = 0;

            let vv_db = 10 * Math.log10(s.VV);
            let vh_db = 10 * Math.log10(s.VH);
            let ratio = (mask === 1) ? (s.VV / s.VH) : 0;
            
            return {
                vv: [vv_db],
                vh: [vh_db],
                ratio: [ratio],
                dataMask: [mask]
            };
        }
        """

        payload = {
            "input": {
                "bounds": {
                    "bbox": bbox,
                    "properties": { "crs": "http://www.opengis.net/def/crs/EPSG/0/4326" }
                },
                "data": [{
                    "type": "sentinel-1-grd",
                    "timeRange": { "from": start_str, "to": end_str },
                    "dataFilter": {
                        "acquisitionMode": "IW",
                        "polarization": "DV"
                    }
                }]
            },
            "aggregation": {
                "timeRange": { "from": start_str, "to": end_str },
                "aggregationInterval": { "of": "P90D" },
                "evalscript": evalscript,
                "width": 1,
                "height": 1
            }
        }

        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }

        response = requests.post(SENTINEL_STATS_URL, json=payload, headers=headers)
        
        if response.status_code != 200:
            print(f"SAR API Error: {response.text}")
            return None

        result = response.json()
        data = result.get("data", [])
        
        if not data:
            return None

        item = data[-1]
        outputs = item.get("outputs", {})
        
        vv = outputs.get("vv", {}).get("bands", [{}])[0].get("stats", {}).get("mean")
        vh = outputs.get("vh", {}).get("bands", [{}])[0].get("stats", {}).get("mean")
        ratio = outputs.get("ratio", {}).get("bands", [{}])[0].get("stats", {}).get("mean")
        
        # Estimate soil moisture (simplified model)
        # Lower VV/VH ratio = more moisture
        if ratio:
            if ratio < 4:
                moisture_level = "wet"
            elif ratio < 8:
                moisture_level = "moist"
            else:
                moisture_level = "dry"
        else:
            moisture_level = "unknown"
        
        return {
            "date": item["interval"]["from"].split("T")[0],
            "vv_db": round(vv, 2) if vv else None,
            "vh_db": round(vh, 2) if vh else None,
            "vv_vh_ratio": round(ratio, 2) if ratio else None,
            "moisture_estimate": moisture_level,
            "source": "sentinel-1-grd"
        }

    except Exception as e:
        print(f"SAR fetch error: {e}")
    
    except Exception as e:
        print(f"SAR fetch error: {e}")
    
    return None


def fetch_sar_timeseries(lat: float, lng: float, days: int = 30, polygon_coords: Optional[list] = None) -> Optional[Dict]:
    """
    Fetches 30-day Sentinel-1 SAR time-series for trend analysis.
    Returns daily VV/VH values to track biomass evolution and moisture changes.
    Works through clouds - perfect complement to Sentinel-2.
    """
    try:
        token = get_access_token()
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        start_str = start_date.strftime("%Y-%m-%dT00:00:00Z")
        end_str = end_date.strftime("%Y-%m-%dT23:59:59Z")

        bounds = _build_process_bounds(polygon_coords, lat, lng, buffer=0.002)

        evalscript = """
        //VERSION=3
        function setup() {
            return {
                input: ["VV", "VH", "dataMask"],
                output: [
                    { id: "vv", bands: 1, sampleType: "FLOAT32" },
                    { id: "vh", bands: 1, sampleType: "FLOAT32" },
                    { id: "dataMask", bands: 1, sampleType: "UINT8" }
                ]
            };
        }
        function evaluatePixel(s) {
            let mask = s.dataMask;
            // Guard against missing/invalid bands
            if (!s.VV || !s.VH || s.VH <= 0) mask = 0;

            let vv_db = 10 * Math.log10(s.VV);
            let vh_db = 10 * Math.log10(s.VH);
            return {
                vv: [vv_db],
                vh: [vh_db],
                dataMask: [mask]
            };
        }
        """

        payload = {
            "input": {
                "bounds": bounds,
                "data": [{
                    "type": "sentinel-1-grd",
                    "timeRange": { "from": start_str, "to": end_str },
                    "dataFilter": { 
                        "acquisitionMode": "IW",
                        "polarization": "DV"
                    }
                }]
            },
            "aggregation": {
                "timeRange": { "from": start_str, "to": end_str },
                "aggregationInterval": { "of": "P6D" },  # 6-day intervals (S1 revisit)
                "evalscript": evalscript,
                "resolution": 10
            }
        }

        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }

        response = requests.post(SENTINEL_STATS_URL, json=payload, headers=headers)
        
        if response.status_code != 200:
            print(f"SAR Timeseries API Error: {response.text}")
            return None

        result = response.json()
        data = result.get("data", [])
        
        if not data:
            print(f"⚠️ SAR Timeseries Empty Data. Raw Response: {result}")
        
        timeseries = []
        for item in data:
            outputs = item.get("outputs", {})
            try:
                vv = outputs.get("vv", {}).get("bands", {}).get("B0", {}).get("stats", {}).get("mean")
                vh = outputs.get("vh", {}).get("bands", {}).get("B0", {}).get("stats", {}).get("mean")
            except (KeyError, IndexError, TypeError):
                continue
            date_str = item["interval"]["from"].split("T")[0]
            
            if vv is not None and vh is not None:
                timeseries.append({
                    "date": date_str,
                    "vv_db": round(vv, 2),
                    "vh_db": round(vh, 2),
                    "vv_vh_ratio": round(10**(vv/10) / 10**(vh/10), 2) if vh != 0 else None
                })
        
        return {
            "timeseries": timeseries,
            "count": len(timeseries),
            "period_days": days,
            "source": "sentinel-1-grd"
        }

    except Exception as e:
        print(f"⚠️ SAR timeseries fetch gracefully degraded: {e}")
        return {"data": [], "timeseries": []}


def fetch_biomass_estimate(lat: float, lng: float) -> Optional[Dict]:
    """
    Estimates crop biomass using VH backscatter.
    VH polarization correlates with vegetation volume/structure.
    Higher VH = more biomass (denser, taller crops).
    """
    try:
        token = get_access_token()
        end_date = datetime.now()
        start_date = end_date - timedelta(days=90)
        
        start_str = start_date.strftime("%Y-%m-%dT00:00:00Z")
        end_str = end_date.strftime("%Y-%m-%dT23:59:59Z")

        delta = 0.002
        bbox = [lng - delta, lat - delta, lng + delta, lat + delta]

        evalscript = """
        //VERSION=3
        function setup() {
            return {
                input: ["VH", "dataMask"],
                output: [
                    { id: "vh", bands: 1, sampleType: "FLOAT32" },
                    { id: "dataMask", bands: 1, sampleType: "UINT8" }
                ]
            };
        }
        function evaluatePixel(s) {
            let mask = s.dataMask;
            if (!s.VH || s.VH <= 0) mask = 0;
            return { vh: [10 * Math.log10(s.VH)], dataMask: [mask] };
        }
        """

        payload = {
            "input": {
                "bounds": {
                    "bbox": bbox,
                    "properties": { "crs": "http://www.opengis.net/def/crs/EPSG/0/4326" }
                },
                "data": [{
                    "type": "sentinel-1-grd",
                    "timeRange": { "from": start_str, "to": end_str },
                    "dataFilter": { 
                        "acquisitionMode": "IW",
                        "polarization": "DV" 
                    }
                }]
            },
            "aggregation": {
                "timeRange": { "from": start_str, "to": end_str },
                "aggregationInterval": { "of": "P12D" },
                "evalscript": evalscript,
                "width": 1,
                "height": 1
            }
        }

        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }

        response = requests.post(SENTINEL_STATS_URL, json=payload, headers=headers)
        
        if response.status_code != 200:
            print(f"Biomass API Error: {response.status_code}")

        result = response.json()
        data = result.get("data", [])
        
        if not data:
            print("Biomass API returned empty data")

        vh = data[-1].get("outputs", {}).get("vh", {}).get("bands", [{}])[0].get("stats", {}).get("mean")
        
        # Biomass classification based on VH backscatter
        # Typical VH ranges: Bare soil: -20 to -18 dB, Low veg: -18 to -14, Dense: -14 to -10
        if vh is not None:
            if vh > -12:
                biomass_level = "high"
                biomass_desc = "كثافة عالية"
            elif vh > -15:
                biomass_level = "medium"
                biomass_desc = "كثافة متوسطة"
            elif vh > -18:
                biomass_level = "low"
                biomass_desc = "كثافة منخفضة"
            else:
                biomass_level = "bare"
                biomass_desc = "تربة عارية"
        else:
            biomass_level = "unknown"
            biomass_desc = "غير متاح"
        
        return {
            "date": data[-1]["interval"]["from"].split("T")[0],
            "vh_db": round(vh, 2) if vh else None,
            "biomass_level": biomass_level,
            "biomass_desc": biomass_desc,
            "source": "sentinel-1-grd"
        }

    except Exception as e:
        print(f"Biomass estimate error: {e}")
    
    except Exception as e:
        print(f"Biomass estimate error: {e}")
    
    return None


def detect_flood_status(lat: float, lng: float) -> Optional[Dict]:
    """
    Detects flooded vs non-flooded soil using SAR.
    Flooded soil: Low VV (specular reflection) + relatively higher VH.
    Key insight: Water acts as a mirror for radar, reducing VV significantly.
    """
    try:
        token = get_access_token()
        end_date = datetime.now()
        start_date = end_date - timedelta(days=90)  # 90 days for better coverage
        
        start_str = start_date.strftime("%Y-%m-%dT00:00:00Z")
        end_str = end_date.strftime("%Y-%m-%dT23:59:59Z")

        delta = 0.002
        bbox = [lng - delta, lat - delta, lng + delta, lat + delta]

        evalscript = """
        //VERSION=3
        function setup() {
            return {
                input: ["VV", "VH", "dataMask"],
                output: [
                    { id: "vv", bands: 1, sampleType: "FLOAT32" },
                    { id: "vh", bands: 1, sampleType: "FLOAT32" },
                    { id: "dataMask", bands: 1, sampleType: "UINT8" }
                ]
            };
        }
        function evaluatePixel(s) {
            let mask = s.dataMask;
            if (!s.VV || !s.VH || s.VH <= 0) mask = 0;
            return {
                vv: [10 * Math.log10(s.VV)],
                vh: [10 * Math.log10(s.VH)],
                dataMask: [mask]
            };
        }
        """

        payload = {
            "input": {
                "bounds": {
                    "bbox": bbox,
                    "properties": { "crs": "http://www.opengis.net/def/crs/EPSG/0/4326" }
                },
                "data": [{
                    "type": "sentinel-1-grd",
                    "timeRange": { "from": start_str, "to": end_str },
                    "dataFilter": { 
                        "acquisitionMode": "IW", 
                        "polarization": "DV"
                    }
                }]
            },
            "aggregation": {
                "timeRange": { "from": start_str, "to": end_str },
                "aggregationInterval": { "of": "P6D" },
                "evalscript": evalscript,
                "width": 1,
                "height": 1
            }
        }

        headers = {
            "Authorization": f"Bearer {token}",
            "Content-Type": "application/json"
        }

        response = requests.post(SENTINEL_STATS_URL, json=payload, headers=headers)
        
        if response.status_code != 200:
            print(f"Flood API Error: {response.status_code}")

        result = response.json()
        data = result.get("data", [])
        
        if not data:
            print("Flood API returned empty data")

        outputs = data[-1].get("outputs", {})
        vv = outputs.get("vv", {}).get("bands", [{}])[0].get("stats", {}).get("mean")
        vh = outputs.get("vh", {}).get("bands", [{}])[0].get("stats", {}).get("mean")
        
        # Flood detection logic
        # Flooded: VV < -18 dB (water reflection) and VV-VH difference is small
        is_flooded = False
        flood_confidence = 0
        
        if vv is not None and vh is not None:
            vv_vh_diff = abs(vv - vh)
            
            if vv < -18:
                is_flooded = True
                flood_confidence = min(100, int(((-18 - vv) / 5) * 100))
            elif vv < -15 and vv_vh_diff < 5:
                is_flooded = True
                flood_confidence = 50
        
        return {
            "date": data[-1]["interval"]["from"].split("T")[0],
            "vv_db": round(vv, 2) if vv else None,
            "vh_db": round(vh, 2) if vh else None,
            "is_flooded": is_flooded,
            "flood_confidence": flood_confidence,
            "status": "مغمور بالماء" if is_flooded else "جاف",
            "source": "sentinel-1-grd"
        }

    except Exception as e:
        print(f"Flood detection error: {e}")
    
    except Exception as e:
        print(f"Flood detection error: {e}")
    
    return None


def detect_crop_emergence(lat: float, lng: float) -> Optional[Dict]:
    """
    Detects early crop emergence using VH temporal rise.
    SAR detects crop structure BEFORE NDVI reacts (optical needs chlorophyll).
    A rising VH trend over 2-3 weeks indicates crop emergence.
    """
    try:
        # Get 30-day timeseries
        ts_result = fetch_sar_timeseries(lat, lng, days=30)
        
        if not ts_result or len(ts_result.get("timeseries", [])) < 3:
            raise ValueError("Insufficient SAR timeseries data")
        
        timeseries = ts_result["timeseries"]
        
        # Calculate VH trend (simple linear regression)
        n = len(timeseries)
        vh_values = [t["vh_db"] for t in timeseries if t["vh_db"] is not None]
        
        if len(vh_values) < 3:
            raise ValueError("Insufficient VH values")
        
        # Calculate slope
        x_mean = (n - 1) / 2
        y_mean = sum(vh_values) / len(vh_values)
        
        numerator = sum((i - x_mean) * (vh_values[i] - y_mean) for i in range(len(vh_values)))
        denominator = sum((i - x_mean) ** 2 for i in range(len(vh_values)))
        
        slope = numerator / denominator if denominator != 0 else 0
        
        # Detect emergence
        # Rising VH slope (>0.1 dB/week) = crop emergence
        is_emerging = slope > 0.05
        emergence_confidence = min(100, int(slope * 200)) if slope > 0 else 0
        
        # Latest VH value
        latest_vh = vh_values[-1] if vh_values else None
        earliest_vh = vh_values[0] if vh_values else None
        vh_change = (latest_vh - earliest_vh) if (latest_vh and earliest_vh) else 0
        
        return {
            "period_days": 30,
            "vh_slope": round(slope, 4),
            "vh_change_db": round(vh_change, 2),
            "earliest_vh_db": round(earliest_vh, 2) if earliest_vh else None,
            "latest_vh_db": round(latest_vh, 2) if latest_vh else None,
            "is_emerging": is_emerging,
            "emergence_confidence": emergence_confidence,
            "status": "إنبات مبكر" if is_emerging else "لا يوجد إنبات",
            "source": "sentinel-1-grd"
        }

    except Exception as e:
        print(f"Crop emergence detection error: {e}")
    
    except Exception as e:
        print(f"Crop emergence detection error: {e}")
    
    return None


# ============================================================================
# ERA5 Historical Climate (via Open-Meteo)
# ============================================================================

def fetch_historical_weather(lat: float, lng: float, 
                              start_date: str, end_date: str) -> Optional[Dict]:
    """
    Fetches historical weather data from ERA5 via Open-Meteo.
    Useful for training data and climate pattern analysis.
    Note: Archive API only has data up to yesterday. We clamp end_date accordingly.
    """
    try:
        # Clamp end_date to yesterday — the archive API doesn't have today's data yet
        from datetime import datetime, timedelta
        yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
        clamped_end = min(end_date, yesterday)
        if clamped_end < start_date:
            # Entire requested range is in the future
            print(f"⚠️ [Weather] Requested range ({start_date} to {end_date}) is entirely future. No archive data.")
            return None
        
        params = {
            "latitude": lat,
            "longitude": lng,
            "start_date": start_date,
            "end_date": clamped_end,
            "daily": [
                "temperature_2m_max",
                "temperature_2m_min",
                "temperature_2m_mean",
                "precipitation_sum",
                "rain_sum",
                "et0_fao_evapotranspiration",
                "shortwave_radiation_sum",
                "windspeed_10m_max"
            ],
            "timezone": "auto"
        }
        
        response = requests.get(OPEN_METEO_ARCHIVE_URL, params=params, timeout=30)
        
        if response.status_code != 200:
            print(f"ERA5 API Error: {response.text}")
            return None
        
        data = response.json()
        daily = data.get("daily", {})
        
        if not daily.get("time"):
            return None
        
        # Package into records
        records = []
        for i, date in enumerate(daily["time"]):
            records.append({
                "date": date,
                "temp_max": daily.get("temperature_2m_max", [None])[i],
                "temp_min": daily.get("temperature_2m_min", [None])[i],
                "temp_mean": daily.get("temperature_2m_mean", [None])[i],
                "precipitation": daily.get("precipitation_sum", [None])[i],
                "rain": daily.get("rain_sum", [None])[i],
                "et0": daily.get("et0_fao_evapotranspiration", [None])[i],
                "solar_radiation": daily.get("shortwave_radiation_sum", [None])[i],
                "wind_max": daily.get("windspeed_10m_max", [None])[i]
            })
        
        return {
            "location": {"lat": lat, "lng": lng},
            "period": {"start": start_date, "end": end_date},
            "record_count": len(records),
            "records": records,
            "source": "era5-open-meteo"
        }

    except Exception as e:
        print(f"Historical weather fetch error: {e}")
        return None


# ============================================================================
# MODIS FIRMS - Fire Risk
# ============================================================================

def fetch_fire_risk(lat: float, lng: float, radius_km: int = 50) -> Optional[Dict]:
    """
    Fetches active fire data from NASA FIRMS (Fire Information for Resource Management).
    Returns fire detections within radius in the last 7 days.
    Note: Requires NASA FIRMS API key (free registration)
    """
    try:
        # Check for NASA API key (use NASA_API_KEY or NASA_FIRMS_API_KEY)
        api_key = os.getenv("NASA_API_KEY") or os.getenv("NASA_FIRMS_API_KEY")
        
        if not api_key:
            print("NASA API Key not set. Returning None.")
            return None
        
        # NASA FIRMS API
        url = f"https://firms.modaps.eosdis.nasa.gov/api/area/csv/{api_key}/VIIRS_SNPP_NRT/{lat},{lng},{radius_km}/7"
        
        response = requests.get(url, timeout=30)
        
        if response.status_code != 200:
            print(f"FIRMS API Error: {response.text}")
            return None
        
        # Parse CSV response
        lines = response.text.strip().split("\n")
        fire_count = len(lines) - 1  # Subtract header
        
        # Risk assessment
        if fire_count == 0:
            risk_level = "low"
        elif fire_count < 5:
            risk_level = "moderate"
        elif fire_count < 20:
            risk_level = "high"
        else:
            risk_level = "extreme"
        
        return {
            "location": {"lat": lat, "lng": lng},
            "search_radius_km": radius_km,
            "fire_count_7days": fire_count,
            "risk_level": risk_level,
            "source": "nasa-firms-viirs"
        }

    except Exception as e:
        print(f"FIRMS fetch error: {e}")
        return None


# ============================================================================
# Open-Meteo Soil Moisture (Multi-Layer)
# ============================================================================

def fetch_soil_moisture_layers(lat: float, lng: float) -> Optional[Dict]:
    """
    Fetches multi-layer soil moisture from Open-Meteo ERA5-Land archive.
    Uses the archive API (daily resolution, last 3 days) because the forecast
    API often returns nulls for soil moisture at many locations.
    This is FREE and requires NO API key.
    """
    try:
        from datetime import datetime, timedelta
        # Use archive API (yesterday - 3 days ago) for reliable ERA5-Land data
        end_date = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
        start_date = (datetime.now() - timedelta(days=3)).strftime("%Y-%m-%d")
        
        params = {
            "latitude": lat,
            "longitude": lng,
            "start_date": start_date,
            "end_date": end_date,
            "daily": [
                "soil_moisture_0_to_7cm_mean",
                "soil_moisture_7_to_28cm_mean",
                "soil_moisture_28_to_100cm_mean",
                "soil_temperature_0_to_7cm_mean",
                "soil_temperature_7_to_28cm_mean"
            ],
            "timezone": "auto"
        }
        
        response = requests.get(OPEN_METEO_ARCHIVE_URL, params=params, timeout=15)
        
        if response.status_code != 200:
            print(f"Open-Meteo Soil Error: {response.text}")
            return None
        
        data = response.json()
        daily = data.get("daily", {})
        
        if not daily.get("time"):
            return None
        
        # Get latest available day with data
        latest_idx = -1
        
        m_07 = daily.get("soil_moisture_0_to_7cm_mean", [None])[latest_idx]
        m_728 = daily.get("soil_moisture_7_to_28cm_mean", [None])[latest_idx]
        m_28100 = daily.get("soil_moisture_28_to_100cm_mean", [None])[latest_idx]
        t_07 = daily.get("soil_temperature_0_to_7cm_mean", [None])[latest_idx]
        t_728 = daily.get("soil_temperature_7_to_28cm_mean", [None])[latest_idx]
        
        # Reject if all values are None
        if all(v is None for v in [m_07, m_728, m_28100]):
            print("Open-Meteo returned empty soil data. Returning None.")
            return None
        
        return {
            "timestamp": daily["time"][latest_idx] if daily.get("time") else None,
            "moisture": {
                "0_7cm": m_07,
                "7_28cm": m_728,
                "28_100cm": m_28100,
            },
            "temperature": {
                "0_7cm": t_07,
                "7_28cm": t_728
            },
            "unit": "m³/m³",
            "source": "open-meteo-era5-land"
        }

    except Exception as e:
        print(f"Soil moisture fetch error: {e}")
        return None


# ============================================================================
# SoilGrids - Global Soil Properties (ISRIC - Free)
# ============================================================================

def fetch_soil_properties(lat: float, lng: float) -> Optional[Dict]:
    """
    Fetches soil properties from SoilGrids (ISRIC).
    Returns: pH, organic carbon, nitrogen, clay/sand/silt content.
    FREE - no API key required.
    """
    try:
        # SoilGrids REST API
        base_url = "https://rest.isric.org/soilgrids/v2.0/properties/query"
        
        params = {
            "lon": lng,
            "lat": lat,
            "property": ["phh2o", "nitrogen", "soc", "clay", "sand", "silt", "cec"],
            "depth": ["0-5cm", "5-15cm", "15-30cm"],
            "value": "mean"
        }
        
        response = requests.get(base_url, params=params, timeout=30)
        
        if response.status_code != 200:
            print(f"SoilGrids Error: {response.text}")
            return None
        
        data = response.json()
        properties = data.get("properties", {})
        layers = properties.get("layers", [])
        
        if not layers:
            return None
        
        # Parse results
        result = {
            "location": {"lat": lat, "lng": lng},
            "properties": {}
        }
        
        for layer in layers:
            prop_name = layer.get("name")
            depths = layer.get("depths", [])
            
            if depths:
                # Get top layer (0-5cm)
                top_layer = depths[0]
                values = top_layer.get("values", {})
                mean_val = values.get("mean")
                
                # Convert based on property
                if prop_name == "phh2o":
                    result["properties"]["ph"] = mean_val / 10 if mean_val else None  # Convert to pH
                elif prop_name == "nitrogen":
                    result["properties"]["nitrogen_g_kg"] = mean_val / 100 if mean_val else None
                elif prop_name == "soc":
                    result["properties"]["organic_carbon_g_kg"] = mean_val / 10 if mean_val else None
                elif prop_name == "clay":
                    result["properties"]["clay_percent"] = mean_val / 10 if mean_val else None
                elif prop_name == "sand":
                    result["properties"]["sand_percent"] = mean_val / 10 if mean_val else None
                elif prop_name == "silt":
                    result["properties"]["silt_percent"] = mean_val / 10 if mean_val else None
                elif prop_name == "cec":
                    result["properties"]["cec_cmol_kg"] = mean_val / 10 if mean_val else None
        
        result["source"] = "soilgrids-isric"
        return result

    except Exception as e:
        print(f"SoilGrids fetch error: {e}")
        return None


# ============================================================================
# NASA POWER - Solar Radiation & GDD
# ============================================================================

def fetch_solar_radiation(lat: float, lng: float, days: int = 7) -> Optional[Dict]:
    """
    Fetches solar radiation and temperature data from NASA POWER.
    Useful for: solar panel potential, GDD calculation, ET estimation.
    FREE - no API key required.
    """
    try:
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        params = {
            "parameters": "ALLSKY_SFC_SW_DWN,T2M,T2M_MAX,T2M_MIN,PRECTOTCORR,RH2M,WS2M",
            "community": "AG",
            "longitude": lng,
            "latitude": lat,
            "start": start_date.strftime("%Y%m%d"),
            "end": end_date.strftime("%Y%m%d"),
            "format": "JSON"
        }
        
        url = "https://power.larc.nasa.gov/api/temporal/daily/point"
        response = requests.get(url, params=params, timeout=30)
        
        if response.status_code != 200:
            print(f"NASA POWER Error: {response.text}")
            return None
        
        data = response.json()
        properties = data.get("properties", {}).get("parameter", {})
        
        if not properties:
            return None
        
        # Calculate GDD (Growing Degree Days) - base 10°C
        gdd_total = 0
        daily_records = []
        
        dates = list(properties.get("T2M", {}).keys())
        for date in dates:
            t_max = properties.get("T2M_MAX", {}).get(date)
            t_min = properties.get("T2M_MIN", {}).get(date)
            solar = properties.get("ALLSKY_SFC_SW_DWN", {}).get(date)
            precip = properties.get("PRECTOTCORR", {}).get(date)
            
            if t_max is not None and t_min is not None:
                t_avg = (t_max + t_min) / 2
                gdd = max(0, t_avg - 10)  # Base 10°C
                gdd_total += gdd
                
                daily_records.append({
                    "date": f"{date[:4]}-{date[4:6]}-{date[6:8]}",
                    "solar_radiation_mj_m2": solar,
                    "temp_max": t_max,
                    "temp_min": t_min,
                    "precipitation_mm": precip,
                    "gdd": round(gdd, 1)
                })
        
        return {
            "location": {"lat": lat, "lng": lng},
            "period_days": days,
            "gdd_total": round(gdd_total, 1),
            "gdd_base": 10,
            "records": daily_records,
            "source": "nasa-power"
        }

    except Exception as e:
        print(f"NASA POWER fetch error: {e}")
        return None


# ============================================================================
# Open-Elevation - Terrain Data (Free)
# ============================================================================

def fetch_elevation(lat: float, lng: float) -> Optional[Dict]:
    """
    Fetches elevation data from Open-Elevation API.
    FREE - no API key required.
    """
    try:
        url = "https://api.open-elevation.com/api/v1/lookup"
        params = {"locations": f"{lat},{lng}"}
        
        response = requests.get(url, params=params, timeout=15)
        
        if response.status_code != 200:
            print(f"Elevation API Error: {response.text}")
            return None
        
        data = response.json()
        results = data.get("results", [])
        
        if not results:
            return None
        
        elevation = results[0].get("elevation")
        
        return {
            "location": {"lat": lat, "lng": lng},
            "elevation_m": elevation,
            "source": "open-elevation"
        }

    except Exception as e:
        print(f"Elevation fetch error: {e}")
        return None


# ============================================================================
# Air Quality (Open-Meteo - Free)
# ============================================================================

def fetch_air_quality(lat: float, lng: float) -> Optional[Dict]:
    """
    Fetches air quality data from Open-Meteo.
    Returns: PM2.5, PM10, Ozone, NO2, SO2.
    FREE - no API key required.
    """
    try:
        url = "https://air-quality-api.open-meteo.com/v1/air-quality"
        params = {
            "latitude": lat,
            "longitude": lng,
            "current": ["pm10", "pm2_5", "ozone", "nitrogen_dioxide", "sulphur_dioxide", 
                       "european_aqi", "us_aqi"],
            "timezone": "auto"
        }
        
        response = requests.get(url, params=params, timeout=15)
        
        if response.status_code != 200:
            print(f"Air Quality Error: {response.text}")
            return None
        
        data = response.json()
        current = data.get("current", {})
        
        if not current:
            return None
        
        return {
            "timestamp": current.get("time"),
            "pm2_5": current.get("pm2_5"),
            "pm10": current.get("pm10"),
            "ozone": current.get("ozone"),
            "no2": current.get("nitrogen_dioxide"),
            "so2": current.get("sulphur_dioxide"),
            "aqi_eu": current.get("european_aqi"),
            "aqi_us": current.get("us_aqi"),
            "source": "open-meteo-air-quality"
        }

    except Exception as e:
        print(f"Air quality fetch error: {e}")
        return None



# NOTE: fetch_soil_moisture_layers is defined above (line ~1001) using the ERA5 archive API.
# A duplicate was removed from here that used the forecast API which returns nulls.


def fetch_soil_properties(lat: float, lng: float) -> Optional[Dict]:
    """
    Fetches soil properties from SoilGrids API.
    Returns pH, organic carbon, nitrogen, and texture (clay/sand/silt).
    """
    try:
        # SoilGrids REST API
        url = f"https://rest.isric.org/soilgrids/v2.0/properties/query"
        params = {
            "lon": lng,
            "lat": lat,
            "property": ["phh2o", "soc", "nitrogen", "clay", "sand", "silt"],
            "depth": "0-5cm",
            "value": "mean"
        }
        response = requests.get(url, params=params, timeout=20)
        
        if response.status_code == 200:
            data = response.json()
            properties = data.get("properties", {})
            layers = properties.get("layers", [])
            
            result = {
                "source": "soilgrids"
            }
            
            for layer in layers:
                name = layer.get("name", "")
                depths = layer.get("depths", [])
                if depths:
                    value = depths[0].get("values", {}).get("mean")
                    
                    if name == "phh2o" and value is not None:
                        result["ph"] = value / 10  # SoilGrids stores pH * 10
                    elif name == "soc" and value is not None:
                        result["organic_carbon"] = value / 10  # dg/kg to g/kg
                    elif name == "nitrogen" and value is not None:
                        result["nitrogen"] = value  # cg/kg to mg/kg
                    elif name == "clay" and value is not None:
                        result["clay"] = value / 10  # g/kg to %
                    elif name == "sand" and value is not None:
                        result["sand"] = value / 10
                    elif name == "silt" and value is not None:
                        result["silt"] = value / 10
            
            # Classify texture
            sand = result.get("sand", 0)
            clay = result.get("clay", 0)
            if sand > 70:
                result["texture_class"] = "رملية"
            elif clay > 40:
                result["texture_class"] = "طينية"
            elif sand > 50:
                result["texture_class"] = "رملية طمية"
            else:
                result["texture_class"] = "طمية"
            
            return result
        else:
            print(f"SoilGrids API error: {response.status_code}")
            return None

    except Exception as e:
        print(f"Soil properties fetch error: {e}")
        return None


# ============================================================================
# OpenWeatherMap - Weather & UV Index (Uses existing OPENWEATHER_API_KEY)
# ============================================================================

def _fetch_open_meteo_weather(lat: float, lng: float) -> Optional[Dict]:
    """
    Fallback weather data from Open-Meteo (free, no API key required).
    """
    try:
        url = "https://api.open-meteo.com/v1/forecast"
        params = {
            "latitude": lat,
            "longitude": lng,
            "current": "temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,wind_direction_10m,surface_pressure,cloud_cover",
            "timezone": "auto"
        }
        response = requests.get(url, params=params, timeout=15)
        if response.status_code == 200:
            data = response.json()
            current = data.get("current", {})
            
            # Map weather code to condition
            wmo_codes = {
                0: ("Clear", "clear sky"),
                1: ("Clear", "mainly clear"),
                2: ("Clouds", "partly cloudy"),
                3: ("Clouds", "overcast"),
                45: ("Fog", "fog"),
                48: ("Fog", "depositing rime fog"),
                51: ("Drizzle", "light drizzle"),
                53: ("Drizzle", "moderate drizzle"),
                55: ("Drizzle", "dense drizzle"),
                61: ("Rain", "slight rain"),
                63: ("Rain", "moderate rain"),
                65: ("Rain", "heavy rain"),
                71: ("Snow", "slight snow"),
                73: ("Snow", "moderate snow"),
                75: ("Snow", "heavy snow"),
                80: ("Rain", "rain showers"),
                95: ("Thunderstorm", "thunderstorm"),
            }
            code = current.get("weather_code", 0)
            condition, desc = wmo_codes.get(code, ("Clear", "unknown"))
            
            return {
                "location": f"Lat {lat:.2f}, Lng {lng:.2f}",
                "coordinates": {"lat": lat, "lng": lng},
                "weather": {
                    "condition": condition,
                    "description": desc,
                    "icon": "01d"
                },
                "temperature": {
                    "current": current.get("temperature_2m"),
                    "feels_like": current.get("apparent_temperature"),
                    "min": current.get("temperature_2m"),
                    "max": current.get("temperature_2m")
                },
                "humidity": current.get("relative_humidity_2m"),
                "pressure": current.get("surface_pressure"),
                "visibility_m": 10000,
                "wind": {
                    "speed_ms": current.get("wind_speed_10m"),
                    "direction_deg": current.get("wind_direction_10m"),
                    "gust_ms": None
                },
                "clouds_percent": current.get("cloud_cover"),
                "source": "open-meteo"
            }
    except Exception as e:
        print(f"Open-Meteo weather fetch error: {e}")
    return None

def fetch_openweather_data(lat: float, lng: float) -> Optional[Dict]:
    """
    Fetches comprehensive weather data from OpenWeatherMap.
    Uses your existing OPENWEATHER_API_KEY from .env file.
    Returns: current weather, UV index, feels like, visibility, etc.
    """
    try:
        api_key = os.getenv("OPENWEATHER_API_KEY")
        
        # Debug: Check if key is loaded
        if api_key:
            print(f"🔑 OpenWeather API Key loaded: {api_key[:8]}...{api_key[-4:]}")
        else:
            print("❌ OpenWeather API Key NOT FOUND in environment")
        
        if not api_key:
            return {
                "status": "api_key_required",
                "message": "Set OPENWEATHER_API_KEY environment variable"
            }
        
        # Strip quotes if present (common .env issue)
        api_key = api_key.strip().strip('"').strip("'")
        
        # Current weather + more details
        url = "https://api.openweathermap.org/data/2.5/weather"
        params = {
            "lat": lat,
            "lon": lng,
            "appid": api_key,
            "units": "metric"
        }
        
        response = requests.get(url, params=params, timeout=15)
        
        if response.status_code != 200:
            print(f"OpenWeatherMap Error ({response.status_code}): {response.text}")
            print("Trying Open-Meteo fallback...")
            return _fetch_open_meteo_weather(lat, lng)
        
        data = response.json()
        main = data.get("main", {})
        wind = data.get("wind", {})
        weather = data.get("weather", [{}])[0]
        clouds = data.get("clouds", {})
        
        result = {
            "location": data.get("name"),
            "coordinates": {"lat": lat, "lng": lng},
            "weather": {
                "condition": weather.get("main"),
                "description": weather.get("description"),
                "icon": weather.get("icon")
            },
            "temperature": {
                "current": main.get("temp"),
                "feels_like": main.get("feels_like"),
                "min": main.get("temp_min"),
                "max": main.get("temp_max")
            },
            "humidity": main.get("humidity"),
            "pressure": main.get("pressure"),
            "visibility_m": data.get("visibility"),
            "wind": {
                "speed_ms": wind.get("speed"),
                "direction_deg": wind.get("deg"),
                "gust_ms": wind.get("gust")
            },
            "clouds_percent": clouds.get("all"),
            "source": "openweathermap"
        }
        
        # Try to get UV index (separate call)
        try:
            uv_url = "https://api.openweathermap.org/data/2.5/uvi"
            uv_params = {"lat": lat, "lon": lng, "appid": api_key}
            uv_response = requests.get(uv_url, params=uv_params, timeout=10)
            if uv_response.status_code == 200:
                uv_data = uv_response.json()
                result["uv_index"] = uv_data.get("value")
        except:
            pass  # UV index is optional
        
        return result

    except Exception as e:
        print(f"OpenWeatherMap fetch error: {e}")
        # Fallback to Open-Meteo (free, no API key needed)
        try:
            print("Trying Open-Meteo fallback...")
            url = "https://api.open-meteo.com/v1/forecast"
            params = {
                "latitude": lat,
                "longitude": lng,
                "current": "temperature_2m,relative_humidity_2m,apparent_temperature,weather_code,wind_speed_10m,wind_direction_10m,surface_pressure,cloud_cover",
                "timezone": "auto"
            }
            response = requests.get(url, params=params, timeout=15)
            if response.status_code == 200:
                data = response.json()
                current = data.get("current", {})
                
                # Map weather code to condition
                wmo_codes = {
                    0: ("Clear", "clear sky"),
                    1: ("Clear", "mainly clear"),
                    2: ("Clouds", "partly cloudy"),
                    3: ("Clouds", "overcast"),
                    45: ("Fog", "fog"),
                    48: ("Fog", "depositing rime fog"),
                    51: ("Drizzle", "light drizzle"),
                    53: ("Drizzle", "moderate drizzle"),
                    55: ("Drizzle", "dense drizzle"),
                    61: ("Rain", "slight rain"),
                    63: ("Rain", "moderate rain"),
                    65: ("Rain", "heavy rain"),
                    71: ("Snow", "slight snow"),
                    73: ("Snow", "moderate snow"),
                    75: ("Snow", "heavy snow"),
                    80: ("Rain", "rain showers"),
                    95: ("Thunderstorm", "thunderstorm"),
                }
                code = current.get("weather_code", 0)
                condition, desc = wmo_codes.get(code, ("Clear", "unknown"))
                
                return {
                    "location": f"Lat {lat}, Lng {lng}",
                    "coordinates": {"lat": lat, "lng": lng},
                    "weather": {
                        "condition": condition,
                        "description": desc,
                        "icon": "01d"
                    },
                    "temperature": {
                        "current": current.get("temperature_2m"),
                        "feels_like": current.get("apparent_temperature"),
                        "min": current.get("temperature_2m"),
                        "max": current.get("temperature_2m")
                    },
                    "humidity": current.get("relative_humidity_2m"),
                    "pressure": current.get("surface_pressure"),
                    "visibility_m": 10000,
                    "wind": {
                        "speed_ms": current.get("wind_speed_10m"),
                        "direction_deg": current.get("wind_direction_10m"),
                        "gust_ms": None
                    },
                    "clouds_percent": current.get("cloud_cover"),
                    "source": "open-meteo-fallback"
                }
        except Exception as e2:
            print(f"Open-Meteo fallback also failed: {e2}")
        return None


def fetch_openweather_forecast(lat: float, lng: float) -> Optional[Dict]:
    """
    Fetches 7-day weather forecast from Open-Meteo (Free, No API Key).
    Replaces the previous OpenWeatherMap 5-day limit.
    """
    try:
        url = "https://api.open-meteo.com/v1/forecast"
        params = {
            "latitude": lat,
            "longitude": lng,
            "daily": "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,wind_speed_10m_max",
            "hourly": "relative_humidity_2m", # Needed to approximate daily humidity
            "timezone": "auto",
            "forecast_days": 8  # precise 7 days sometimes excludes today if late
        }
        
        response = requests.get(url, params=params, timeout=15)
        
        if response.status_code != 200:
            print(f"Open-Meteo Forecast Error: {response.text}")
            return None
        
        data = response.json()
        daily = data.get("daily", {})
        hourly = data.get("hourly", {})
        
        if not daily.get("time"):
            return None

        # WMO Code Mapping (Code -> (Condition, Description, Icon))
        wmo_map = {
            0: ("Clear", "سماء صافية", "01d"),
            1: ("Clear", "غائم جزئياً", "02d"),
            2: ("Clouds", "غائم جزئياً", "03d"),
            3: ("Clouds", "غائم", "04d"),
            45: ("Fog", "ضباب", "50d"),
            48: ("Fog", "ضباب جليدي", "50d"),
            51: ("Drizzle", "رذاذ خفيف", "09d"),
            53: ("Drizzle", "رذاذ متوسط", "09d"),
            55: ("Drizzle", "رذاذ كثيف", "09d"),
            61: ("Rain", "مطر خفيف", "10d"),
            63: ("Rain", "مطر متوسط", "10d"),
            65: ("Rain", "مطر غزير", "10d"),
            66: ("Rain", "مطر متجمد", "13d"),
            67: ("Rain", "مطر متجمد غزير", "13d"),
            71: ("Snow", "ثلوج خفيفة", "13d"),
            73: ("Snow", "ثلوج متوسطة", "13d"),
            75: ("Snow", "ثلوج كثيفة", "13d"),
            77: ("Snow", "حبيبات ثلجية", "13d"),
            80: ("Rain", "زخات مطر", "09d"),
            81: ("Rain", "زخات مطر متوسطة", "09d"),
            82: ("Rain", "زخات مطر غزيرة", "09d"),
            85: ("Snow", "زخات ثلج", "13d"),
            86: ("Snow", "زخات ثلج غزيرة", "13d"),
            95: ("Thunderstorm", "عاصفة رعدية", "11d"),
            96: ("Thunderstorm", "عاصفة رعدية مع برد", "11d"),
            99: ("Thunderstorm", "عاصفة رعدية شديدة", "11d"),
        }

        forecast_list = []
        timestamps = daily["time"]
        
        for i, date_str in enumerate(timestamps):
            if i >= 7: break # Limit to 7 days
            
            code = daily["weather_code"][i]
            condition, desc, icon = wmo_map.get(code, ("Clouds", "غير معروف", "03d"))
            
            # Approximate humidity (Take noon value -> index 12 + i*24)
            # This is a rough approximation as hourly array aligns with daily 00:00 start
            hum_idx = (i * 24) + 12
            humidity = 50 # Default
            if "relative_humidity_2m" in hourly and len(hourly["relative_humidity_2m"]) > hum_idx:
                humidity = hourly["relative_humidity_2m"][hum_idx]

            pop = daily["precipitation_probability_max"][i]
            if pop is not None:
                pop = pop / 100.0 # Convert % to 0-1
            else:
                pop = 0.0

            forecast_list.append({
                "date": date_str,
                "temp_min": daily["temperature_2m_min"][i],
                "temp_max": daily["temperature_2m_max"][i],
                "humidity": humidity,
                "weather": condition,
                "description": desc,
                "icon": icon,
                "wind_speed": daily["wind_speed_10m_max"][i],
                "pop": pop
            })
        
        return {
            "location": {"lat": lat, "lng": lng},
            "forecast_days": len(forecast_list),
            "forecast": forecast_list, # Key changed from 'daily' to 'forecast' to match frontend expects?
            # Wait, looking at frontend code: `setForecast(forecastData.forecast.slice(0, 5))`
            # So the key returned MUST be `forecast`.
            # The previous code returned `daily` key with list?
            # Let me check previous code.
            # Previous code (lines 1742): `"daily": list(daily_summary.values())`
            # Frontend code (line 98): `if (forecastData.forecast && ...)`
            # WAIT. The frontend expects `forecast`. 
            # But the backend WAS returning `daily`. 
            # This means the frontend was probably broken or I misread the frontend code.
            # Let's check frontend code again.
            # Frontend Step 9786 line 98: `if (forecastData.forecast && !forecastData.error)`
            # Backend Step 9884 line 1742: `"daily": list(daily_summary.values())`
            # THIS EXPLAINS WHY IT WAS EMPTY! There was a key mismatch!
            # frontend wanted `forecast`, backend gave `daily`.
            # I will fix this by returning `forecast`.
            "source": "open-meteo-7day"
        }

    except Exception as e:
        print(f"Open-Meteo forecast error: {e}")
        return None


# ============================================================================
# Combined Multi-Source Query
# ============================================================================

def fetch_all_eo_data(lat: float, lng: float) -> Dict:
    """
    Fetches ALL available EO data for a location.
    Returns a combined dataset from ALL free sources.
    """
    results = {
        "location": {"lat": lat, "lng": lng},
        "timestamp": datetime.now().isoformat(),
        "sources": {}
    }
    
    # Sentinel-2 Vegetation Indices
    try:
        indices = fetch_vegetation_indices(lat, lng)
        if indices:
            results["sources"]["sentinel2_indices"] = indices
    except Exception as e:
        results["sources"]["sentinel2_indices"] = {"error": str(e)}
    
    # Sentinel-1 Soil Moisture (SAR)
    try:
        sar_moisture = fetch_soil_moisture_proxy(lat, lng)
        if sar_moisture:
            results["sources"]["sentinel1_sar"] = sar_moisture
    except Exception as e:
        results["sources"]["sentinel1_sar"] = {"error": str(e)}
    
    # Open-Meteo Soil Moisture (Multi-layer)
    try:
        soil_layers = fetch_soil_moisture_layers(lat, lng)
        if soil_layers:
            results["sources"]["soil_moisture_layers"] = soil_layers
    except Exception as e:
        results["sources"]["soil_moisture_layers"] = {"error": str(e)}
    
    # SoilGrids Properties
    try:
        soil_props = fetch_soil_properties(lat, lng)
        if soil_props:
            results["sources"]["soil_properties"] = soil_props
    except Exception as e:
        results["sources"]["soil_properties"] = {"error": str(e)}
    
    # NASA POWER Solar/GDD
    try:
        solar = fetch_solar_radiation(lat, lng, days=7)
        if solar:
            results["sources"]["nasa_power"] = solar
    except Exception as e:
        results["sources"]["nasa_power"] = {"error": str(e)}
    
    # Air Quality
    try:
        air = fetch_air_quality(lat, lng)
        if air:
            results["sources"]["air_quality"] = air
    except Exception as e:
        results["sources"]["air_quality"] = {"error": str(e)}
    
    # Elevation
    try:
        elev = fetch_elevation(lat, lng)
        if elev:
            results["sources"]["elevation"] = elev
    except Exception as e:
        results["sources"]["elevation"] = {"error": str(e)}
    
    # Fire Risk
    try:
        fire = fetch_fire_risk(lat, lng)
        if fire:
            results["sources"]["fire_risk"] = fire
    except Exception as e:
        results["sources"]["fire_risk"] = {"error": str(e)}
    
    # OpenWeatherMap
    try:
        owm = fetch_openweather_data(lat, lng)
        if owm:
            results["sources"]["openweathermap"] = owm
    except Exception as e:
        results["sources"]["openweathermap"] = {"error": str(e)}
    
    # Summary
    results["data_sources_queried"] = len(results["sources"])
    results["sources_available"] = [k for k, v in results["sources"].items() if "error" not in v]
    
    return results


# ============================================================================
# PHENOLOGY & GROWTH STAGE DATA
# ============================================================================

# Comprehensive Crop Calendar Database (50+ crops)
CROP_CALENDARS = {
    # CEREALS
    "wheat": {"cycle_days": 180, "base_temp": 0, "optimal_temp": {"min": 12, "max": 25}, "gdd_requirements": {"emergence": 150, "tillering": 500, "heading": 900, "maturity": 1800}},
    "barley": {"cycle_days": 150, "base_temp": 0, "optimal_temp": {"min": 12, "max": 22}, "gdd_requirements": {"emergence": 130, "tillering": 450, "heading": 800, "maturity": 1500}},
    "corn": {"cycle_days": 130, "base_temp": 10, "optimal_temp": {"min": 20, "max": 30}, "gdd_requirements": {"emergence": 120, "v6": 475, "tasseling": 750, "maturity": 1400}},
    "maize": {"cycle_days": 130, "base_temp": 10, "optimal_temp": {"min": 20, "max": 30}, "gdd_requirements": {"emergence": 120, "v6": 475, "tasseling": 750, "maturity": 1400}},
    "rice": {"cycle_days": 150, "base_temp": 10, "optimal_temp": {"min": 22, "max": 32}, "gdd_requirements": {"emergence": 100, "tillering": 500, "heading": 1000, "maturity": 1800}},
    "sorghum": {"cycle_days": 120, "base_temp": 15, "optimal_temp": {"min": 25, "max": 35}, "gdd_requirements": {"emergence": 80, "boot": 600, "heading": 900, "maturity": 1400}},
    "millet": {"cycle_days": 90, "base_temp": 15, "optimal_temp": {"min": 25, "max": 35}, "gdd_requirements": {"emergence": 60, "heading": 500, "maturity": 900}},
    "oat": {"cycle_days": 140, "base_temp": 0, "optimal_temp": {"min": 10, "max": 20}, "gdd_requirements": {"emergence": 120, "tillering": 400, "heading": 750, "maturity": 1400}},
    "rye": {"cycle_days": 160, "base_temp": 0, "optimal_temp": {"min": 8, "max": 18}, "gdd_requirements": {"emergence": 140, "tillering": 480, "heading": 850, "maturity": 1600}},
    # VEGETABLES
    "tomato": {"cycle_days": 120, "base_temp": 10, "optimal_temp": {"min": 18, "max": 27}, "gdd_requirements": {"emergence": 100, "flowering": 800, "fruit_set": 1000, "maturity": 1400}},
    "pepper": {"cycle_days": 120, "base_temp": 15, "optimal_temp": {"min": 20, "max": 30}, "gdd_requirements": {"emergence": 100, "flowering": 700, "fruit_set": 900, "maturity": 1300}},
    "eggplant": {"cycle_days": 130, "base_temp": 15, "optimal_temp": {"min": 22, "max": 30}, "gdd_requirements": {"emergence": 120, "flowering": 800, "maturity": 1400}},
    "potato": {"cycle_days": 100, "base_temp": 7, "optimal_temp": {"min": 15, "max": 20}, "gdd_requirements": {"emergence": 150, "tuber_initiation": 400, "bulking": 800, "maturity": 1200}},
    "onion": {"cycle_days": 150, "base_temp": 4, "optimal_temp": {"min": 12, "max": 24}, "gdd_requirements": {"emergence": 200, "bulbing": 800, "maturity": 1500}},
    "garlic": {"cycle_days": 180, "base_temp": 0, "optimal_temp": {"min": 12, "max": 22}, "gdd_requirements": {"emergence": 150, "bulbing": 700, "maturity": 1400}},
    "carrot": {"cycle_days": 100, "base_temp": 4, "optimal_temp": {"min": 15, "max": 20}, "gdd_requirements": {"emergence": 150, "root_development": 600, "maturity": 1100}},
    "cabbage": {"cycle_days": 90, "base_temp": 4, "optimal_temp": {"min": 15, "max": 20}, "gdd_requirements": {"emergence": 100, "heading": 500, "maturity": 900}},
    "lettuce": {"cycle_days": 60, "base_temp": 4, "optimal_temp": {"min": 12, "max": 18}, "gdd_requirements": {"emergence": 80, "heading": 400, "maturity": 600}},
    "spinach": {"cycle_days": 50, "base_temp": 2, "optimal_temp": {"min": 10, "max": 18}, "gdd_requirements": {"emergence": 60, "maturity": 500}},
    "cucumber": {"cycle_days": 70, "base_temp": 15, "optimal_temp": {"min": 20, "max": 30}, "gdd_requirements": {"emergence": 80, "flowering": 400, "maturity": 700}},
    "zucchini": {"cycle_days": 60, "base_temp": 15, "optimal_temp": {"min": 20, "max": 28}, "gdd_requirements": {"emergence": 70, "flowering": 350, "maturity": 600}},
    "pumpkin": {"cycle_days": 120, "base_temp": 15, "optimal_temp": {"min": 20, "max": 30}, "gdd_requirements": {"emergence": 100, "flowering": 600, "maturity": 1200}},
    "watermelon": {"cycle_days": 100, "base_temp": 18, "optimal_temp": {"min": 24, "max": 32}, "gdd_requirements": {"emergence": 80, "flowering": 500, "maturity": 1000}},
    "melon": {"cycle_days": 90, "base_temp": 18, "optimal_temp": {"min": 24, "max": 32}, "gdd_requirements": {"emergence": 80, "flowering": 450, "maturity": 900}},
    "beans": {"cycle_days": 90, "base_temp": 10, "optimal_temp": {"min": 18, "max": 25}, "gdd_requirements": {"emergence": 100, "flowering": 500, "maturity": 900}},
    "peas": {"cycle_days": 80, "base_temp": 4, "optimal_temp": {"min": 12, "max": 18}, "gdd_requirements": {"emergence": 100, "flowering": 400, "maturity": 800}},
    # FRUITS
    "olive": {"cycle_days": 365, "base_temp": 10, "optimal_temp": {"min": 15, "max": 25}, "gdd_requirements": {"bud_break": 200, "flowering": 600, "fruit_set": 900, "maturity": 2500}},
    "grape": {"cycle_days": 180, "base_temp": 10, "optimal_temp": {"min": 15, "max": 30}, "gdd_requirements": {"bud_break": 100, "flowering": 500, "veraison": 1200, "harvest": 1800}},
    "apple": {"cycle_days": 180, "base_temp": 7, "optimal_temp": {"min": 15, "max": 25}, "gdd_requirements": {"bud_break": 150, "flowering": 400, "fruit_set": 600, "maturity": 1600}},
    "pear": {"cycle_days": 180, "base_temp": 7, "optimal_temp": {"min": 15, "max": 25}, "gdd_requirements": {"bud_break": 140, "flowering": 380, "maturity": 1500}},
    "peach": {"cycle_days": 150, "base_temp": 7, "optimal_temp": {"min": 18, "max": 28}, "gdd_requirements": {"bud_break": 200, "flowering": 450, "maturity": 1400}},
    "apricot": {"cycle_days": 140, "base_temp": 7, "optimal_temp": {"min": 18, "max": 28}, "gdd_requirements": {"bud_break": 180, "flowering": 400, "maturity": 1300}},
    "cherry": {"cycle_days": 120, "base_temp": 7, "optimal_temp": {"min": 15, "max": 25}, "gdd_requirements": {"bud_break": 200, "flowering": 400, "maturity": 1100}},
    "plum": {"cycle_days": 150, "base_temp": 7, "optimal_temp": {"min": 15, "max": 25}, "gdd_requirements": {"bud_break": 180, "flowering": 420, "maturity": 1400}},
    "fig": {"cycle_days": 180, "base_temp": 10, "optimal_temp": {"min": 20, "max": 32}, "gdd_requirements": {"bud_break": 150, "flowering": 500, "maturity": 1800}},
    "citrus": {"cycle_days": 300, "base_temp": 13, "optimal_temp": {"min": 20, "max": 30}, "gdd_requirements": {"flowering": 300, "fruit_set": 600, "maturity": 2000}},
    "orange": {"cycle_days": 300, "base_temp": 13, "optimal_temp": {"min": 20, "max": 30}, "gdd_requirements": {"flowering": 300, "fruit_set": 600, "maturity": 2000}},
    "lemon": {"cycle_days": 300, "base_temp": 13, "optimal_temp": {"min": 18, "max": 28}, "gdd_requirements": {"flowering": 280, "maturity": 1800}},
    "pomegranate": {"cycle_days": 180, "base_temp": 10, "optimal_temp": {"min": 20, "max": 35}, "gdd_requirements": {"flowering": 400, "fruit_set": 700, "maturity": 1800}},
    "date_palm": {"cycle_days": 200, "base_temp": 18, "optimal_temp": {"min": 25, "max": 40}, "gdd_requirements": {"flowering": 400, "fruit_development": 1500, "ripening": 3000}},
    "banana": {"cycle_days": 365, "base_temp": 14, "optimal_temp": {"min": 22, "max": 32}, "gdd_requirements": {"vegetative": 1000, "flowering": 2500, "maturity": 4000}},
    "avocado": {"cycle_days": 365, "base_temp": 10, "optimal_temp": {"min": 18, "max": 28}, "gdd_requirements": {"flowering": 500, "fruit_set": 1000, "maturity": 2500}},
    "mango": {"cycle_days": 150, "base_temp": 15, "optimal_temp": {"min": 24, "max": 35}, "gdd_requirements": {"flowering": 400, "fruit_set": 800, "maturity": 1500}},
    "strawberry": {"cycle_days": 90, "base_temp": 5, "optimal_temp": {"min": 15, "max": 22}, "gdd_requirements": {"flowering": 300, "fruit_set": 500, "maturity": 900}},
    # LEGUMES
    "soybean": {"cycle_days": 120, "base_temp": 10, "optimal_temp": {"min": 20, "max": 30}, "gdd_requirements": {"emergence": 100, "flowering": 600, "pod_fill": 900, "maturity": 1300}},
    "groundnut": {"cycle_days": 130, "base_temp": 13, "optimal_temp": {"min": 25, "max": 32}, "gdd_requirements": {"emergence": 100, "flowering": 500, "pegging": 800, "maturity": 1300}},
    "peanut": {"cycle_days": 130, "base_temp": 13, "optimal_temp": {"min": 25, "max": 32}, "gdd_requirements": {"emergence": 100, "flowering": 500, "pegging": 800, "maturity": 1300}},
    "chickpea": {"cycle_days": 110, "base_temp": 5, "optimal_temp": {"min": 18, "max": 26}, "gdd_requirements": {"emergence": 120, "flowering": 500, "maturity": 1100}},
    "lentil": {"cycle_days": 100, "base_temp": 5, "optimal_temp": {"min": 15, "max": 25}, "gdd_requirements": {"emergence": 100, "flowering": 450, "maturity": 1000}},
    "faba_bean": {"cycle_days": 150, "base_temp": 0, "optimal_temp": {"min": 12, "max": 22}, "gdd_requirements": {"emergence": 150, "flowering": 600, "maturity": 1400}},
    # OIL CROPS
    "sunflower": {"cycle_days": 110, "base_temp": 8, "optimal_temp": {"min": 20, "max": 28}, "gdd_requirements": {"emergence": 100, "flowering": 700, "maturity": 1200}},
    "rapeseed": {"cycle_days": 180, "base_temp": 0, "optimal_temp": {"min": 12, "max": 22}, "gdd_requirements": {"emergence": 150, "flowering": 700, "maturity": 1600}},
    "canola": {"cycle_days": 180, "base_temp": 0, "optimal_temp": {"min": 12, "max": 22}, "gdd_requirements": {"emergence": 150, "flowering": 700, "maturity": 1600}},
    "sesame": {"cycle_days": 100, "base_temp": 15, "optimal_temp": {"min": 25, "max": 35}, "gdd_requirements": {"emergence": 80, "flowering": 500, "maturity": 1000}},
    "cotton": {"cycle_days": 180, "base_temp": 15, "optimal_temp": {"min": 22, "max": 32}, "gdd_requirements": {"emergence": 100, "squaring": 500, "flowering": 900, "boll_open": 1800}},
    # SUGAR CROPS
    "sugarcane": {"cycle_days": 365, "base_temp": 12, "optimal_temp": {"min": 25, "max": 35}, "gdd_requirements": {"germination": 300, "tillering": 1200, "grand_growth": 3000, "maturity": 5000}},
    "sugar_beet": {"cycle_days": 180, "base_temp": 3, "optimal_temp": {"min": 15, "max": 22}, "gdd_requirements": {"emergence": 150, "canopy": 700, "sugar_accumulation": 1400, "maturity": 2000}},
    # OTHERS
    "tobacco": {"cycle_days": 120, "base_temp": 13, "optimal_temp": {"min": 20, "max": 28}, "gdd_requirements": {"emergence": 100, "topping": 600, "maturity": 1200}},
    "coffee": {"cycle_days": 365, "base_temp": 10, "optimal_temp": {"min": 18, "max": 24}, "gdd_requirements": {"flowering": 400, "fruit_development": 1500, "maturity": 3000}},
    "tea": {"cycle_days": 365, "base_temp": 13, "optimal_temp": {"min": 18, "max": 28}, "gdd_requirements": {"flush": 200, "plucking": 400}},
    "alfalfa": {"cycle_days": 60, "base_temp": 5, "optimal_temp": {"min": 15, "max": 25}, "gdd_requirements": {"emergence": 100, "bud": 350, "flowering": 500}},
    "clover": {"cycle_days": 60, "base_temp": 5, "optimal_temp": {"min": 15, "max": 22}, "gdd_requirements": {"emergence": 100, "flowering": 450}}
}

# FAO Crop Coefficients (Kc) - Comprehensive (FAO-56)
CROP_KC_COEFFICIENTS = {
    # Cereals
    "wheat": {"initial": 0.3, "mid": 1.15, "late": 0.25}, "barley": {"initial": 0.3, "mid": 1.15, "late": 0.25},
    "corn": {"initial": 0.3, "mid": 1.2, "late": 0.6}, "maize": {"initial": 0.3, "mid": 1.2, "late": 0.6},
    "rice": {"initial": 1.05, "mid": 1.2, "late": 0.9}, "sorghum": {"initial": 0.3, "mid": 1.0, "late": 0.55},
    "millet": {"initial": 0.3, "mid": 1.0, "late": 0.3}, "oat": {"initial": 0.3, "mid": 1.15, "late": 0.25},
    "rye": {"initial": 0.3, "mid": 1.15, "late": 0.25},
    # Vegetables
    "tomato": {"initial": 0.6, "mid": 1.15, "late": 0.8}, "pepper": {"initial": 0.6, "mid": 1.05, "late": 0.9},
    "eggplant": {"initial": 0.6, "mid": 1.05, "late": 0.9}, "potato": {"initial": 0.5, "mid": 1.15, "late": 0.75},
    "onion": {"initial": 0.7, "mid": 1.05, "late": 0.75}, "garlic": {"initial": 0.7, "mid": 1.0, "late": 0.7},
    "carrot": {"initial": 0.7, "mid": 1.05, "late": 0.95}, "cabbage": {"initial": 0.7, "mid": 1.05, "late": 0.95},
    "lettuce": {"initial": 0.7, "mid": 1.0, "late": 0.95}, "spinach": {"initial": 0.7, "mid": 1.0, "late": 0.95},
    "cucumber": {"initial": 0.6, "mid": 1.0, "late": 0.75}, "zucchini": {"initial": 0.5, "mid": 0.95, "late": 0.75},
    "pumpkin": {"initial": 0.5, "mid": 1.0, "late": 0.8}, "watermelon": {"initial": 0.4, "mid": 1.0, "late": 0.75},
    "melon": {"initial": 0.5, "mid": 1.05, "late": 0.75}, "beans": {"initial": 0.4, "mid": 1.15, "late": 0.35},
    "peas": {"initial": 0.5, "mid": 1.15, "late": 0.3},
    # Fruits
    "olive": {"initial": 0.65, "mid": 0.7, "late": 0.7}, "grape": {"initial": 0.3, "mid": 0.85, "late": 0.45},
    "apple": {"initial": 0.45, "mid": 0.95, "late": 0.7}, "pear": {"initial": 0.45, "mid": 0.95, "late": 0.7},
    "peach": {"initial": 0.45, "mid": 0.9, "late": 0.65}, "apricot": {"initial": 0.45, "mid": 0.9, "late": 0.65},
    "cherry": {"initial": 0.45, "mid": 0.95, "late": 0.7}, "plum": {"initial": 0.45, "mid": 0.9, "late": 0.65},
    "fig": {"initial": 0.5, "mid": 0.85, "late": 0.75}, "citrus": {"initial": 0.7, "mid": 0.65, "late": 0.7},
    "orange": {"initial": 0.7, "mid": 0.65, "late": 0.7}, "lemon": {"initial": 0.7, "mid": 0.65, "late": 0.7},
    "pomegranate": {"initial": 0.5, "mid": 0.85, "late": 0.6}, "date_palm": {"initial": 0.9, "mid": 0.95, "late": 0.95},
    "banana": {"initial": 0.5, "mid": 1.1, "late": 1.0}, "avocado": {"initial": 0.6, "mid": 0.85, "late": 0.75},
    "mango": {"initial": 0.4, "mid": 0.75, "late": 0.7}, "strawberry": {"initial": 0.4, "mid": 0.85, "late": 0.75},
    # Legumes
    "soybean": {"initial": 0.4, "mid": 1.15, "late": 0.5}, "groundnut": {"initial": 0.4, "mid": 1.15, "late": 0.6},
    "peanut": {"initial": 0.4, "mid": 1.15, "late": 0.6}, "chickpea": {"initial": 0.4, "mid": 1.0, "late": 0.35},
    "lentil": {"initial": 0.4, "mid": 1.1, "late": 0.3}, "faba_bean": {"initial": 0.5, "mid": 1.15, "late": 0.3},
    # Oil crops
    "sunflower": {"initial": 0.35, "mid": 1.1, "late": 0.35}, "rapeseed": {"initial": 0.35, "mid": 1.15, "late": 0.35},
    "canola": {"initial": 0.35, "mid": 1.15, "late": 0.35}, "sesame": {"initial": 0.35, "mid": 1.1, "late": 0.25},
    "cotton": {"initial": 0.35, "mid": 1.2, "late": 0.6},
    # Sugar crops
    "sugarcane": {"initial": 0.4, "mid": 1.25, "late": 0.75}, "sugar_beet": {"initial": 0.35, "mid": 1.2, "late": 0.7},
    # Others
    "tobacco": {"initial": 0.35, "mid": 1.15, "late": 0.85}, "coffee": {"initial": 0.9, "mid": 0.95, "late": 0.95},
    "tea": {"initial": 0.95, "mid": 1.0, "late": 1.0}, "alfalfa": {"initial": 0.4, "mid": 0.95, "late": 0.9},
    "clover": {"initial": 0.4, "mid": 0.9, "late": 0.85}
}


def get_crop_calendar(crop: str) -> Optional[Dict]:
    """
    Get crop calendar with planting/harvest windows and GDD requirements.
    """
    crop_lower = crop.lower()
    if crop_lower in CROP_CALENDARS:
        calendar = CROP_CALENDARS[crop_lower].copy()
        calendar["crop"] = crop_lower
        calendar["source"] = "fao-crop-calendar"
        return calendar
    return None


def get_crop_kc(crop: str, growth_stage: str = None) -> Optional[Dict]:
    """
    Get FAO crop coefficient (Kc) values.
    """
    crop_lower = crop.lower()
    if crop_lower in CROP_KC_COEFFICIENTS:
        kc = CROP_KC_COEFFICIENTS[crop_lower].copy()
        result = {
            "crop": crop_lower,
            "kc_initial": kc["initial"],
            "kc_mid": kc["mid"],
            "kc_late": kc["late"],
            "source": "fao-56"
        }
        if growth_stage:
            stage_lower = growth_stage.lower()
            if "initial" in stage_lower or "emergence" in stage_lower:
                result["current_kc"] = kc["initial"]
            elif "mid" in stage_lower or "flower" in stage_lower or "fruit" in stage_lower:
                result["current_kc"] = kc["mid"]
            else:
                result["current_kc"] = kc["late"]
        return result
    return None


def calculate_gdd(temp_max: float, temp_min: float, base_temp: float = 10) -> float:
    """
    Calculate Growing Degree Days (GDD) using the averaging method.
    GDD = max(0, (Tmax + Tmin) / 2 - Tbase)
    """
    avg_temp = (temp_max + temp_min) / 2
    return max(0, avg_temp - base_temp)


def fetch_gdd_accumulation(lat: float, lng: float, crop: str = "tomato", 
                           days: int = 90) -> Optional[Dict]:
    """
    Calculate cumulative GDD for a location using historical temperature data.
    Uses crop-specific base temperature.
    """
    try:
        # Get crop base temperature
        crop_info = CROP_CALENDARS.get(crop.lower(), {"base_temp": 10})
        base_temp = crop_info.get("base_temp", 10)
        gdd_requirements = crop_info.get("gdd_requirements", {})
        
        # Fetch historical temperature data
        end_date = datetime.now()
        start_date = end_date - timedelta(days=days)
        
        params = {
            "latitude": lat,
            "longitude": lng,
            "start_date": start_date.strftime("%Y-%m-%d"),
            "end_date": end_date.strftime("%Y-%m-%d"),
            "daily": ["temperature_2m_max", "temperature_2m_min"],
            "timezone": "auto"
        }
        
        response = requests.get(OPEN_METEO_ARCHIVE_URL, params=params, timeout=30)
        
        if response.status_code != 200:
            return None
        
        data = response.json()
        daily = data.get("daily", {})
        
        if not daily.get("time"):
            return None
        
        # Calculate cumulative GDD
        gdd_total = 0
        gdd_by_week = []
        weekly_gdd = 0
        week_count = 0
        
        for i, date in enumerate(daily["time"]):
            t_max = daily.get("temperature_2m_max", [None])[i]
            t_min = daily.get("temperature_2m_min", [None])[i]
            
            if t_max is not None and t_min is not None:
                daily_gdd = calculate_gdd(t_max, t_min, base_temp)
                gdd_total += daily_gdd
                weekly_gdd += daily_gdd
                
                if (i + 1) % 7 == 0:
                    gdd_by_week.append({
                        "week": week_count + 1,
                        "gdd": round(weekly_gdd, 1)
                    })
                    weekly_gdd = 0
                    week_count += 1
        
        # Determine current growth stage
        current_stage = "unknown"
        next_stage = None
        gdd_to_next = None
        
        stages = list(gdd_requirements.items())
        for i, (stage, required_gdd) in enumerate(stages):
            if gdd_total < required_gdd:
                if i > 0:
                    current_stage = stages[i-1][0]
                else:
                    current_stage = "pre-emergence"
                next_stage = stage
                gdd_to_next = required_gdd - gdd_total
                break
            current_stage = stage
        
        return {
            "location": {"lat": lat, "lng": lng},
            "crop": crop,
            "base_temp_c": base_temp,
            "period_days": days,
            "gdd_total": round(gdd_total, 1),
            "current_stage": current_stage,
            "next_stage": next_stage,
            "gdd_to_next_stage": round(gdd_to_next, 1) if gdd_to_next else None,
            "gdd_requirements": gdd_requirements,
            "gdd_by_week": gdd_by_week,
            "source": "calculated-from-era5"
        }
        
    except Exception as e:
        print(f"GDD calculation error: {e}")
        return None


def detect_phenology_from_ndvi(ndvi_values: List[float], dates: List[str]) -> Optional[Dict]:
    """
    Detect phenological stages from NDVI time series.
    Identifies: green-up start, peak vegetation, senescence start.
    """
    if not ndvi_values or len(ndvi_values) < 10:
        return None
    
    try:
        # Find key phenological dates
        max_ndvi = max(ndvi_values)
        min_ndvi = min(ndvi_values)
        max_idx = ndvi_values.index(max_ndvi)
        
        # Green-up threshold (30% of max)
        greenup_threshold = min_ndvi + 0.3 * (max_ndvi - min_ndvi)
        # Senescence threshold (70% of max, declining)
        senescence_threshold = min_ndvi + 0.7 * (max_ndvi - min_ndvi)
        
        greenup_date = None
        peak_date = dates[max_idx] if dates else None
        senescence_date = None
        
        # Find green-up (first crossing up)
        for i in range(1, max_idx):
            if ndvi_values[i-1] < greenup_threshold <= ndvi_values[i]:
                greenup_date = dates[i] if dates else None
                break
        
        # Find senescence (first crossing down after peak)
        for i in range(max_idx + 1, len(ndvi_values)):
            if ndvi_values[i-1] >= senescence_threshold > ndvi_values[i]:
                senescence_date = dates[i] if dates else None
                break
        
        # Calculate season length
        season_length = None
        if greenup_date and senescence_date:
            try:
                g_date = datetime.strptime(greenup_date, "%Y-%m-%d")
                s_date = datetime.strptime(senescence_date, "%Y-%m-%d")
                season_length = (s_date - g_date).days
            except:
                pass
        
        return {
            "greenup_date": greenup_date,
            "peak_vegetation_date": peak_date,
            "senescence_date": senescence_date,
            "peak_ndvi": round(max_ndvi, 3),
            "min_ndvi": round(min_ndvi, 3),
            "season_length_days": season_length,
            "source": "ndvi-phenology-detection"
        }
        
    except Exception as e:
        print(f"NDVI phenology detection error: {e}")
        return None


def fetch_comprehensive_phenology(lat: float, lng: float, crop: str = "tomato",
                                   planting_date: str = None) -> Dict:
    """
    Get comprehensive phenology data for a location and crop.
    Combines: GDD accumulation, crop calendar, Kc values, and stage detection.
    """
    results = {
        "location": {"lat": lat, "lng": lng},
        "crop": crop,
        "timestamp": datetime.now().isoformat()
    }
    
    # Crop Calendar
    calendar = get_crop_calendar(crop)
    if calendar:
        results["crop_calendar"] = calendar
    
    # Crop Coefficients
    kc = get_crop_kc(crop)
    if kc:
        results["crop_coefficients"] = kc
    
    # GDD Accumulation
    gdd_data = fetch_gdd_accumulation(lat, lng, crop, days=90)
    if gdd_data:
        results["gdd_accumulation"] = gdd_data
        # Update Kc with current stage
        if "current_stage" in gdd_data and kc:
            kc_updated = get_crop_kc(crop, gdd_data["current_stage"])
            if kc_updated:
                results["crop_coefficients"] = kc_updated
    
    # Add optimal conditions
    crop_info = CROP_CALENDARS.get(crop.lower(), {})
    if crop_info:
        results["optimal_conditions"] = {
            "temp_min": crop_info.get("optimal_temp", {}).get("min"),
            "temp_max": crop_info.get("optimal_temp", {}).get("max"),
            "base_temp": crop_info.get("base_temp")
        }
    
    results["source"] = "agriwise-phenology"
    return results


# ============================================================================
# Long-Term Rainfall History (ERA5 via Open-Meteo)
# ============================================================================

def fetch_rainfall_climatology(lat: float, lng: float) -> Optional[Dict]:
    """
    Fetches 30-year monthly rainfall normals (1991-2020).
    These climate normals provide the baseline for anomaly calculations.
    """
    try:
        # Use 30-year reference period (1991-2020)
        params = {
            "latitude": lat,
            "longitude": lng,
            "start_date": "1991-01-01",
            "end_date": "2020-12-31",
            "daily": ["precipitation_sum"],
            "timezone": "auto"
        }
        
        response = requests.get(OPEN_METEO_ARCHIVE_URL, params=params, timeout=60)
        
        if response.status_code != 200:
            print(f"Climatology API Error: {response.text}")
            return None
        
        data = response.json()
        daily = data.get("daily", {})
        dates = daily.get("time", [])
        precip = daily.get("precipitation_sum", [])
        
        if not dates:
            return None
        
        # Aggregate by month
        monthly_totals = {m: [] for m in range(1, 13)}
        annual_totals = {}
        
        for i, date in enumerate(dates):
            if precip[i] is not None:
                month = int(date[5:7])
                year = int(date[:4])
                monthly_totals[month].append(precip[i])
                
                if year not in annual_totals:
                    annual_totals[year] = 0
                annual_totals[year] += precip[i]
        
        # Calculate monthly means
        monthly_means = {}
        month_names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", 
                       "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
        
        for month in range(1, 13):
            values = monthly_totals[month]
            if values:
                # Sum of all daily rainfall for this month across 30 years
                total_mass = sum(values)
                # Divide by 30 years to get average monthly total
                monthly_means[month_names[month-1]] = round(total_mass / 30, 1)
            else:
                monthly_means[month_names[month-1]] = 0
        
        # Calculate annual mean
        annual_values = list(annual_totals.values())
        annual_mean = sum(annual_values) / len(annual_values) if annual_values else 0
        
        return {
            "location": {"lat": lat, "lng": lng},
            "reference_period": "1991-2020",
            "monthly_normals_mm": monthly_means,
            "annual_normal_mm": round(annual_mean, 1),
            "total_years": len(annual_values),
            "source": "era5-open-meteo-climatology"
        }
        
    except Exception as e:
        print(f"Rainfall climatology error: {e}")
        return None


def fetch_rainfall_history(lat: float, lng: float, years: int = 30) -> Optional[Dict]:
    """
    Fetches annual rainfall totals for the past N years.
    Identifies wet years, dry years, and trends.
    """
    try:
        end_year = datetime.now().year - 1  # Complete years only
        start_year = end_year - years + 1
        
        params = {
            "latitude": lat,
            "longitude": lng,
            "start_date": f"{start_year}-01-01",
            "end_date": f"{end_year}-12-31",
            "daily": ["precipitation_sum"],
            "timezone": "auto"
        }
        
        response = requests.get(OPEN_METEO_ARCHIVE_URL, params=params, timeout=60)
        
        if response.status_code != 200:
            print(f"Rainfall history API Error: {response.text}")
            return None
        
        data = response.json()
        daily = data.get("daily", {})
        dates = daily.get("time", [])
        precip = daily.get("precipitation_sum", [])
        
        if not dates:
            return None
        
        # Aggregate by year
        annual_totals = {}
        for i, date in enumerate(dates):
            if precip[i] is not None:
                year = int(date[:4])
                if year not in annual_totals:
                    annual_totals[year] = 0
                annual_totals[year] += precip[i]
        
        # Calculate statistics
        years_list = sorted(annual_totals.keys())
        values = [annual_totals[y] for y in years_list]
        mean_rainfall = sum(values) / len(values) if values else 0
        
        # Build annual records with classification
        annual_records = []
        for year in years_list:
            total = annual_totals[year]
            pct_of_mean = (total / mean_rainfall * 100) if mean_rainfall > 0 else 100
            
            if pct_of_mean < 75:
                classification = "drought"
            elif pct_of_mean < 90:
                classification = "dry"
            elif pct_of_mean <= 110:
                classification = "normal"
            elif pct_of_mean <= 125:
                classification = "wet"
            else:
                classification = "very_wet"
            
            annual_records.append({
                "year": year,
                "total_mm": round(total, 1),
                "pct_of_mean": round(pct_of_mean, 1),
                "classification": classification
            })
        
        # Calculate trend (simple linear regression slope)
        if len(values) >= 5:
            n = len(values)
            x_mean = sum(range(n)) / n
            y_mean = mean_rainfall
            
            numerator = sum((i - x_mean) * (values[i] - y_mean) for i in range(n))
            denominator = sum((i - x_mean) ** 2 for i in range(n))
            
            slope = numerator / denominator if denominator != 0 else 0
            trend = "increasing" if slope > 1 else "decreasing" if slope < -1 else "stable"
            trend_mm_per_year = round(slope, 2)
        else:
            trend = "insufficient_data"
            trend_mm_per_year = 0
        
        return {
            "location": {"lat": lat, "lng": lng},
            "period": {"start": start_year, "end": end_year},
            "mean_annual_mm": round(mean_rainfall, 1),
            "min_year": {"year": years_list[values.index(min(values))], "mm": round(min(values), 1)},
            "max_year": {"year": years_list[values.index(max(values))], "mm": round(max(values), 1)},
            "trend": trend,
            "trend_mm_per_year": trend_mm_per_year,
            "annual_records": annual_records,
            "source": "era5-open-meteo-history"
        }
        
    except Exception as e:
        print(f"Rainfall history error: {e}")
        return None


def calculate_drought_frequency(lat: float, lng: float, years: int = 30) -> Optional[Dict]:
    """
    Calculates drought frequency and risk based on historical rainfall.
    Drought year = annual rainfall < 75% of long-term mean.
    """
    try:
        history = fetch_rainfall_history(lat, lng, years)
        if not history:
            return None
        
        records = history.get("annual_records", [])
        mean = history.get("mean_annual_mm", 0)
        
        # Count drought years
        drought_years = [r for r in records if r["classification"] == "drought"]
        dry_years = [r for r in records if r["classification"] == "dry"]
        
        drought_count = len(drought_years)
        dry_count = len(dry_years)
        total_years = len(records)
        
        # Calculate drought frequency
        drought_frequency = drought_count / total_years if total_years > 0 else 0
        
        # Determine risk level
        if drought_frequency >= 0.3:
            risk_level = "high"
            risk_score = min(100, int(drought_frequency * 200))
        elif drought_frequency >= 0.15:
            risk_level = "moderate"
            risk_score = int(drought_frequency * 150)
        else:
            risk_level = "low"
            risk_score = int(drought_frequency * 100)
        
        # Recent drought pattern (last 10 years)
        recent_records = [r for r in records if r["year"] >= datetime.now().year - 10]
        recent_droughts = len([r for r in recent_records if r["classification"] == "drought"])
        recent_dry = len([r for r in recent_records if r["classification"] == "dry"])
        
        return {
            "location": {"lat": lat, "lng": lng},
            "analysis_period": {"start": records[0]["year"] if records else None, 
                               "end": records[-1]["year"] if records else None},
            "total_years_analyzed": total_years,
            "drought_years_count": drought_count,
            "dry_years_count": dry_count,
            "drought_frequency": round(drought_frequency * 100, 1),  # as percentage
            "drought_return_period": round(1/drought_frequency, 1) if drought_frequency > 0 else None,
            "risk_level": risk_level,
            "risk_score": risk_score,
            "recent_10_years": {
                "drought_count": recent_droughts,
                "dry_count": recent_dry
            },
            "drought_years_list": [d["year"] for d in drought_years],
            "source": "era5-drought-analysis"
        }
        
    except Exception as e:
        print(f"Drought frequency error: {e}")
        return None


def get_current_rainfall_anomaly(lat: float, lng: float) -> Optional[Dict]:
    """
    Compares current year's rainfall to 30-year baseline.
    Returns anomaly percentage and status.
    """
    try:
        # Get climatology (30-year normals)
        climatology = fetch_rainfall_climatology(lat, lng)
        if not climatology:
            return None
        
        monthly_normals = climatology.get("monthly_normals_mm", {})
        annual_normal = climatology.get("annual_normal_mm", 0)
        
        # Get current year rainfall (up to yesterday)
        current_year = datetime.now().year
        current_month = datetime.now().month
        yesterday = (datetime.now() - timedelta(days=1)).strftime("%Y-%m-%d")
        
        params = {
            "latitude": lat,
            "longitude": lng,
            "start_date": f"{current_year}-01-01",
            "end_date": yesterday,
            "daily": ["precipitation_sum"],
            "timezone": "auto"
        }
        
        response = requests.get(OPEN_METEO_ARCHIVE_URL, params=params, timeout=30)
        
        if response.status_code != 200:
            print(f"Current rainfall API Error: {response.text}")
            return None
        
        data = response.json()
        daily = data.get("daily", {})
        dates = daily.get("time", [])
        precip = daily.get("precipitation_sum", [])
        
        if not dates:
            return None
        
        # Calculate YTD rainfall
        ytd_rainfall = sum(p for p in precip if p is not None)
        
        # Calculate expected rainfall up to current month
        month_names = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", 
                       "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"]
        expected_ytd = sum(monthly_normals.get(month_names[m], 0) for m in range(current_month))
        
        # Calculate anomaly
        if expected_ytd > 0:
            anomaly_pct = ((ytd_rainfall - expected_ytd) / expected_ytd) * 100
        else:
            anomaly_pct = 0
        
        # Determine status
        if anomaly_pct <= -30:
            status = "severe_deficit"
            status_ar = "نقص حاد"
        elif anomaly_pct <= -15:
            status = "moderate_deficit"
            status_ar = "نقص معتدل"
        elif anomaly_pct <= 15:
            status = "normal"
            status_ar = "طبيعي"
        elif anomaly_pct <= 30:
            status = "above_normal"
            status_ar = "فوق الطبيعي"
        else:
            status = "excess"
            status_ar = "فائض"
        
        return {
            "location": {"lat": lat, "lng": lng},
            "year": current_year,
            "days_elapsed": len(dates),
            "ytd_rainfall_mm": round(ytd_rainfall, 1),
            "expected_ytd_mm": round(expected_ytd, 1),
            "anomaly_mm": round(ytd_rainfall - expected_ytd, 1),
            "anomaly_pct": round(anomaly_pct, 1),
            "status": status,
            "status_ar": status_ar,
            "annual_normal_mm": annual_normal,
            "projected_annual_mm": round(ytd_rainfall * (12 / current_month), 1) if current_month > 0 else 0,
            "source": "era5-rainfall-anomaly"
        }
        
    except Exception as e:
        print(f"Rainfall anomaly error: {e}")
        return None


# ============================================================================
# Evapotranspiration & Water Stress Analysis (FAO-56)
# ============================================================================

def fetch_water_balance(lat: float, lng: float, days_past: int = 30, days_future: int = 7) -> Optional[Dict]:
    """
    Fetches daily Reference Evapotranspiration (ET0) and Precipitation
    for the past X days and future Y days to calculate Water Balance.
    
    Data Source: Open-Meteo (Archive for past, Forecast for future).
    """
    try:
        today = datetime.now().date()
        start_date = today - timedelta(days=days_past)
        end_date = today - timedelta(days=1) # Yesterday
        
        # 1. Fetch Historical Data (Archive)
        history_params = {
            "latitude": lat,
            "longitude": lng,
            "start_date": start_date.strftime("%Y-%m-%d"),
            "end_date": end_date.strftime("%Y-%m-%d"),
            "daily": ["et0_fao_evapotranspiration", "precipitation_sum"],
            "timezone": "auto"
        }
        
        hist_res = requests.get(OPEN_METEO_ARCHIVE_URL, params=history_params, timeout=15)
        hist_data = hist_res.json() if hist_res.status_code == 200 else {}
        
        # 2. Fetch Forecast Data (Current)
        forecast_params = {
            "latitude": lat,
            "longitude": lng,
            "daily": ["et0_fao_evapotranspiration", "precipitation_sum"],
            "forecast_days": days_future + 1, # Include today
            "timezone": "auto"
        }
        
        fore_res = requests.get(OPEN_METEO_CURRENT_URL, params=forecast_params, timeout=15)
        fore_data = fore_res.json() if fore_res.status_code == 200 else {}
        
        # 3. Merge Datasets
        combined_records = []
        cumulative_deficit = 0
        
        # Process History
        if "daily" in hist_data and "time" in hist_data["daily"]:
            daily = hist_data["daily"]
            for i, date_str in enumerate(daily["time"]):
                et0 = daily["et0_fao_evapotranspiration"][i] or 0
                precip = daily["precipitation_sum"][i] or 0
                balance = precip - et0
                cumulative_deficit += balance
                
                combined_records.append({
                    "date": date_str,
                    "type": "historical",
                    "et0": round(et0, 2),
                    "precip": round(precip, 2),
                    "balance": round(balance, 2),
                    "cumulative_deficit": round(cumulative_deficit, 2)
                })
        
        # Process Forecast (starting from today)
        if "daily" in fore_data and "time" in fore_data["daily"]:
            daily = fore_data["daily"]
            for i, date_str in enumerate(daily["time"]):
                # Skip if date matches last history date (overlap check)
                if combined_records and combined_records[-1]["date"] == date_str:
                    continue
                    
                et0 = daily["et0_fao_evapotranspiration"][i] or 0
                precip = daily["precipitation_sum"][i] or 0
                balance = precip - et0
                cumulative_deficit += balance
                
                combined_records.append({
                    "date": date_str,
                    "type": "forecast",
                    "et0": round(et0, 2),
                    "precip": round(precip, 2),
                    "balance": round(balance, 2),
                    "cumulative_deficit": round(cumulative_deficit, 2)
                })
                
        return {
            "location": {"lat": lat, "lng": lng},
            "records": combined_records,
            "summary": {
                "total_precip_mm": round(sum(r["precip"] for r in combined_records), 2),
                "total_et0_mm": round(sum(r["et0"] for r in combined_records), 2),
                "final_deficit_mm": round(cumulative_deficit, 2),
                "stress_index": max(0, min(100, abs(min(0, cumulative_deficit)) * 0.5)) # Simple normalized index 0-100
            },
            "source": "open-meteo-fao56"
        }

    except Exception as e:
        print(f"fetch_water_balance error: {e}")
        import traceback
        traceback.print_exc()

# ============================================================================
# Land Cover & Crop Context (Sentinel-2 SCL)
# ============================================================================

def fetch_land_cover(lat: float, lng: float) -> Optional[Dict]:
    """
    Fetches Land Cover classification from Sentinel-2 L2A Scene Classification Layer (SCL).
    Uses raw TIFF parsing to avoid external dependencies (PIL) and handling Deflate compression.
    """
    try:
        import struct
        import zlib
        
        token = get_access_token()
        
        # Sentinel-2 L2A SCL Collection
        # We use a small window around the point (10m resolution approx 0.0001 deg)
        # Sentinel-2 L2A SCL Collection
        # We use a small window around the point (10m resolution approx 0.0001 deg)
        bbox = [lng - 0.0001, lat - 0.0001, lng + 0.0001, lat + 0.0001]
        
        # Evalscript for Statistics API
        evalscript = """
        //VERSION=3
        function setup() {
            return {
                input: [{
                    bands: ["SCL", "dataMask"]
                }],
                output: [
                    { id: "default", bands: 1, sampleType: "UINT8" },
                    { id: "dataMask", bands: 1, sampleType: "UINT8" }
                ]
            };
        }
        function evaluatePixel(sample) {
            return {
                default: [sample.SCL],
                dataMask: [sample.dataMask]
            };
        }
        """

        # Payload for Statistics API with Histogram request
        payload = {
            "input": {
                "bounds": {
                    "bbox": bbox,
                     "properties": { "crs": "http://www.opengis.net/def/crs/EPSG/0/4326" }
                },
                "data": [{
                    "type": "sentinel-2-l2a",
                    "dataFilter": { "maxCloudCoverage": 20 }
                }]
            },
            "aggregation": {
                "timeRange": {
                    "from": (datetime.now(timezone.utc) - timedelta(days=30)).strftime("%Y-%m-%dT%H:%M:%SZ"),
                    "to": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
                },
                "aggregationInterval": { "of": "P30D" },
                "evalscript": evalscript
            },
            "calculations": {
                "default": {
                    "histograms": {
                        "default": {
                            "nBins": 12,
                            "lowEdge": 0,
                            "highEdge": 12
                        }
                    }
                }
            }
        }
        
        response = requests.post(
            f"{SENTINEL_HUB_URL}/api/v1/statistics",
            headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json", "Accept": "*/*"},
            json=payload,
            timeout=30
        )
        
        # print(f"[Sentinel] Land Cover Response: {response.status_code}")
        
        if response.status_code != 200:
            print(f"[Sentinel] Land Cover SCL Error ({response.status_code}): {response.text}")
            return None
            
        # Valid SCL Map
        scl_map = {
            0: {"label": "No Data", "color": "#000000", "is_crop": False},
            1: {"label": "Saturated", "color": "#ff0000", "is_crop": False},
            2: {"label": "Dark Area", "color": "#2f2f2f", "is_crop": False},
            3: {"label": "Cloud Shadow", "color": "#643200", "is_crop": False},
            4: {"label": "Vegetation", "color": "#00a000", "is_crop": True},
            5: {"label": "Not Vegetated", "color": "#ffe65a", "is_crop": False},
            6: {"label": "Water", "color": "#0064c8", "is_crop": False},
            7: {"label": "Unclassified", "color": "#787878", "is_crop": False},
            8: {"label": "Cloud (Medium)", "color": "#c8c8c8", "is_crop": False},
            9: {"label": "Cloud (High)", "color": "#ffffff", "is_crop": False},
            10: {"label": "Thin Cirrus", "color": "#c8c8c8", "is_crop": False},
            11: {"label": "Snow", "color": "#f0f0f0", "is_crop": False},
        }

        # Parse response from Statistical API
        try:
            data = response.json()
            val = 4 # Fallback
            total_pixels = 0
            
            if "data" in data and len(data["data"]) > 0:
                 outputs = data["data"][0]["outputs"]["default"]["bands"]
                 
                 # Dynamic key lookup to be safe (usually "default" or "0")
                 band_key = "default"
                 if "default" not in outputs:
                     if "0" in outputs: band_key = "0"
                     else: band_key = list(outputs.keys())[0] # Take first available
                 
                 # Get histogram (bins)
                 histogram = outputs[band_key].get("histogram", {}).get("bins", [])
                 
                 # Find dominant class (mode)
                 max_count = 0
                 dominant_class = 4 # Default to vegetation if unsure
                 
                 for i, bin_data in enumerate(histogram):
                     count = bin_data.get("count", 0)
                     total_pixels += count
                     
                     # Ignore No Data (0) and Saturated (1) if possible
                     if i in [0, 1] and count > 0:
                         continue
                         
                     if count > max_count:
                         max_count = count
                         dominant_class = i
                 
                 val = dominant_class
                 
                 # --- VEGETATION DENSITY & DESERT SAFETY NET ---
                 # Always fetch Max NDVI (90 days) to provide density context.
                 try:
                     ndvi_max = fetch_ndvi_max(lat, lng, days=90)
                     
                     # Calibrated Scale for Desert/Orchards: 
                     # 0.05 (Sand) -> 0%
                     # 0.50 (Dense Forest) -> 100%
                     # 0.38 (Orchard) -> ~73%
                     density_val = max(0.0, min(1.0, (ndvi_max - 0.05) / 0.45))
                     vegetation_density = round(density_val, 2)
                     
                     # Override Logic: If SCL=5 (Not Vegetated) but Density > 20% (NDVI > ~0.14)
                     # We used 0.25 (44%) before, let's stick to 0.20 (33%) as a safe threshold
                     if val == 5 and ndvi_max > 0.20:
                         print(f"[Sentinel] Land Cover Fallback: OVERRIDE -> Vegetation (4) | NDVI={ndvi_max:.2f}")
                         val = 4
                         val_override = True
                         
                 except Exception as e:
                     print(f"NDVI Density check failed: {e}")
                     vegetation_density = 0.0

            else:
                print(f"[Sentinel] No data in statistical response for SCL. Using Fallback.")
                val = 4 # Fallback to Vegetation
                val_override = True


        except Exception as e:
            print(f"Error parsing SCL response: {e}, Data: {response.text[:100]}")
            val = 4 # Fallback
            
        # Clamp value to 0-11
        if val < 0 or val > 11: 
            val = 7 # Unclassified

        cls_data = scl_map.get(val, {"label": f"Unknown ({val})", "color": "#000000", "is_crop": False})
        
        source_label = "sentinel-2-l2a-scl-dominant"
        if 'val_override' in locals() and val_override:
            source_label += "-ndvi-override"

        response_data = {
            "location": {"lat": lat, "lng": lng},
            "class_value": val,
            "label": cls_data["label"],
            "color": cls_data["color"],
            "is_potentially_crop": cls_data["is_crop"],
            "source": source_label
        }
        
        if 'vegetation_density' in locals():
            response_data["vegetation_density"] = vegetation_density
            
        return response_data

    except Exception as e:
        print(f"Land cover (SCL) fetch error: {e}")
        import traceback
        traceback.print_exc()
        return None

def fetch_ndvi_max(lat: float, lng: float, days: int = 90) -> float:
    """
    Fetches the Maximum NDVI for a location over a given period.
    Used as a fallback validation for Sentinel-2 SCL classification.
    """
    try:
        token = get_access_token()
        bbox = [lng - 0.0001, lat - 0.0001, lng + 0.0001, lat + 0.0001]
        
        evalscript = """
        //VERSION=3
        function setup() {
            return {
                input: [{
                    bands: ["B04", "B08", "dataMask"]
                }],
                output: [
                    { id: "default", bands: 1 },
                    { id: "dataMask", bands: 1, sampleType: "UINT8" }
                ]
            };
        }
        function evaluatePixel(sample) {
            let ndvi = (sample.B08 - sample.B04) / (sample.B08 + sample.B04);
            return {
                default: [ndvi],
                dataMask: [sample.dataMask]
            };
        }
        """

        payload = {
            "input": {
                "bounds": {
                    "bbox": bbox,
                     "properties": { "crs": "http://www.opengis.net/def/crs/EPSG/0/4326" }
                },
                "data": [{
                    "type": "sentinel-2-l2a",
                    "dataFilter": { "maxCloudCoverage": 20 }
                }]
            },
            "aggregation": {
                "timeRange": {
                    "from": (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%dT%H:%M:%SZ"),
                    "to": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
                },
                "aggregationInterval": { "of": f"P{days}D" },
                "evalscript": evalscript
            },
            "calculations": {
                "default": {
                    "statistics": {
                        "default": {
                             "max": True
                        }
                    }
                }
            }
        }
        
        response = requests.post(
            f"{SENTINEL_HUB_URL}/api/v1/statistics",
            headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json", "Accept": "*/*"},
            json=payload,
            timeout=30
        )
        
        if response.status_code == 200:
            data = response.json()
            if "data" in data and len(data["data"]) > 0:
                 outputs = data["data"][0]["outputs"]["default"]["bands"]
                 # Band key can be "0" or "B0" depending on version/config
                 band_key = list(outputs.keys())[0] 
                 stats = outputs[band_key].get("stats", {})
                 return stats.get("max", 0.0)
        return 0.0
    except Exception as e:
        print(f"NDVI Max fetch error: {e}")
        return 0.0

def fetch_soil_properties(lat: float, lng: float) -> Dict[str, Any]:
    """
    Fetches base soil properties from ISRIC SoilGrids REST API.
    Provides fallback static data if the parcel lacks uploaded soil tests.
    """
    url = f"https://rest.isric.org/soilgrids/v2.0/properties/query?lon={lng}&lat={lat}&property=clay&property=sand&property=soc&property=phh2o&depth=0-5cm&value=mean"
    try:
        resp = requests.get(url, headers={"Accept": "application/json"}, timeout=10)
        if resp.status_code != 200:
            return {}
        
        data = resp.json()
        layers = data.get("properties", {}).get("layers", [])
        
        parsed = {}
        for layer in layers:
            name = layer.get("name")
            unit = layer.get("unit_measure", {})
            d_factor = unit.get("d_factor", 10)
            
            # Extract mean from first depth (0-5cm)
            depths = layer.get("depths", [])
            if not depths:
                continue
            
            mean_val = depths[0].get("values", {}).get("mean")
            if mean_val is None:
                continue
                
            # Scale by d_factor
            scaled_val = mean_val / float(d_factor)
            
            if name == "clay":
                parsed["clay"] = scaled_val 
            elif name == "sand":
                parsed["sand"] = scaled_val
            elif name == "phh2o":
                parsed["ph"] = scaled_val
            elif name == "soc":
                parsed["organic_carbon"] = scaled_val

        if not parsed:
            return {}
            
        # Basic texture classification
        clay = parsed.get("clay", 0)
        sand = parsed.get("sand", 0)
        silt = 100 - (clay + sand)
        
        texture = "loam"
        if clay >= 40:
            texture = "clay"
        elif sand >= 70:
            texture = "sand"
        elif silt >= 40 and clay < 27 and sand < 50:
            texture = "silt"
            
        parsed["texture_class"] = texture
        return parsed
        
    except Exception as e:
        print(f"⚠️ [SoilGrids] Failed to fetch: {e}")
        return {}

