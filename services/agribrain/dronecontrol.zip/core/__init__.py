# Core orchestration module
