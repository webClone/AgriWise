
import unittest
from datetime import datetime, timedelta
from typing import List

from services.agribrain.layer1_fusion.schema import FieldTensor, FieldTensorChannels
from services.agribrain.layer2_veg_int.schema import VegIntOutput, VegetationAnomaly, AnomalyType, SpatialMetrics, PhenologyOutput, ModeledCurveOutput, CurveQuality
from services.agribrain.layer3_decision.schema import PlotContext, Driver, DegradationMode
from services.agribrain.layer3_decision.runner import run_layer3_decision
from services.agribrain.layer3_decision.knowledge.ontology import ProblemType
from services.agribrain.orchestrator_v2.schema import OrchestratorInput

class TestLayer3ResearchGrade(unittest.TestCase):

    def setUp(self):
        self.dates = [(datetime(2025, 6, 1) + timedelta(days=i)).strftime("%Y-%m-%d") for i in range(30)]
        self.inputs = OrchestratorInput(
            plot_id="P1", geometry_hash="GEO123",
            date_range={"start": self.dates[0], "end": self.dates[-1]},
            crop_config={"crop": "Corn", "planting_date": "2025-05-01"},
            operational_context={"irrigation_type": "pivot", "constraints": {"water_quota_mm": 500}},
            policy_snapshot={},
        )

    def _make_mocks(self, rain_series, sar_vv_series, anomalies, tmax_series=None):
        ft_store = []
        for i in range(30):
            ft_store.append({
                "date": self.dates[i],
                FieldTensorChannels.PRECIPITATION.value: rain_series[i] if i < len(rain_series) else 0.0,
                FieldTensorChannels.VV.value: sar_vv_series[i] if i < len(sar_vv_series) else -12.0,
                FieldTensorChannels.TEMP_MAX.value: tmax_series[i] if tmax_series and i < len(tmax_series) else 30.0,
                FieldTensorChannels.TEMP_MIN.value: 10.0,
                FieldTensorChannels.NDVI.value: 0.7,
            })
        ft = FieldTensor(plot_id="plot_1", run_id="L1_TEST")
        ft.time_index = self.dates
        ft.channels = [
            FieldTensorChannels.NDVI.value,
            FieldTensorChannels.PRECIPITATION.value,
            FieldTensorChannels.VV.value,
            FieldTensorChannels.TEMP_MAX.value,
            FieldTensorChannels.TEMP_MIN.value,
        ]
        ft.plot_timeseries = ft_store

        curve_out = ModeledCurveOutput(
            ndvi_fit=[0.5]*30, ndvi_fit_d1=[0.01]*30,
            quality=CurveQuality(0.05, 0.0, 1.0), ndvi_fit_unc=[0.05]*30,
        )
        pheno_out = PhenologyOutput(
            stage_by_day=["VEGETATIVE"]*30, confidence_by_day=[0.9]*30, key_dates={},
        )
        v_out = VegIntOutput(
            run_id="L2_TEST", layer1_run_id="L1_TEST",
            curve=curve_out, phenology=pheno_out,
            anomalies=anomalies, stability=SpatialMetrics(0.0, 0.0, "STABLE", 1.0),
            provenance={},
        )
        return ft, v_out

    def test_probability_confidence_split(self):
        print("\n🧪 Test: Probability vs Confidence Separation")
        anom = VegetationAnomaly(
            anomaly_id="a1", type=AnomalyType.STALL,
            date_range=[self.dates[10], self.dates[20]],
            severity=0.8, confidence=0.8, description="Stall",
            likely_cause="LIKELY_WATER_STRESS",
        )
        ft, veg = self._make_mocks([0.0]*30, [-12.0]*30, [anom])
        # Remove Rain data to tank confidence
        for r in ft.plot_timeseries:
            r[FieldTensorChannels.PRECIPITATION.value] = None
        decision = run_layer3_decision(self.inputs, ft, veg)
        water_diag = next((d for d in decision.diagnoses if d.problem_id == ProblemType.WATER_STRESS.value), None)
        self.assertIsNotNone(water_diag)
        self.assertGreater(water_diag.probability, 0.6)
        print(f"   -> Water stress prob={water_diag.probability:.2f}, conf={water_diag.confidence:.2f}")

    def test_compliance_fallback(self):
        print("\n🧪 Test: Compliance Gate & Fallback")
        anom = VegetationAnomaly(
            anomaly_id="a1", type=AnomalyType.STALL,
            date_range=[self.dates[20], self.dates[29]],
            severity=0.8, confidence=0.9, description="Stall",
            likely_cause="LIKELY_WATER_STRESS",
        )
        ft, veg = self._make_mocks([0.0]*30, [-12.0]*30, [anom])
        # NO water quota
        restricted_inputs = OrchestratorInput(
            plot_id="P1", geometry_hash="GEO123",
            date_range={"start": self.dates[0], "end": self.dates[-1]},
            crop_config={"crop": "Corn"},
            operational_context={"irrigation_type": "pivot", "constraints": {"water_quota_mm": 0.0}},
            policy_snapshot={},
        )
        decision = run_layer3_decision(restricted_inputs, ft, veg)
        self.assertTrue(len(decision.recommendations) >= 0)
        print(f"   -> Recommendations: {len(decision.recommendations)}")

    def test_harvest_event_detection(self):
        print("\n🧪 Test: Harvest Event Detection")
        sar = [-12.0]*26 + [-8.0, -14.0, -9.0, -13.0]
        anom = VegetationAnomaly(
            anomaly_id="a2", type=AnomalyType.DROP,
            date_range=[self.dates[25], self.dates[29]],
            severity=0.9, confidence=0.9, description="Harvest Drop",
            likely_cause="POSSIBLE_HARVEST",
        )
        ft, veg = self._make_mocks([0.0]*30, sar, [anom])
        veg.phenology.stage_by_day = ["SENESCENCE"]*30
        decision = run_layer3_decision(self.inputs, ft, veg)
        self.assertTrue(len(decision.diagnoses) > 0)
        print(f"   -> Diagnoses: {[d.problem_id for d in decision.diagnoses]}")

    def test_data_gap_scenario(self):
        print("\n🧪 Test: Data Gap handling")
        ft, veg = self._make_mocks([], [], [])
        for r in ft.plot_timeseries:
            r[FieldTensorChannels.PRECIPITATION.value] = None
            r[FieldTensorChannels.VV.value] = None
        decision = run_layer3_decision(self.inputs, ft, veg)
        print(f"   -> Missing Drivers: {decision.quality_metrics.missing_drivers}")
        self.assertIsNotNone(decision)

    def test_compliance_scenario(self):
        print("\n🧪 Test: Compliance & Constraints")
        anom = VegetationAnomaly(
            anomaly_id="a4", type=AnomalyType.STALL,
            date_range=[self.dates[20], self.dates[29]],
            severity=0.8, confidence=0.8, description="Stall",
        )
        ft, veg = self._make_mocks([0.0]*30, [-12.0]*30, [anom])
        restricted_inputs = OrchestratorInput(
            plot_id="P1", geometry_hash="GEO123",
            date_range={"start": self.dates[0], "end": self.dates[-1]},
            crop_config={"crop": "Corn"},
            operational_context={"irrigation_type": "pivot", "constraints": {"water_quota_mm": 10.0}},
            policy_snapshot={},
        )
        decision = run_layer3_decision(restricted_inputs, ft, veg)
        self.assertTrue(len(decision.recommendations) >= 0)
        print(f"   -> Recommendations: {len(decision.recommendations)}")

    def test_execution_plan_dag(self):
        print("\n🧪 Test: Execution Plan DAG")
        anom = VegetationAnomaly(
            anomaly_id="a1", type=AnomalyType.STALL,
            date_range=[self.dates[20], self.dates[29]],
            severity=0.8, confidence=0.9, description="Stall",
        )
        ft, veg = self._make_mocks([0.0]*30, [-12.0]*30, [anom])
        decision = run_layer3_decision(self.inputs, ft, veg)
        plan = decision.execution_plan
        self.assertIsNotNone(plan)
        self.assertGreater(len(plan.tasks), 0)
        print(f"   -> Plan Tasks: {[t.task_id for t in plan.tasks]}")

    def test_sar_missing_degradation(self):
        print("\n🧪 Test: SAR Missing Degradation Mode")
        ft, veg = self._make_mocks([0.0]*30, [], [])
        for r in ft.plot_timeseries:
            r[FieldTensorChannels.VV.value] = None
        decision = run_layer3_decision(self.inputs, ft, veg)
        metrics = decision.quality_metrics
        self.assertIn(metrics.degradation_mode, [DegradationMode.NO_SAR, DegradationMode.DATA_GAP])
        print(f"   -> Degradation Mode: {metrics.degradation_mode}")

if __name__ == "__main__":
    unittest.main()
