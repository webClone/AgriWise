
import unittest
from datetime import datetime, timedelta
from services.agribrain.layer1_fusion.schema import FieldTensor
from services.agribrain.layer2_veg_int.schema import VegIntOutput, VegetationAnomaly, AnomalyType, SpatialMetrics, PhenologyOutput, GrowthMetrics, ModeledCurveOutput, CurveQuality
from services.agribrain.layer3_decision.schema import PlotContext
from services.agribrain.layer3_decision.runner import run_layer3_decision
from services.agribrain.layer3_decision.knowledge.ontology import ProblemType
from services.agribrain.orchestrator_v2.schema import OrchestratorInput


class TestLayer3Decision(unittest.TestCase):

    def setUp(self):
        self.base_date = datetime(2025, 6, 1)
        self.dates = [(self.base_date + timedelta(days=i)).strftime("%Y-%m-%d") for i in range(30)]
        self.inputs = OrchestratorInput(
            plot_id="P1", geometry_hash="GEO123",
            date_range={"start": self.dates[0], "end": self.dates[-1]},
            crop_config={"crop": "wheat", "planting_date": "2025-05-01"},
            operational_context={"irrigation_type": "rainfed"},
            policy_snapshot={},
        )

    def _make_mocks(self, rain_series, sar_vv_series, anomalies):
        # 1. Field Tensor
        ft = FieldTensor(plot_id="plot_1", run_id="L1_123")
        ft.time_index = self.dates
        ft.channels = ["ndvi", "precipitation", "vv", "temp_max", "temp_min"]
        ft_store = []
        for i in range(30):
            ft_store.append({
                "date": self.dates[i],
                "rain": rain_series[i] if i < len(rain_series) else 0.0,
                "vv": sar_vv_series[i] if i < len(sar_vv_series) else -12.0,
                "tmax": 30.0,
                "tmin": 10.0,
                "ndvi_smoothed": 0.5,
            })
        ft.daily_state = {
            "precipitation": [d["rain"] for d in ft_store],
            "vv": [d["vv"] for d in ft_store],
            "temp_max": [d["tmax"] for d in ft_store],
            "temp_min": [d["tmin"] for d in ft_store],
            "ndvi": [0.5] * 30,
        }
        ft.plot_timeseries = ft_store

        # 2. VegInt Output
        curve_out = ModeledCurveOutput(
            ndvi_fit=[0.5]*30, ndvi_fit_d1=[0.01]*30,
            quality=CurveQuality(0.05, 0.0, 1.0), ndvi_fit_unc=[0.05]*30,
        )
        pheno_out = PhenologyOutput(
            stage_by_day=["VEGETATIVE"]*30, key_dates={},
            confidence_by_day=[0.9]*30,
        )
        v_out = VegIntOutput(
            run_id="L2_123", layer1_run_id="L1_123",
            curve=curve_out, phenology=pheno_out,
            anomalies=anomalies,
            stability=SpatialMetrics(0.0, 0.0, "STABLE", 1.0),
            provenance={},
        )
        return ft, v_out

    def test_water_stress_scenario(self):
        print("\n🧠 Testing Layer 3: Water Stress Decision")
        rain = [0.0] * 30
        sar = [-12.0] * 30
        anom = VegetationAnomaly(
            anomaly_id="a1", type=AnomalyType.STALL,
            date_range=[self.dates[15], self.dates[29]],
            severity=0.6, confidence=0.8,
            description="Stall", likely_cause="LIKELY_WATER_STRESS",
        )
        ft, veg = self._make_mocks(rain, sar, [anom])
        decision = run_layer3_decision(self.inputs, ft, veg)
        self.assertTrue(len(decision.diagnoses) > 0, "Should have diagnoses")
        print(f"   -> Top diagnosis: {decision.diagnoses[0].problem_id}")

    def test_structure_loss_scenario(self):
        print("\n🧠 Testing Layer 3: Structure Loss (Anti-Logging)")
        rain = [5.0] * 30
        sar = [-12.0]*15 + [-6.0]*15  # SAR jump
        ft, veg = self._make_mocks(rain, sar, [])
        decision = run_layer3_decision(self.inputs, ft, veg)
        self.assertIsNotNone(decision.diagnoses, "Should return diagnoses")
        print(f"   -> Diagnoses: {[d.problem_id for d in decision.diagnoses]}")

    def test_waterlogging_scenario(self):
        print("\n🧠 Testing Layer 3: Waterlogging")
        rain = [15.0] * 30  # Heavy rain
        sar = [-8.0] * 30   # High SAR (wet)
        anom = VegetationAnomaly(
            anomaly_id="a2", type=AnomalyType.STALL,
            date_range=[self.dates[10], self.dates[25]],
            severity=0.5, confidence=0.7,
            description="Stall", likely_cause="WATERLOGGING",
        )
        ft, veg = self._make_mocks(rain, sar, [anom])
        decision = run_layer3_decision(self.inputs, ft, veg)
        self.assertTrue(len(decision.diagnoses) > 0)
        print(f"   -> Top diagnosis: {decision.diagnoses[0].problem_id}")

    def test_data_gap_scenario(self):
        print("\n🧠 Testing Layer 3: Data Gap")
        # Empty timeseries
        ft = FieldTensor(plot_id="plot_1", run_id="L1_123")
        ft.daily_state = {}
        ft.plot_timeseries = []
        veg = VegIntOutput(
            run_id="L2_123", layer1_run_id="L1_123",
            curve=ModeledCurveOutput([], [], CurveQuality(0, 0, 0)),
            phenology=PhenologyOutput([], {}),
            anomalies=[], stability=SpatialMetrics(0, 0, "STABLE"),
        )
        decision = run_layer3_decision(self.inputs, ft, veg)
        self.assertIsNotNone(decision)
        print(f"   -> Degradation: {decision.quality_metrics.degradation_mode}")

    def test_compliance_scenario(self):
        print("\n🧠 Testing Layer 3: Policy Compliance")
        rain = [0.0] * 30
        sar = [-12.0] * 30
        anom = VegetationAnomaly(
            anomaly_id="a3", type=AnomalyType.STALL,
            date_range=[self.dates[15], self.dates[29]],
            severity=0.6, confidence=0.8,
            description="Stall",
        )
        ft, veg = self._make_mocks(rain, sar, [anom])
        # Add policy constraints
        constrained_inputs = OrchestratorInput(
            plot_id="P1", geometry_hash="GEO123",
            date_range={"start": self.dates[0], "end": self.dates[-1]},
            crop_config={"crop": "wheat"},
            operational_context={"irrigation_type": "rainfed"},
            policy_snapshot={"spray_blocked": True},
        )
        decision = run_layer3_decision(constrained_inputs, ft, veg)
        self.assertTrue(len(decision.recommendations) >= 0)
        print(f"   -> Recommendations: {len(decision.recommendations)}")


if __name__ == "__main__":
    unittest.main()
