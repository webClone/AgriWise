"""
Photogrammetry Pipeline — Unit & Integration Tests.

Tests cover:
  1. Individual pipeline stages (frame_ingest, frame_qa, camera_model,
     tiepoints, alignment, bundle_adjustment, surface_model, orthorectify,
     mosaic, seam_optimizer, georef, artifact_store)
  2. Full pipeline orchestrator (engine)
  3. QA failure modes (insufficient frames, all blurred, no GPS)
  4. End-to-end photogrammetry → drone_rgb integration (the critical test)
"""

import pytest
import datetime

from ..schemas import (
    DroneFrameSetInput,
    CameraIntrinsics,
    FrameGPS,
    FrameMetadata,
    FrameQAResult,
    OrthomosaicOutput,
    MosaicStatus,
    GroundControlPoint,
)
from ..frame_ingest import FrameIngestor, FrameManifest
from ..frame_qa import FrameQA
from ..camera_model import CameraModelNormalizer
from ..tiepoints import TiePointExtractor
from ..alignment import InitialAligner
from ..bundle_adjustment import BundleAdjuster
from ..surface_model import SurfaceModelBuilder
from ..orthorectify import Orthorectifier
from ..mosaic import MosaicGenerator
from ..seam_optimizer import SeamOptimizer
from ..georef import Georeferencer
from ..engine import PhotogrammetryEngine
from ..benchmark.cases import (
    BENCHMARK_CASES,
    generate_synthetic_frame_set,
    DEFAULT_CAMERA,
    DEFAULT_POLYGON,
)


# ============================================================================
# Fixtures
# ============================================================================

def _make_test_input(num_frames=10, altitude=50.0, with_pixels=True):
    """Create a simple test DroneFrameSetInput."""
    gps_list = []
    frames = []
    for i in range(num_frames):
        gps = FrameGPS(
            latitude=36.0 + i * 0.0001,
            longitude=10.0 + (i % 3) * 0.0002,
            altitude_m=altitude,
            heading_deg=0.0,
            horizontal_accuracy_m=2.0,
        )
        gps_list.append(gps)
        
        if with_pixels:
            # Pixels need sufficient Laplacian variance to pass blur QA
            pixels = {
                "red": [[100 + ((x * 17 + y * 7 + i * 11) % 60) for x in range(10)] for y in range(10)],
                "green": [[120 + ((x * 13 + y * 11 + i * 5) % 50) for x in range(10)] for y in range(10)],
                "blue": [[60 + ((x * 7 + y * 3 + i * 9) % 40) for x in range(10)] for y in range(10)],
            }
            frames.append(pixels)
    
    return DroneFrameSetInput(
        mission_id="test_mission",
        plot_id="test_plot",
        camera=DEFAULT_CAMERA,
        frame_gps=gps_list,
        frame_count=num_frames,
        synthetic_frames=frames if with_pixels else None,
        plot_polygon=DEFAULT_POLYGON,
        target_gsd_cm=2.0,
        target_overlap_pct=75.0,
        flight_altitude_m=altitude,
    )


# ============================================================================
# Stage A: Frame Ingestion
# ============================================================================

class TestFrameIngest:
    def test_basic_ingest(self):
        inp = _make_test_input(10)
        ingestor = FrameIngestor()
        manifest = ingestor.ingest(inp)
        
        assert manifest.is_valid
        assert manifest.total_ingested == 10
        assert len(manifest.frames) == 10
        assert manifest.missing_gps_count == 0
    
    def test_insufficient_frames(self):
        inp = _make_test_input(2)
        ingestor = FrameIngestor()
        manifest = ingestor.ingest(inp)
        
        assert not manifest.is_valid
        assert "Insufficient frames" in manifest.validation_errors[0]
    
    def test_duplicate_detection(self):
        inp = _make_test_input(5)
        # Make two frames at same position
        inp.frame_gps[1].latitude = inp.frame_gps[0].latitude
        inp.frame_gps[1].longitude = inp.frame_gps[0].longitude
        inp.frame_gps[1].altitude_m = inp.frame_gps[0].altitude_m
        
        ingestor = FrameIngestor()
        manifest = ingestor.ingest(inp)
        
        assert manifest.duplicates_found >= 1
    
    def test_bbox_computation(self):
        inp = _make_test_input(5)
        ingestor = FrameIngestor()
        manifest = ingestor.ingest(inp)
        
        # bbox should be non-zero
        assert manifest.bbox[0] != 0 or manifest.bbox[1] != 0


# ============================================================================
# Stage B: Frame QA
# ============================================================================

class TestFrameQA:
    def test_good_frame(self):
        frame = FrameMetadata(
            frame_id="test_0",
            gps=FrameGPS(altitude_m=50.0),
            camera=DEFAULT_CAMERA,
            synthetic_pixels={
                "red": [[100 + ((x * 17 + y * 7) % 60) for x in range(20)] for y in range(20)],
                "green": [[120 + ((x * 13 + y * 11) % 50) for x in range(20)] for y in range(20)],
                "blue": [[60 + ((x * 7 + y * 3) % 40) for x in range(20)] for y in range(20)],
            },
        )
        qa = FrameQA()
        result = qa.assess_single(frame)
        
        assert result.usable
        assert result.quality_weight > 0.5
    
    def test_no_pixels_defaults(self):
        frame = FrameMetadata(frame_id="test_no_px")
        qa = FrameQA()
        result = qa.assess_single(frame)
        
        assert result.usable
        assert result.blur_score < 0.5
    
    def test_batch_assess(self):
        frames = [
            FrameMetadata(frame_id=f"test_{i}")
            for i in range(5)
        ]
        qa = FrameQA()
        results = qa.assess_batch(frames)
        
        assert len(results) == 5
        assert all(r.usable for r in results)


# ============================================================================
# Stage C: Camera Model
# ============================================================================

class TestCameraModel:
    def test_normalize(self):
        normalizer = CameraModelNormalizer()
        cam = normalizer.normalize(DEFAULT_CAMERA)
        
        assert cam.fx_px > 0
        assert cam.fy_px > 0
        assert cam.cx_px > 0
        assert cam.cy_px > 0
    
    def test_ground_projection(self):
        normalizer = CameraModelNormalizer()
        cam = normalizer.normalize(DEFAULT_CAMERA)
        
        # Center pixel should project to (0, 0)
        east, north = normalizer.project_to_ground(
            cam, 50.0,
            cam.cx_px, cam.cy_px,
        )
        assert abs(east) < 0.1
        assert abs(north) < 0.1
    
    def test_batch_normalize(self):
        frames = [FrameMetadata(camera=DEFAULT_CAMERA) for _ in range(5)]
        normalizer = CameraModelNormalizer()
        cameras = normalizer.normalize_batch(frames)
        
        assert len(cameras) == 5
        # All should be identical (shared camera)
        assert cameras[0].fx_px == cameras[4].fx_px


# ============================================================================
# Stage D: Tie Points
# ============================================================================

class TestTiePoints:
    def test_basic_extraction(self):
        frames = [
            FrameMetadata(
                frame_id=f"f_{i}",
                gps=FrameGPS(
                    latitude=36.0 + i * 0.0001,
                    longitude=10.0,
                    altitude_m=50.0,
                ),
                camera=DEFAULT_CAMERA,
            )
            for i in range(5)
        ]
        qa_results = [FrameQAResult(frame_id=f.frame_id, usable=True) for f in frames]
        
        extractor = TiePointExtractor()
        graph = extractor.extract(frames, qa_results)
        
        assert graph.total_pairs > 0
        assert graph.connected_components >= 1
    
    def test_no_overlap(self):
        # Frames very far apart — no overlap
        frames = [
            FrameMetadata(
                frame_id=f"f_{i}",
                gps=FrameGPS(latitude=36.0 + i * 0.1, longitude=10.0, altitude_m=50.0),
                camera=DEFAULT_CAMERA,
            )
            for i in range(3)
        ]
        qa_results = [FrameQAResult(frame_id=f.frame_id, usable=True) for f in frames]
        
        extractor = TiePointExtractor()
        graph = extractor.extract(frames, qa_results)
        
        assert graph.total_pairs == 0
        assert graph.missing_strip_risk > 0


# ============================================================================
# Stages E: Alignment + Bundle Adjustment
# ============================================================================

class TestAlignment:
    def test_basic_alignment(self):
        frames = [
            FrameMetadata(
                frame_id=f"f_{i}",
                gps=FrameGPS(latitude=36.0 + i * 0.0001, longitude=10.0, altitude_m=50.0),
            )
            for i in range(5)
        ]
        qa_results = [FrameQAResult(frame_id=f.frame_id, usable=True) for f in frames]
        
        aligner = InitialAligner()
        result = aligner.align(frames, qa_results)
        
        assert len(result.poses) == 5
        assert result.alignment_confidence > 0
        assert result.method == "gps_only"


class TestBundleAdjustment:
    def test_basic_ba(self):
        frames = [
            FrameMetadata(
                frame_id=f"f_{i}",
                gps=FrameGPS(latitude=36.0 + i * 0.0001, longitude=10.0, altitude_m=50.0),
                camera=DEFAULT_CAMERA,
            )
            for i in range(5)
        ]
        qa_results = [FrameQAResult(frame_id=f.frame_id, usable=True) for f in frames]
        
        aligner = InitialAligner()
        alignment = aligner.align(frames, qa_results)
        
        extractor = TiePointExtractor()
        overlap = extractor.extract(frames, qa_results)
        
        adjuster = BundleAdjuster()
        result = adjuster.adjust(alignment, overlap)
        
        assert len(result.refined_poses) == 5
        assert result.converged
        assert result.mean_reprojection_error_px >= 0  # Can be 0 with self-consistent observations
        assert result.adjustment_confidence > 0


# ============================================================================
# Stage F: Surface Model
# ============================================================================

class TestSurfaceModel:
    def test_flat_ground(self):
        from ..schemas import CameraPose
        poses = [CameraPose(altitude_m=50.0) for _ in range(5)]
        
        builder = SurfaceModelBuilder()
        result = builder.build(poses)
        
        assert result.model_type.value == "flat_ground"
        assert result.confidence > 0.5
    
    def test_external_dem(self):
        builder = SurfaceModelBuilder()
        result = builder.build([], dem_ref="s3://dem/srtm30.tif", dem_resolution_m=30.0)
        
        assert result.model_type.value == "external_dem"
        assert result.dem_ref == "s3://dem/srtm30.tif"


# ============================================================================
# Stages G-J: Orthorectify, Mosaic, Seam, Georef
# ============================================================================

class TestMosaicPipeline:
    def test_full_mosaic_stages(self):
        """Test orthorectify → mosaic → seam → georef pipeline."""
        inp = _make_test_input(6)
        
        ingestor = FrameIngestor()
        manifest = ingestor.ingest(inp)
        
        qa = FrameQA()
        qa_results = qa.assess_batch(manifest.frames)
        
        cam_norm = CameraModelNormalizer()
        cameras = cam_norm.normalize_batch(manifest.frames)
        
        aligner = InitialAligner()
        alignment = aligner.align(manifest.frames, qa_results)
        
        surface_builder = SurfaceModelBuilder()
        surface = surface_builder.build(alignment.poses)
        
        ortho = Orthorectifier()
        tiles = ortho.rectify(manifest.frames, qa_results, alignment.poses, cameras, surface)
        
        assert len(tiles.tiles) > 0
        
        mosaic_gen = MosaicGenerator()
        mosaic = mosaic_gen.generate(tiles)
        
        assert mosaic.pixels is not None
        assert mosaic.width_px > 0
        assert mosaic.height_px > 0
        
        seam_opt = SeamOptimizer()
        seam = seam_opt.analyze(mosaic)
        
        assert seam.seam_artifact_score >= 0
        
        georef = Georeferencer()
        geo = georef.georeference(mosaic, inp, 0.5)
        
        assert geo.coverage_completeness >= 0
        assert geo.ground_resolution_cm > 0


# ============================================================================
# Full Pipeline (Engine)
# ============================================================================

class TestEngine:
    def test_happy_path(self):
        inp = _make_test_input(10)
        engine = PhotogrammetryEngine()
        output = engine.process(inp)
        
        assert output.usable
        assert output.qa_score > 0
        assert output.orthomosaic_ref != ""
        assert output.provenance.pipeline_version == "v2"
        assert output.provenance.total_frames_ingested == 10
        assert len(output.provenance.processing_steps) > 0
        assert output.provenance.alignment_method != ""
        assert output.provenance.surface_model_type != ""
    
    def test_too_few_frames(self):
        inp = _make_test_input(2)
        engine = PhotogrammetryEngine()
        output = engine.process(inp)
        
        assert not output.usable
        assert output.status == MosaicStatus.UNUSABLE
    
    def test_provenance_mandatory(self):
        """Every output MUST have complete provenance."""
        inp = _make_test_input(8)
        engine = PhotogrammetryEngine()
        output = engine.process(inp)
        
        prov = output.provenance
        assert prov.pipeline_version != ""
        assert prov.alignment_method != ""
        assert prov.surface_model_type != ""
        assert len(prov.processing_steps) > 5  # At least 6 stages completed
        assert prov.total_frames_ingested > 0
    
    def test_provenance_on_failure(self):
        """Even failed outputs must have provenance."""
        inp = _make_test_input(1)  # Will fail
        engine = PhotogrammetryEngine()
        output = engine.process(inp)
        
        assert not output.usable
        assert output.provenance.pipeline_version == "v2"
    
    def test_gcp_fields_stored(self):
        """GCP fields should be accepted and surfaced in provenance."""
        inp = _make_test_input(8)
        inp.gcps = [
            GroundControlPoint(
                gcp_id="GCP_01",
                latitude=36.0001,
                longitude=10.0001,
                altitude_m=0.0,
                accuracy_m=0.02,
            )
        ]
        engine = PhotogrammetryEngine()
        output = engine.process(inp)
        
        assert output.provenance.gcps_provided == 1
        assert output.provenance.gcps_used == 0  # V1: no fake refinement
    
    def test_dem_hook(self):
        """Optional DEM should be accepted and recorded in provenance."""
        inp = _make_test_input(8)
        inp.dem_ref = "s3://dem/srtm30.tif"
        inp.dem_resolution_m = 30.0
        
        engine = PhotogrammetryEngine()
        output = engine.process(inp)
        
        assert output.provenance.surface_model_type == "external_dem"
        assert output.provenance.dem_source == "s3://dem/srtm30.tif"
    
    def test_benchmark_cases(self):
        """All benchmark cases should run without crashing."""
        engine = PhotogrammetryEngine()
        for case in BENCHMARK_CASES:
            inp = generate_synthetic_frame_set(case)
            output = engine.process(inp)
            
            # Should always produce an output
            assert output is not None
            assert output.provenance.pipeline_version == "v2"


# ============================================================================
# QA Failure Modes
# ============================================================================

class TestQAFailureModes:
    def test_all_frames_missing_gps(self):
        inp = _make_test_input(5)
        inp.frame_gps = []  # No GPS at all
        
        engine = PhotogrammetryEngine()
        output = engine.process(inp)
        
        # Should complete but with low quality
        assert output.provenance.pipeline_version == "v2"


# ============================================================================
# CRITICAL: End-to-End Photogrammetry → drone_rgb Integration
# ============================================================================

class TestPhotogrammetryToDroneRGBIntegration:
    """Proves the full pipeline:
    1. Orthomosaic is created by photogrammetry engine
    2. drone_rgb Mapping Mode consumes it via orthomosaic_output
    3. Row / weed / structural outputs are produced
    
    This is the guardrail test that proves the subsystem is worth building.
    """
    
    def test_end_to_end_integration(self):
        """Full integration: photogrammetry → drone_rgb."""
        from ...layer0.perception.drone_rgb.engine import DroneRGBEngine
        from ...layer0.perception.drone_rgb.schemas import DroneRGBInput
        from ...drone_mission.schemas import FlightMode, MissionType
        
        # --- Step 1: Run photogrammetry to produce orthomosaic ---
        photogram_inp = _make_test_input(10)
        photogram_engine = PhotogrammetryEngine()
        ortho_output = photogram_engine.process(photogram_inp)
        
        assert ortho_output.usable, (
            f"Photogrammetry failed: {ortho_output.rejection_reason}"
        )
        assert ortho_output._benchmark_pixels is not None
        
        # --- Step 2: Feed orthomosaic into drone_rgb Mapping Mode ---
        drone_rgb_inp = DroneRGBInput(
            plot_id="integration_test_plot",
            mission_id="integration_test_mission",
            flight_mode=FlightMode.MAPPING_MODE,
            mission_type=MissionType.FULL_PLOT_MAP,
            orthomosaic_output=ortho_output,
        )
        
        drone_rgb_engine = DroneRGBEngine()
        drone_out, packets = drone_rgb_engine.process_full(drone_rgb_inp)
        
        # --- Step 3: Verify structural outputs ---
        assert drone_out is not None
        assert drone_out.is_valid, (
            f"Drone RGB rejected: {drone_out.rejection_reason}"
        )
        
        # Should have structural analysis results
        # (row azimuth may be 0 for uniform test pixels, that's fine)
        assert drone_out.qa_score > 0
        
        # Should have provenance from photogrammetry
        assert drone_out.orthomosaic_provenance is not None
        assert drone_out.orthomosaic_provenance["pipeline_version"] == "v2"
    
    def test_unusable_mosaic_rejected(self):
        """drone_rgb should reject unusable photogrammetry output."""
        from ...layer0.perception.drone_rgb.engine import DroneRGBEngine
        from ...layer0.perception.drone_rgb.schemas import DroneRGBInput
        from ...drone_mission.schemas import FlightMode, MissionType
        
        # Create an unusable mosaic
        bad_output = OrthomosaicOutput(
            mission_id="bad_mission",
            plot_id="bad_plot",
            status=MosaicStatus.UNUSABLE,
            usable=False,
            rejection_reason="Coverage too low",
        )
        
        drone_rgb_inp = DroneRGBInput(
            plot_id="test_plot",
            mission_id="test_mission",
            flight_mode=FlightMode.MAPPING_MODE,
            mission_type=MissionType.FULL_PLOT_MAP,
            orthomosaic_output=bad_output,
        )
        
        drone_rgb_engine = DroneRGBEngine()
        drone_out, packets = drone_rgb_engine.process_full(drone_rgb_inp)
        
        assert drone_out is not None
        assert not drone_out.is_valid
        assert "unusable" in drone_out.rejection_reason.lower()
    
    def test_command_mode_bypasses_photogrammetry(self):
        """Command/Revisit mode should NOT use photogrammetry."""
        from ...layer0.perception.drone_rgb.engine import DroneRGBEngine
        from ...layer0.perception.drone_rgb.schemas import DroneRGBInput
        from ...drone_mission.schemas import FlightMode, MissionType
        
        drone_rgb_inp = DroneRGBInput(
            plot_id="test_plot",
            mission_id="test_mission",
            flight_mode=FlightMode.COMMAND_REVISIT_MODE,
            mission_type=MissionType.CONCERN_ZONE_COMMAND,
            # Explicitly provide an orthomosaic_output — should be ignored
            orthomosaic_output=OrthomosaicOutput(
                mission_id="should_ignore",
                usable=True,
            ),
        )
        
        drone_rgb_engine = DroneRGBEngine()
        drone_out, packets = drone_rgb_engine.process_full(drone_rgb_inp)
        
        assert drone_out is not None
        # Should route to farmer photo, not use orthomosaic
        assert drone_out.routed_to_farmer_photo
